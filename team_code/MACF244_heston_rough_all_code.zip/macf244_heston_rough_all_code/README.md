# MAC F244 – Heston and rough Heston additions: all code

Every script written for the Heston / rough Heston extension of the MAC F244 project
(repo: github.com/shrirang73/macf242, tested at commit beeb9551). All files are NEW;
no existing repo file is overwritten.

## Install
1. Clone the repo **with its submodule** (`git clone --recurse-submodules ...`), install
   `requirements.txt` (Python 3.13/3.14). Details: `HESTON_INSTRUCTIONS.md`.
2. Copy this zip's `src/`, `tests/` and `extras/` folders into the repo root.
3. Pricing scripts need the full NSE option data in `data/raw/bhavcopy/nifty/` (git-ignored).
   Either copy it from the shared `data.rar` (on machines without unrar/7z:
   `python extras/extract_rar_libarchive.py data.rar unpacked extract`, then copy
   `unpacked/data/raw/bhavcopy/nifty/` into the repo) or rebuild it with `python -m src.bhavcopy` (~1.5 h).

Run everything from the repo root.

## Files

### src/ (run with `python -m src.<name>`)
| File | What it does | Output |
|---|---|---|
| `heston.py` | Heston price, delta, dC/dv, minimum-variance delta (Fourier, Gil-Pelaez); parameter estimation from VIX + NIFTY | library |
| `rough_heston.py` | Rough Heston (rough Hawkes-Heston without jumps): fractional Riccati (Adams scheme), price, delta, min-var delta; roughness estimator; VIX-variogram fit | library |
| `backtest_heston.py` | NIFTY hedging backtest with BS / Heston delta / Heston min-var (parameters from 2010-2018) | `results/backtest_heston/{bs,heston,heston_mv}/` |
| `backtest_heston_rolling.py` | Heston re-estimated every month: `--window 252` (12-month), `126` (6-month), `0` (expanding, all data since 2010) | `results/backtest_heston/heston*_roll{252,126,exp}/` |
| `backtest_rough.py` | Rough Heston (alpha ~0.555) and alpha = 1 control hedges | `results/backtest_heston/rough*/` |
| `compare_hedges.py` | Hedges x strategies x costs: RMSE, VaR, ES, worst, z vs BS; `--hedges ... --name ...` | `results/backtest_heston/<name>.{md,csv}` |
| `pricing_test.py` | Prices traded ~3-month NIFTY calls with BS, Heston, rough, alpha = 1 | `results/pricing_test/` |
| `pricing_all_models.py` | Pricing comparison of all 7 models incl. monthly-updated Heston | `results/pricing_test/all_models.md` |
| `pricing_robustness.py` | Liquidity filter + ~1-month contracts | `results/pricing_test/robustness.md` |
| `compare_models.py` | Full comparison report: bootstrap intervals, tail risk, worst case, win rates, yearly ranks, rank stability, tail drivers, stress windows (hedging); error breakdown, worst mispricings, by strike, intervals, win rates, yearly ranks (pricing) | `results/model_comparison/model_comparison_report.md` |

### tests/ (28 checks; with the repo's 41, 69 pass: `python -m pytest tests -q`)
`test_heston.py` (14), `test_heston_rolling.py` (4), `test_rough_heston.py` (8), `test_pricing_test.py` (2).

### extras/ (run with `python extras/<name>.py`)
| File | What it does |
|---|---|
| `hedging_tables_all_models.py` | RMSE / ES99 tables for all 13 hedges x 3 strategies x 3 costs, with/without COVID |
| `tail_risk_real.py` | VaR / ES / worst loss of the three strategies on the original BS real-data backtest (`python extras/tail_risk_real.py results/backtest_real/maturity_21`) |
| `tail_risk_sim.py`, `tail_risk_sim_es.py` | Tail risk of the rules in the RHH simulation (argument: folder with `per_path.npz` from `python -m src.experiment_discrete`) |
| `roughness_nifty.py` | Is NIFTY rough? alpha from range volatility and VIX, smoothing-bias check, jump clustering |
| `extract_rar_libarchive.py` | Unpacks `data.rar` without unrar/7z |
| `experimental_rough_expanding.py` | EXPERIMENTAL, not in any result: expanding-window rough Heston; unstable after March 2020 (see its docstring) |

## Full run order (reproduces every reported number)
```bash
python -m pytest tests -q                                   # 69 passed
python -m src.backtest_heston
python -m src.backtest_heston_rolling --window 252
python -m src.backtest_heston_rolling --window 126
python -m src.backtest_heston_rolling --window 0
python -m src.backtest_rough
H="bs heston heston_mv heston_roll252 heston_mv_roll252 heston_roll126 heston_mv_roll126 heston_rollexp heston_mv_rollexp rough_a1 rough_mv_a1 rough rough_mv"
for h in $H; do
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21 --exclude-test 2020-01-15 2020-06-30 --tag excl_covid
done
python -m src.compare_hedges
python -m src.compare_hedges --hedges $H --name comparison_all
python extras/hedging_tables_all_models.py
python -m src.pricing_test           # needs full option data
python -m src.pricing_all_models
python -m src.pricing_robustness
python -m src.compare_models
python extras/roughness_nifty.py
```
Run time: about 15 minutes in total. Checked on a fresh clone: all tests pass and every result file matches the reported numbers exactly.
