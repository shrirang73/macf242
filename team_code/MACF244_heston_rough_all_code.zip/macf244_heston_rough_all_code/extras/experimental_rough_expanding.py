"""EXPERIMENTAL - NOT USED IN ANY REPORTED RESULT.

Known problem: after the 2020 crash enters the expanding window, the estimated
vol of vol nu jumps from ~0.19 to 0.41-0.77, and the fractional Riccati solver in
rough_heston.py becomes unstable for short times to expiry (non-finite hedge ratios
from April 2020). Months up to March 2020 are fine. A stable solver (e.g. the rational
approximation of Gatheral & Radoicic 2019) is needed before this can be used.

Rough Heston hedges on NIFTY with parameters re-estimated EVERY MONTH on an
EXPANDING window (test period 2019-2026).

For each test month M, every rough Heston parameter is re-estimated from ALL
data from the first day of the panel (2010-07-20) up to the day before M's
first trading day (no look-ahead), exactly as ``backtest_rough.estimate`` does
for the training period:
  * alpha = H + 1/2 from the Garman--Klass range volatility (OHLC);
  * lam, nu from the VIX^2 variogram with alpha fixed;
  * rho as in heston.estimate_params.
Options starting in month M are hedged with month M's parameters for their
whole life (flat forward variance at (VIX/100)^2, as in backtest_rough).

The train file is copied from the fixed-parameter run (``rough`` / ``rough_mv``),
so rules are picked on train exactly as there.

Heavy: about 25 s per month (93 months). Each month is cached in
results/backtest_heston/_rough_rollexp_cache/<YYYY-MM>.npz, so the run can be
stopped and resumed; ``--max-minutes`` stops cleanly after that long.

Requires: ``python -m src.backtest_rough`` first.
Outputs: results/backtest_heston/{rough_rollexp, rough_mv_rollexp}/maturity_21/
  per_option_{train,test}.npz, config.json, monthly_params.csv
Usage (copy to src/ first, or run from repo root): python -m extras.experimental_rough_expanding [--workers 2] [--max-minutes 0]
"""

from __future__ import annotations

import argparse
import csv
import json
import shutil
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

from src import backtest_real as bt
from src import backtest_rough as br
from src import heston as hs
from src import rebalancing as rb
from src import rough_heston as rh
from src.backtest_heston import OUT

MATURITY = 21
CACHE = OUT / "_rough_rollexp_cache"


def month_params(panel: pd.DataFrame, ohlc: pd.DataFrame, month_first: pd.Timestamp) -> dict:
    """All parameters from data strictly before ``month_first`` (expanding window)."""
    hist = panel[panel.index < month_first]
    o = ohlc[(ohlc.index >= panel.index[0]) & (ohlc.index < month_first)]
    H = rh.roughness_H(rh.garman_klass_logvol(o["open"], o["high"], o["low"], o["close"]))
    alpha = H + 0.5
    rho = hs.estimate_params(hist["vix"].to_numpy(), hist["nifty"].to_numpy()).rho
    lam, nu, info = rh.fit_lam_nu(hist["vix"].to_numpy(), alpha)
    return {"alpha": alpha, "lam": lam, "nu": nu, "rho": rho, "H": H,
            "rows": int(len(hist)), "ohlc_days": int(len(o)), **info}


def run_month(args) -> str:
    key, month_first, idx = args
    path = CACHE / f"{key}.npz"
    if path.exists():
        return key
    panel = bt.load_panel()
    ohlc = load_ohlc()
    est = month_params(panel, ohlc, pd.Timestamp(month_first))
    p = rh.RoughParams(est["alpha"], est["lam"], est["nu"], est["rho"])
    labels = bt.label_variants(panel, br.LABELS)
    stock, vol, _ = bt.build_paths(panel, np.asarray(idx), MATURITY, labels)
    delta, minvar = br.targets(stock, vol, p, MATURITY)
    np.savez_compressed(path, delta=delta, minvar=minvar, idx=np.asarray(idx),
                        params=json.dumps(est))
    return key


def load_ohlc() -> pd.DataFrame:
    o = pd.read_csv(br.OHLC_CSV, parse_dates=["date"]).set_index("date")
    return o[~o["special_session"].astype(bool)]


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--max-minutes", type=float, default=0.0, help="0 = no limit")
    parser.add_argument("--root", type=Path, default=OUT)
    args = parser.parse_args(argv)
    for base in ("rough", "rough_mv"):
        if not (args.root / base / f"maturity_{MATURITY}" / "per_option_train.npz").exists():
            raise FileNotFoundError("run python -m src.backtest_rough first")
    CACHE.mkdir(parents=True, exist_ok=True)
    panel = bt.load_panel()
    starts = bt.option_starts(panel, "test", MATURITY)
    months = panel.index[starts].to_period("M")
    jobs = []
    for m in sorted(set(months)):
        idx = starts[np.asarray(months == m)]
        first = panel.index[panel.index.to_period("M") == m][0]
        jobs.append((str(m), str(first.date()), idx.tolist()))
    todo = [j for j in jobs if not (CACHE / f"{j[0]}.npz").exists()]
    print(f"{len(jobs)} months, {len(todo)} to compute", flush=True)
    t0 = time.time()
    if todo:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            pending = list(todo)
            running = {}
            while pending or running:
                while pending and len(running) < args.workers and not (
                        args.max_minutes and time.time() - t0 > args.max_minutes * 60):
                    job = pending.pop(0)
                    running[pool.submit(run_month, job)] = job[0]
                if not running:
                    break
                done = next(iter(f for f in list(running) if f.done()), None)
                if done is None:
                    time.sleep(0.5)
                    continue
                print("done", done.result(), f"{(time.time() - t0) / 60:.1f} min", flush=True)
                running.pop(done)
    left = [j for j in jobs if not (CACHE / f"{j[0]}.npz").exists()]
    if left:
        print(f"stopped: {len(left)} months left; run again to resume")
        return

    # assemble
    n_opt = len(starts)
    delta = np.full((n_opt, MATURITY), np.nan)
    minvar = np.full_like(delta, np.nan)
    pos = {int(s): i for i, s in enumerate(starts)}
    params = {}
    for key, _, _ in jobs:
        z = np.load(CACHE / f"{key}.npz")
        rows = [pos[int(s)] for s in z["idx"]]
        delta[rows], minvar[rows] = z["delta"], z["minvar"]
        params[key] = json.loads(str(z["params"]))
    labels = bt.label_variants(panel, br.LABELS)
    stock, vol, lab = bt.build_paths(panel, starts, MATURITY, labels)
    for base, target in (("rough", delta), ("rough_mv", minvar)):
        if not np.all(np.isfinite(target)):
            raise FloatingPointError(f"non-finite hedge ratios for {base}")
        out = {"start_dates": panel.index[starts].strftime("%Y-%m-%d").to_numpy().astype("U10"),
               "premium": bt.bs_call(1.0, 1.0, MATURITY / bt.YEAR, vol[:, 0]),
               "payoff": np.maximum(stock[:, -1] - 1.0, 0.0), "target0": target[:, 0]}
        for name, rule, variant in bt.build_rules(list(labels), MATURITY):
            phi, _ = rb.held_positions(target, rule, lab[variant] if variant is not None else None)
            res = rb.trading_outcome(phi, stock)
            out[f"gain|{name}"] = res["gain"]
            out[f"notional|{name}"] = (res["notional_initial"] + res["notional_rebalance"]
                                       + res["notional_terminal"])
            out[f"trades|{name}"] = res["trades"]
        src = args.root / base / f"maturity_{MATURITY}"
        d = args.root / f"{base}_rollexp" / f"maturity_{MATURITY}"
        d.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(d / "per_option_test.npz", **out)
        shutil.copy(src / "per_option_train.npz", d / "per_option_train.npz")
        cfg = json.loads((src / "config.json").read_text())
        cfg.update({"hedge": f"{base}_rollexp", "rough_params": "monthly_params.csv",
                    "window": "expanding from 2010-07-20",
                    "train_file": f"copied from {base}/ (fixed 2010-2018 parameters)"})
        cfg["periods"]["test"]["mean_initial_hedge"] = float(out["target0"].mean())
        (d / "config.json").write_text(json.dumps(cfg, indent=2))
        with (d / "monthly_params.csv").open("w", newline="") as fh:
            w = csv.writer(fh, lineterminator="\n")
            w.writerow(["month", "alpha", "lam", "nu", "rho", "lam_at_grid_edge"])
            for m, e in params.items():
                w.writerow([m, e["alpha"], e["lam"], e["nu"], e["rho"], e["lam_at_grid_edge"]])
        print(f"{base}_rollexp written: {len(out['premium'])} options, mean initial hedge "
              f"{out['target0'].mean():.3f}")


if __name__ == "__main__":
    main()
