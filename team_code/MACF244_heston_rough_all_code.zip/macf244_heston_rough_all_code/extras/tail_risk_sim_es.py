import sys, json, numpy as np
d = sys.argv[1]
z = np.load(f"{d}/per_path.npz"); cfg = json.load(open(f"{d}/config.json"))
cap = cfg["gkw_capital"]; payoff = z["payoff"]; BP = 1e4
R = [("Fixed every step","fixed/every=1"),
     ("Fixed (every 16)","fixed/every=16"),
     ("Regime-aware","variance/calm=32,stress=8,thr=0.01217"),
     ("Band h=0.1","band/half_width=0.1")]
rng = np.random.default_rng(0)
def es(loss,q):
    v=np.quantile(loss,q); return v, loss[loss>=v].mean()
for kappa in (0.0, 0.0005):
  for h in ("GKW","BS"):
    print(f"\n{h} hedge, cost {kappa*BP:.0f} bp  (bp of S0; loss = -P&L; 50,000 paths)")
    print(f"{'rule':18s}{'trades':>7s}{'notl':>6s}{'mean':>7s}{'sd':>7s}{'VaR95':>7s}{'ES95':>7s}{'VaR99':>7s}{'ES99':>7s}{'ES99 se':>8s}{'worst':>7s}")
    for name,r in R:
        g=z[f"gain|{h}|{r}"]; n=z[f"notional|{h}|{r}"].astype(float)
        e=(cap+g-kappa*n-payoff)*BP; loss=-e
        v95,e95=es(loss,.95); v99,e99=es(loss,.99)
        bs=[es(loss[rng.integers(0,len(loss),len(loss))],.99)[1] for _ in range(100)]
        print(f"{name:18s}{z[f'trades|{h}|{r}'].mean():7.0f}{n.mean():6.2f}{e.mean():7.1f}{e.std():7.1f}{v95:7.1f}{e95:7.1f}{v99:7.1f}{e99:7.1f}{np.std(bs):8.1f}{loss.max():7.0f}")
