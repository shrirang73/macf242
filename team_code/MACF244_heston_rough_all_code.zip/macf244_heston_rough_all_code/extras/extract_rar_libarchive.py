"""Extract (or list) a .rar archive using the system libarchive library via ctypes,
for machines without unrar/7z. Used to unpack the shared data.rar (full NSE option data).

Usage: python extras/extract_rar_libarchive.py data.rar OUT_DIR list|extract
Then copy OUT_DIR/data/raw/bhavcopy/nifty/ into the repo's data/raw/bhavcopy/nifty/.
"""
import ctypes, os, sys
la = ctypes.CDLL("libarchive.so.13")
la.archive_read_new.restype = ctypes.c_void_p
la.archive_entry_pathname.restype = ctypes.c_char_p
la.archive_entry_pathname.argtypes = [ctypes.c_void_p]
la.archive_entry_size.restype = ctypes.c_int64
la.archive_entry_size.argtypes = [ctypes.c_void_p]
la.archive_entry_filetype.restype = ctypes.c_uint
la.archive_entry_filetype.argtypes = [ctypes.c_void_p]
la.archive_error_string.restype = ctypes.c_char_p
la.archive_error_string.argtypes = [ctypes.c_void_p]
for f in ("archive_read_support_format_all","archive_read_support_filter_all"):
    getattr(la,f).argtypes=[ctypes.c_void_p]
la.archive_read_open_filename.argtypes=[ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
la.archive_read_next_header.argtypes=[ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
la.archive_read_data.argtypes=[ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
la.archive_read_data.restype=ctypes.c_ssize_t
src, dst, mode = sys.argv[1], sys.argv[2], sys.argv[3]  # mode: list | extract
a = la.archive_read_new()
la.archive_read_support_format_all(a); la.archive_read_support_filter_all(a)
if la.archive_read_open_filename(a, src.encode(), 1 << 20) != 0:
    sys.exit("open failed: %s" % la.archive_error_string(a))
entry = ctypes.c_void_p(); n = 0; total = 0
buf = ctypes.create_string_buffer(1 << 20)
while True:
    r = la.archive_read_next_header(a, ctypes.byref(entry))
    if r == 1: break
    if r < 0: sys.exit("header error: %s" % la.archive_error_string(a))
    name = la.archive_entry_pathname(entry).decode("utf-8", "replace").replace("\\", "/")
    size = la.archive_entry_size(entry); isdir = la.archive_entry_filetype(entry) == 0o040000
    n += 1; total += max(size, 0)
    if mode == "list":
        if n <= 40 or not name.endswith(".csv.gz"): print(name, size)
        continue
    out = os.path.normpath(os.path.join(dst, name))
    if not out.startswith(os.path.abspath(dst)): sys.exit("unsafe path " + name)
    if isdir: os.makedirs(out, exist_ok=True); continue
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "wb") as fh:
        while True:
            k = la.archive_read_data(a, buf, len(buf))
            if k < 0: sys.exit("data error in %s: %s" % (name, la.archive_error_string(a)))
            if k == 0: break
            fh.write(buf.raw[:k])
print("entries", n, "bytes", total)
