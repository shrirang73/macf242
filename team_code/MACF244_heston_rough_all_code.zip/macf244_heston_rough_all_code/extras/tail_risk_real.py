import sys, numpy as np
d = sys.argv[1]
R = {"Fixed daily":"fixed/every=1",
     "Regime-aware":"regime[vix_hyst]/calm=2,stress=1",
     "Band h=0.02":"band/h=0.02"}
BP = 1e4
def pnl(z, rule, kappa):
    return (z["premium"] + z[f"gain|{rule}"] - kappa*z[f"notional|{rule}"] - z["payoff"])*BP
def stats(e):
    loss = -e
    v95 = np.quantile(loss, .95); v99 = np.quantile(loss, .99)
    return dict(mean=e.mean(), sd=e.std(), var95=v95, es95=loss[loss>=v95].mean(),
                var99=v99, es99=loss[loss>=v99].mean(), worst=loss.max())
for kappa in (0.0005,):
  for per in ("train","test"):
    z = np.load(f"{d}/per_option_{per}.npz")
    dates = z["start_dates"].astype(str)
    covid = (dates>="2020-01-15")&(dates<="2020-06-30")
    for tag, mask in (("all", np.ones(len(dates),bool)), ("excl_covid", ~covid)):
        if per=="train" and tag=="excl_covid": continue
        print(f"\n{per} / {tag} / cost {kappa*BP:.0f}bp  n={mask.sum()}  (bp of notional; loss = -P&L)")
        print(f"{'rule':14s}{'mean':>8s}{'sd':>8s}{'VaR95':>8s}{'ES95':>8s}{'VaR99':>8s}{'ES99':>8s}{'worst':>8s}")
        for name, r in R.items():
            s = stats(pnl(z, r, kappa)[mask])
            print(f"{name:14s}"+"".join(f"{s[k]:8.1f}" for k in ("mean","sd","var95","es95","var99","es99","worst")))
