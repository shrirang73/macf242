import sys, json, numpy as np
d = sys.argv[1]
z = np.load(f"{d}/per_path.npz")
cfg = json.load(open(f"{d}/config.json"))
cap = cfg["gkw_capital"]; payoff = z["payoff"]
hedges = ["GKW","BS"]
rules = sorted({k.split("|",2)[2] for k in z.files if k.startswith("gain|GKW|")})
print("rule | mean trades | mean notional (GKW)")
for r in rules:
    print(f"{r:48s}{z[f'trades|GKW|{r}'].mean():8.1f}{z[f'notional|GKW|{r}'].mean():8.2f}")
