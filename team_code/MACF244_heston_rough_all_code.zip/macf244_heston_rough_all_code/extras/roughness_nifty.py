"""Is NIFTY volatility rough? Estimate H (alpha = H + 1/2) by the
Gatheral-Jaisson-Rosenbaum (2018) method: m(q, D) = mean |log s_{t+D} - log s_t|^q ~ D^{qH}.
Volatility proxies: (a) Garman-Klass daily range vol from NIFTY OHLC, (b) India VIX.
Plus a simple jump/clustering check on daily returns."""
import numpy as np, pandas as pd
R = ""  # run from the repo root
o = pd.read_csv(R + "data/processed/nifty50.csv", parse_dates=["date"]).set_index("date")
o = o[(o.index >= "2010-07-20") & ~o.special_session.astype(bool)]
gk = 0.5*np.log(o.high/o.low)**2 - (2*np.log(2)-1)*np.log(o.close/o.open)**2
gk = gk[gk > 0]
panel = pd.read_csv(R + "results/regimes/regime_labels.csv", index_col=0, parse_dates=True)
series = {"range vol (Garman-Klass)": 0.5*np.log(gk), "India VIX": np.log(panel.vix)}
lags = np.arange(1, 51)
def H_est(x, q, lags):
    x = x.to_numpy()
    m = [np.mean(np.abs(x[l:] - x[:-l])**q) for l in lags]
    slope = np.polyfit(np.log(lags), np.log(m), 1)[0]
    return slope / q
def run(x, label):
    hs = {q: H_est(x, q, lags) for q in (0.5, 1, 1.5, 2)}
    h_long = H_est(x, 2, np.arange(5, 51))
    print(f"  {label:26s} H(q=.5,1,1.5,2) = " + ", ".join(f"{h:.3f}" for h in hs.values())
          + f"  | H(q=2, lags 5-50) = {h_long:.3f}  -> alpha = H + 0.5 = {hs[2]+0.5:.2f}")
for name, x in series.items():
    print(name)
    run(x, "2010-2026")
    run(x[x.index < "2019-01-01"], "2010-2018")
    run(x[x.index >= "2019-01-01"], "2019-2026")
# Smoothing bias check: a known-H series averaged over 21 days, as VIX is, then re-estimated
rng = np.random.default_rng(0)
def fbm(n, H):
    k = np.arange(n); g = 0.5*(np.abs(k+1)**(2*H) - 2*np.abs(k)**(2*H) + np.abs(k-1)**(2*H))
    c = np.concatenate([g, g[-2:0:-1]]); lam = np.fft.fft(c).real; lam[lam < 0] = 0
    z = rng.standard_normal(len(c)) + 1j*rng.standard_normal(len(c))
    return np.cumsum(np.fft.fft(np.sqrt(lam/len(c))*z).real[:n])
print("bias check (synthetic log-vol with known H, then 21-day averaging like VIX):")
for H in (0.05, 0.1, 0.2, 0.5):
    x = pd.Series(fbm(2**12, H))
    sm = np.log(pd.Series(np.exp(0.3*x)).rolling(21).mean().dropna())
    noisy = 0.3*x + 0.25*rng.standard_normal(len(x))
    print(f"  true H {H:.2f}: raw {H_est(0.3*x,2,lags):.3f}  21-day averaged {H_est(sm,2,lags):.3f}  with daily noise {H_est(noisy,2,lags):.3f}")
# Jumps and clustering
p = panel.nifty; r = np.log(p).diff().dropna()
sd = r.rolling(63).std().shift(1)
z = (r/sd).dropna(); jump = z.abs() > 4
print(f"jumps (|return| > 4 x trailing 3-month sd): {jump.sum()} days in {len(z)} ({jump.mean()*252:.2f} per year)")
print("  dates:", ", ".join(d.strftime('%Y-%m-%d') for d in z.index[jump]))
big = r < -0.03
idx = np.flatnonzero(big.to_numpy())
after = np.mean([big.iloc[i+1:i+11].any() for i in idx if i+11 < len(big)])
base = 1 - (1 - big.mean())**10
print(f"falls > 3% in a day: {big.sum()}; P(another within 10 days | one today) = {after:.2f} vs {base:.2f} if no clustering")
