"""Hedging error / ES99 table for all 13 hedges, 3 strategies, 3 costs, with and without COVID.

Needs: python -m src.compare_hedges --hedges bs heston heston_mv heston_roll252 heston_mv_roll252
heston_roll126 heston_mv_roll126 heston_rollexp heston_mv_rollexp rough_a1 rough_mv_a1 rough rough_mv
--name comparison_all
Usage (from repo root): python extras/hedging_tables_all_models.py
Writes results/backtest_heston/hedging_error_es99_all_models.md
"""
import csv
from pathlib import Path

ROOT = Path("results/backtest_heston")
rows = list(csv.DictReader(open(ROOT / "comparison_all.csv")))
names = {"bs": "Black-Scholes", "heston": "Heston delta (fixed)", "heston_mv": "Heston min-var (fixed)",
         "heston_roll252": "Heston delta, 12-month", "heston_mv_roll252": "Heston min-var, 12-month",
         "heston_roll126": "Heston delta, 6-month", "heston_mv_roll126": "Heston min-var, 6-month",
         "heston_rollexp": "Heston delta, expanding", "heston_mv_rollexp": "Heston min-var, expanding",
         "rough_a1": "alpha=1 delta", "rough_mv_a1": "alpha=1 min-var", "rough": "Rough delta", "rough_mv": "Rough min-var"}
out = ["# Hedging error / ES99 for every hedge (NIFTY, test 2019-2026)", "",
       "Each cell: RMSE (overall hedging error) / ES99 (average loss in the worst 1% of options), bp of notional.",
       "Rules picked on 2010-2018 for each hedge: daily = fixed/every=1; regime = regime[vix_hyst]/calm=2,stress=1; "
       "band = band/h=0.02 (h=0.05 at 20 bp).", ""]
for s, title in (("test_all", "Whole test period 2019-2026 (with COVID)"),
                 ("test_excl_covid", "Test period without the COVID window (options starting 2020-01-15..2020-06-30 removed)")):
    out += [f"## {title}", ""]
    for k in ("0.0", "5.0", "20.0"):
        out += [f"### Cost {float(k):g} bp", "", "| Hedge | Daily | Regime-aware | Band |", "|---|---|---|---|"]
        for h in names:
            cell = {r["strategy"]: f"{float(r['rmse_bp']):.1f} / {float(r['es99_bp']):.1f}" for r in rows
                    if r["sample"] == s and r["kappa_bp"] == k and r["hedge"] == h}
            out.append(f"| {names[h]} | {cell['fixed']} | {cell['regime']} | {cell['band']} |")
        out.append("")
(ROOT / "hedging_error_es99_all_models.md").write_text("\n".join(out))
print("\n".join(out))
