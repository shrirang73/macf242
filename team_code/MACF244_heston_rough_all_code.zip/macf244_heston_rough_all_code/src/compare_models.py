"""Model comparison from SAVED results only (no new pricing or hedging runs).

Hedging (13 hedges, NIFTY 1-month ATM calls, test 2019-2026, rules picked on 2010-2018):
  H1 uncertainty: paired moving-block bootstrap CIs for differences in RMSE and ES99/ES95
  H2 tail risk: VaR95/99, ES95/99, worst, mean of 5 worst, dates behind the worst 1%
  H3 stress: COVID window, VIX-stress / calm, the three 20%+ falls
  + variance reduction vs unhedged, win rates, yearly ranks, rank stability over 18 settings
Pricing (7 models, traded 3-month NIFTY calls, test 2019-2026):
  P1 error breakdown: bias, MAE, RMSE, P95/P99 |error|, % overpriced (vol pts and bp of F),
     largest over/underpricing, by strike
  P2 uncertainty: day-block bootstrap CIs for RMSE differences
  + win rates, yearly ranks

Needs: all backtest_heston / rough runs, their backtest_analysis, compare_hedges --name comparison_all
(all 13 hedges) and pricing_test. Usage: python -m src.compare_models
Writes results/model_comparison/model_comparison_report.md
"""
from pathlib import Path
import csv
import numpy as np
import pandas as pd
from . import backtest_analysis as ba, backtest_real as bt, heston as hs, fo_data as fd
from .upstream import PROJECT_ROOT

BP = 1e4
B, SEED = 1000, 7
ROOT = PROJECT_ROOT / "results" / "backtest_heston"
OUT = PROJECT_ROOT / "results" / "model_comparison"
COVID = ("2020-01-15", "2020-06-30")
H = {"bs": "Black-Scholes", "heston": "Heston delta (fixed)", "heston_mv": "Heston min-var (fixed)",
     "heston_roll252": "Heston delta, 12-month", "heston_mv_roll252": "Heston min-var, 12-month",
     "heston_roll126": "Heston delta, 6-month", "heston_mv_roll126": "Heston min-var, 6-month",
     "heston_rollexp": "Heston delta, expanding", "heston_mv_rollexp": "Heston min-var, expanding",
     "rough_a1": "alpha=1 delta", "rough_mv_a1": "alpha=1 min-var", "rough": "Rough delta", "rough_mv": "Rough min-var"}
DAILY = "fixed/every=1"
KAPPA = 5 / BP
out = []
w = out.append


def mbb(n, L, seed=SEED):
    rng = np.random.default_rng(seed)
    nb = int(np.ceil(n / L))
    st = rng.integers(0, n - L + 1, size=(B, nb))
    idx = (st[:, :, None] + np.arange(L)[None, None, :]).reshape(B, -1)[:, :n]
    return idx


def es(loss, q):
    v = np.quantile(loss, q)
    return loss[loss >= v].mean()


def es_rows(loss_mat, q):
    """ES for each row of a (B, n) loss matrix."""
    v = np.quantile(loss_mat, q, axis=1, keepdims=True)
    m = loss_mat >= v
    return (loss_mat * m).sum(1) / m.sum(1)


def ci(x):
    lo, hi = np.percentile(x, [2.5, 97.5])
    return lo, hi


def sig(lo, hi):
    return "**" if lo > 0 or hi < 0 else ""


def fmt_ci(point, lo, hi):
    s = sig(lo, hi)
    return f"{s}{point:+.1f} [{lo:+.1f}, {hi:+.1f}]{s}"


# ------------------------------------------------------------------ hedging
w("# Model comparison from saved results (no new runs)\n")
w("All hedging numbers: NIFTY 1-month ATM calls, test period 2019-2026, rules picked on 2010-2018 per hedge, "
  "bp of notional. Main setting: daily rebalancing, 5 bp cost. Bootstrap: paired moving-block bootstrap, "
  f"block 42 option-days, {B} resamples; 95% intervals; **bold** = interval excludes 0 (difference is real).\n")
w("# Part A - Hedging\n")

data = {s: {h: ba.load(ROOT / h / "maturity_21", "test", None if s == "all" else COVID) for h in H}
        for s in ("all", "excl")}
SAMPLES = {"all": "with COVID", "excl": "without COVID"}

# A1 headline table
w("## A1. Summary table (daily, 5 bp)\n")
for s in ("all", "excl"):
    d0 = data[s]["bs"]
    e0 = d0["premium"] - d0["payoff"]
    w(f"### Test period {SAMPLES[s]} ({len(e0)} options)\n")
    w("| Hedge | RMSE | Variance reduction vs no hedge | VaR95 | VaR99 | ES95 | ES99 | Worst | Mean of 5 worst | Worst option starts |")
    w("|---|---|---|---|---|---|---|---|---|---|")
    for h, nm in H.items():
        d = data[s][h]
        e = ba.pnl(d, DAILY, KAPPA)
        adj = ba.adjusted(d, DAILY, KAPPA)
        loss = -e
        vr = 1 - np.var(e) / np.var(e0)
        worst_i = int(np.argmax(loss))
        w(f"| {nm} | {np.sqrt(np.mean(adj**2))*BP:.1f} | {vr*100:.1f}% | {np.quantile(loss,.95)*BP:.1f} | "
          f"{np.quantile(loss,.99)*BP:.1f} | {es(loss,.95)*BP:.1f} | {es(loss,.99)*BP:.1f} | {loss.max()*BP:.1f} | "
          f"{np.sort(loss)[-5:].mean()*BP:.1f} | {d['start_dates'][worst_i]} |")
    w("")

# A2 uncertainty vs BS and vs Heston min-var
w("## A2. Are the differences real? (paired block bootstrap, daily, 5 bp)\n")
w("Difference = hedge minus reference, bp. Negative = hedge better (lower error / smaller tail loss).\n")
for ref in ("bs", "heston_mv"):
    for s in ("all", "excl"):
        w(f"### Reference: {H[ref]}, test {SAMPLES[s]}\n")
        w("| Hedge | RMSE difference [95% CI] | ES95 difference [95% CI] | ES99 difference [95% CI] |")
        w("|---|---|---|---|")
        dr = data[s][ref]
        n = len(dr["premium"])
        idx = mbb(n, 42)
        ar = ba.adjusted(dr, DAILY, KAPPA)
        lr = -ba.pnl(dr, DAILY, KAPPA)
        r_rmse = np.sqrt((ar[idx] ** 2).mean(1))
        r_es95, r_es99 = es_rows(lr[idx], .95), es_rows(lr[idx], .99)
        for h, nm in H.items():
            if h == ref:
                continue
            d = data[s][h]
            a = ba.adjusted(d, DAILY, KAPPA)
            l = -ba.pnl(d, DAILY, KAPPA)
            p_rmse = (np.sqrt(np.mean(a**2)) - np.sqrt(np.mean(ar**2))) * BP
            p95 = (es(l, .95) - es(lr, .95)) * BP
            p99 = (es(l, .99) - es(lr, .99)) * BP
            b_rmse = (np.sqrt((a[idx] ** 2).mean(1)) - r_rmse) * BP
            b95 = (es_rows(l[idx], .95) - r_es95) * BP
            b99 = (es_rows(l[idx], .99) - r_es99) * BP
            w(f"| {nm} | {fmt_ci(p_rmse, *ci(b_rmse))} | {fmt_ci(p95, *ci(b95))} | {fmt_ci(p99, *ci(b99))} |")
        w("")

# A3 win rates
w("## A3. Win rates (daily, 5 bp)\n")
w("Share of options where the hedge's cost-adjusted error is smaller in size than the reference's. 50% = no edge.\n")
w("| Hedge | vs Black-Scholes (with COVID) | vs Black-Scholes (without COVID) | vs Heston min-var (with COVID) | vs Heston min-var (without COVID) |")
w("|---|---|---|---|---|")
for h, nm in H.items():
    cells = []
    for ref in ("bs", "heston_mv"):
        for s in ("all", "excl"):
            if h == ref:
                cells.append("-")
                continue
            a = np.abs(ba.adjusted(data[s][h], DAILY, KAPPA))
            r = np.abs(ba.adjusted(data[s][ref], DAILY, KAPPA))
            cells.append(f"{(a < r).mean()*100:.0f}%")
    w(f"| {nm} | " + " | ".join(cells) + " |")
w("")

# A4 yearly ranks
w("## A4. Rank in each year (RMSE, daily, 5 bp; 1 = best of 13)\n")
d_all = data["all"]
years = pd.to_datetime(d_all["bs"]["start_dates"]).year
ys = sorted(set(years))
rmse_y = {h: [] for h in H}
for y in ys:
    m = years == y
    for h in H:
        a = ba.adjusted(d_all[h], DAILY, KAPPA)[m]
        rmse_y[h].append(np.sqrt(np.mean(a**2)) * BP)
ranks = {h: [] for h in H}
for j in range(len(ys)):
    order = sorted(H, key=lambda h: rmse_y[h][j])
    for r, h in enumerate(order, 1):
        ranks[h].append(r)
w("| Hedge | " + " | ".join(str(y) for y in ys) + " | Years better than BS | Average rank |")
w("|---|" + "---|" * (len(ys) + 2))
for h, nm in H.items():
    better = sum(rmse_y[h][j] < rmse_y["bs"][j] for j in range(len(ys))) if h != "bs" else "-"
    w(f"| {nm} | " + " | ".join(str(r) for r in ranks[h]) + f" | {better} | {np.mean(ranks[h]):.1f} |")
w(f"\nOptions per year: " + ", ".join(f"{y}: {(years == y).sum()}" for y in ys) + " (2026 to 18 Sep).\n")

# A5 rank stability across 18 settings
w("## A5. Rank stability across all 18 settings (3 costs x 3 strategies x with/without COVID)\n")
rows = list(csv.DictReader(open(ROOT / "comparison_all.csv")))
stab = {h: {"rmse": [], "es99": [], "beat_rmse": 0, "beat_es": 0} for h in H}
for s in ("test_all", "test_excl_covid"):
    for k in ("0.0", "5.0", "20.0"):
        for st in ("fixed", "regime", "band"):
            sel = {r["hedge"]: r for r in rows if r["sample"] == s and r["kappa_bp"] == k and r["strategy"] == st}
            for key, col in (("rmse", "rmse_bp"), ("es99", "es99_bp")):
                order = sorted(sel, key=lambda h: float(sel[h][col]))
                for r_, h in enumerate(order, 1):
                    stab[h][key].append(r_)
            for h in H:
                if h != "bs":
                    stab[h]["beat_rmse"] += float(sel[h]["rmse_bp"]) < float(sel["bs"]["rmse_bp"])
                    stab[h]["beat_es"] += float(sel[h]["es99_bp"]) < float(sel["bs"]["es99_bp"])
w("| Hedge | Avg rank RMSE | Best-worst rank RMSE | Avg rank ES99 | Best-worst rank ES99 | Settings beating BS on RMSE | Settings beating BS on ES99 |")
w("|---|---|---|---|---|---|---|")
for h in sorted(H, key=lambda h: np.mean(stab[h]["rmse"])):
    t = stab[h]
    b1 = "-" if h == "bs" else f"{t['beat_rmse']}/18"
    b2 = "-" if h == "bs" else f"{t['beat_es']}/18"
    w(f"| {H[h]} | {np.mean(t['rmse']):.1f} | {min(t['rmse'])}-{max(t['rmse'])} | {np.mean(t['es99']):.1f} | "
      f"{min(t['es99'])}-{max(t['es99'])} | {b1} | {b2} |")
w("")

# A6 tail drivers
w("## A6. What drives the tail: start months of the worst 1% of options (daily, 5 bp, with COVID)\n")
for h in ("bs", "heston_mv", "rough_mv", "rough"):
    d = d_all[h]
    loss = -ba.pnl(d, DAILY, KAPPA)
    k = max(1, int(np.ceil(0.01 * len(loss))))
    worst = np.argsort(loss)[-k:]
    months = pd.Series(pd.to_datetime(d["start_dates"][worst]).strftime("%Y-%m")).value_counts().sort_index()
    w(f"- **{H[h]}** ({k} options): " + ", ".join(f"{m} x{c}" for m, c in months.items()))
w("")
for h in ("bs", "heston_mv"):
    d = data["excl"][h]
    loss = -ba.pnl(d, DAILY, KAPPA)
    k = max(1, int(np.ceil(0.01 * len(loss))))
    worst = np.argsort(loss)[-k:]
    months = pd.Series(pd.to_datetime(d["start_dates"][worst]).strftime("%Y-%m")).value_counts().sort_index()
    w(f"- **{H[h]}, without COVID** ({k} options): " + ", ".join(f"{m} x{c}" for m, c in months.items()))
w("")

# A7 stress
w("## A7. Stress windows (daily, 5 bp; RMSE / worst loss, bp)\n")
panel = bt.load_panel()
dates_all = pd.to_datetime(d_all["bs"]["start_dates"])
q75 = panel.loc[dates_all, "vix_q75"].to_numpy()
covid = ((d_all["bs"]["start_dates"] >= COVID[0]) & (d_all["bs"]["start_dates"] <= COVID[1]))
wins = {"COVID window (Jan-Jun 2020)": ("test", covid),
        "VIX stress, excl. COVID": ("test", (q75 == 1) & ~covid),
        "Calm (VIX below 75th pct)": ("test", q75 == 0)}
tr = {h: ba.load(ROOT / h / "maturity_21", "train") for h in H}
tr_dates = tr["bs"]["start_dates"]
wins["Fall 2010-11 (-28%), in-sample"] = ("train", (tr_dates >= "2010-11-05") & (tr_dates <= "2011-12-20"))
wins["Fall 2015-16 (-23%), in-sample"] = ("train", (tr_dates >= "2015-03-03") & (tr_dates <= "2016-02-25"))
wins["COVID fall Jan-Mar 2020 (-38%)"] = ("test", (d_all["bs"]["start_dates"] >= "2020-01-14") & (d_all["bs"]["start_dates"] <= "2020-03-23"))
w("| Hedge | " + " | ".join(f"{k} (n={v[1].sum()})" for k, v in wins.items()) + " |")
w("|---|" + "---|" * len(wins))
for h, nm in H.items():
    cells = []
    for k, (per, m) in wins.items():
        d = d_all[h] if per == "test" else tr[h]
        e = ba.pnl(d, DAILY, KAPPA)[m]
        a = ba.adjusted(d, DAILY, KAPPA)[m]
        cells.append(f"{np.sqrt(np.mean(a**2))*BP:.0f} / {(-e).max()*BP:.0f}")
    w(f"| {nm} | " + " | ".join(cells) + " |")
w("\nIn the 2010-2018 falls the monthly-updated hedges use the fixed 2010-2018 parameters (they were only re-estimated in the test period), so they equal the fixed versions there.\n")

# ------------------------------------------------------------------ pricing
w("# Part B - Pricing (traded NIFTY calls, ~3 months to expiry, test 2019-2026)\n")
d = pd.read_csv(PROJECT_ROOT / "results" / "pricing_test" / "smile_3m.csv", parse_dates=["date"])
d = d[d.period == "test"].sort_values(["date", "strike"]).reset_index(drop=True)
tau = d.n.to_numpy() / fd.YEAR; k = d.m.to_numpy(); v = d.vix.to_numpy() ** 2
month = d.date.dt.to_period("M").astype(str)
for name, folder in (("heston_12m", "heston_roll252"), ("heston_6m", "heston_roll126"), ("heston_exp", "heston_rollexp")):
    P = pd.read_csv(ROOT / folder / "maturity_21" / "monthly_params.csv").set_index("month")
    price = np.empty(len(d))
    for m in month.unique():
        sel = (month == m).to_numpy(); r = P.loc[m]
        price[sel] = hs.heston_call(1.0, k[sel], tau[sel], v[sel], hs.HestonParams(r.kappa, r.theta, r.sigma, r.rho))
    d[name] = price
    d[name + "_iv"] = [fd.implied_vol(p, 1.0, kk, t) for p, kk, t in zip(price, k, tau)]
M = {"bs": "Black-Scholes", "heston": "Heston, fixed 2010-18", "heston_12m": "Heston, 12-month", "heston_6m": "Heston, 6-month",
     "heston_exp": "Heston, expanding", "rough_a1": "alpha=1 control", "rough": "Rough Heston"}
for m in M:
    d[m + "_ev"] = (d[m + "_iv"] - d.market_iv) * 100     # vol pts
    d[m + "_ep"] = (d[m] - d.market) * BP                 # bp of F
w("Error = model minus market. vol pts = implied-volatility points; bp = basis points of the futures price. "
  "Each model uses only that day's India VIX (and its own parameters); none is fitted to option prices.\n")
for title, g in (("ATM call (the paper's option), one per day", d[d.atm]), ("All traded calls, strikes 0.90-1.10 x futures", d)):
    w(f"## B1. Error breakdown: {title} ({len(g)} options, {g.date.nunique()} days)\n")
    w("| Model | Bias vol | MAE vol | RMSE vol | P95 abs vol | P99 abs vol | Overpriced | Bias bp | RMSE bp | P99 abs bp |")
    w("|---|---|---|---|---|---|---|---|---|---|")
    for m in sorted(M, key=lambda m: np.sqrt(np.nanmean(g[m + "_ev"] ** 2))):
        ev, ep = g[m + "_ev"], g[m + "_ep"]
        w(f"| {M[m]} | {ev.mean():+.2f} | {ev.abs().mean():.2f} | {np.sqrt(np.nanmean(ev**2)):.2f} | "
          f"{ev.abs().quantile(.95):.2f} | {ev.abs().quantile(.99):.2f} | {(ev > 0).mean()*100:.0f}% | "
          f"{ep.mean():+.1f} | {np.sqrt(np.mean(ep**2)):.1f} | {ep.abs().quantile(.99):.1f} |")
    w("")
w("## B2. Largest single mispricings (all strikes, vol pts)\n")
w("| Model | Largest overpricing (date, K/F, market IV) | Largest underpricing (date, K/F, market IV) |")
w("|---|---|---|")
for m, nm in M.items():
    i, j = d[m + "_ev"].idxmax(), d[m + "_ev"].idxmin()
    w(f"| {nm} | {d.loc[i, m+'_ev']:+.1f} ({d.loc[i,'date'].date()}, {d.loc[i,'m']:.2f}, {d.loc[i,'market_iv']*100:.1f}%) | "
      f"{d.loc[j, m+'_ev']:+.1f} ({d.loc[j,'date'].date()}, {d.loc[j,'m']:.2f}, {d.loc[j,'market_iv']*100:.1f}%) |")
w("")
w("## B3. Error by strike (mean error / mean absolute error, vol pts)\n")
by = d.assign(b=pd.cut(d.m, [0.899, 0.95, 0.99, 1.01, 1.05, 1.101], labels=["0.90-0.95", "0.95-0.99", "0.99-1.01", "1.01-1.05", "1.05-1.10"]))
w("| K/F | Options | Market IV % | " + " | ".join(M.values()) + " |")
w("|---|---|---|" + "---|" * len(M))
for b, g in by.groupby("b", observed=True):
    w(f"| {b} | {len(g)} | {g.market_iv.mean()*100:.1f} | " + " | ".join(f"{g[m+'_ev'].mean():+.2f} / {g[m+'_ev'].abs().mean():.2f}" for m in M) + " |")
w("")

# B4 uncertainty: day-block bootstrap of RMSE differences
w("## B4. Are the pricing differences real? (block bootstrap over days, block 63 trading days)\n")
w("Difference in RMSE (vol pts), model minus reference; negative = model prices better.\n")
days = np.array(sorted(d.date.unique()))
nd = len(days)
idx = mbb(nd, 63)
for title, g in (("ATM", d[d.atm]), ("All strikes", d)):
    agg = {m: g.groupby("date")[m + "_ev"].agg(lambda x: np.nansum(x**2)).reindex(days).to_numpy() for m in M}
    cnt = g.groupby("date").size().reindex(days).to_numpy()
    def rm(m, ix=None):
        if ix is None:
            return np.sqrt(agg[m].sum() / cnt.sum())
        return np.sqrt(agg[m][ix].sum(1) / cnt[ix].sum(1))
    w(f"### {title}\n")
    w("| Model | vs Black-Scholes [95% CI] | vs Rough Heston [95% CI] |")
    w("|---|---|---|")
    for m, nm in M.items():
        cells = []
        for ref in ("bs", "rough"):
            if m == ref:
                cells.append("-")
                continue
            p = rm(m) - rm(ref)
            bdiff = rm(m, idx) - rm(ref, idx)
            lo, hi = ci(bdiff)
            s = sig(lo, hi)
            cells.append(f"{s}{p:+.2f} [{lo:+.2f}, {hi:+.2f}]{s}")
        w(f"| {nm} | " + " | ".join(cells) + " |")
    w("")

# B5 win rates and yearly ranks (ATM)
w("## B5. Win rates and yearly ranks (ATM call)\n")
a = d[d.atm].copy()
w("| Model | Days beating BS | Days beating Rough Heston | " + " | ".join(str(y) for y in sorted(a.date.dt.year.unique())) + " | Avg rank |")
yrs = sorted(a.date.dt.year.unique())
yr_rmse = {m: [np.sqrt(np.nanmean(a[a.date.dt.year == y][m + "_ev"] ** 2)) for y in yrs] for m in M}
yr_rank = {m: [] for m in M}
for j in range(len(yrs)):
    for r, m in enumerate(sorted(M, key=lambda m: yr_rmse[m][j]), 1):
        yr_rank[m].append(r)
w("|---|---|---|" + "---|" * (len(yrs) + 1))
for m in sorted(M, key=lambda m: np.mean(yr_rank[m])):
    c1 = "-" if m == "bs" else f"{(a[m+'_ev'].abs() < a['bs_ev'].abs()).mean()*100:.0f}%"
    c2 = "-" if m == "rough" else f"{(a[m+'_ev'].abs() < a['rough_ev'].abs()).mean()*100:.0f}%"
    w(f"| {M[m]} | {c1} | {c2} | " + " | ".join(str(r) for r in yr_rank[m]) + f" | {np.mean(yr_rank[m]):.1f} |")
w("\nYearly ranks: 1 = lowest ATM RMSE of the 7 models in that year.\n")

OUT.mkdir(parents=True, exist_ok=True)
(OUT / "model_comparison_report.md").write_text("\n".join(out) + "\n")
print("\n".join(out))
