"""Pricing comparison of all model variants on traded NIFTY calls, test period 2019-2026.
Adds Heston with monthly-updated parameters (12-month, 6-month, expanding windows) to the
models already in results/pricing_test/smile_3m.csv. A Heston variant prices options on a
day in month M with month M's parameters (estimated on data before M).

Needs: python -m src.pricing_test and the monthly Heston runs (backtest_heston_rolling
--window 252, 126 and 0). Usage: python -m src.pricing_all_models
Writes results/pricing_test/all_models.md.
"""
import numpy as np, pandas as pd
from . import heston as hs, fo_data as fd
from .metrics import block_bootstrap_se
from .upstream import PROJECT_ROOT
R = str(PROJECT_ROOT / "results") + "/"
out = []
w = out.append
d = pd.read_csv(R + "pricing_test/smile_3m.csv", parse_dates=["date"])
d = d[d.period == "test"].sort_values(["date", "strike"]).reset_index(drop=True)
tau = d.n.to_numpy() / fd.YEAR; k = d.m.to_numpy(); v = d.vix.to_numpy() ** 2
month = d.date.dt.to_period("M").astype(str)
for name, folder in (("heston_12m", "heston_roll252"), ("heston_6m", "heston_roll126"), ("heston_exp", "heston_rollexp")):
    P = pd.read_csv(R + f"backtest_heston/{folder}/maturity_21/monthly_params.csv").set_index("month")
    price = np.empty(len(d))
    for m in month.unique():
        sel = (month == m).to_numpy()
        if m not in P.index:   # option days in months with no option start (none expected)
            raise SystemExit(f"no params for {m}")
        r = P.loc[m]
        price[sel] = hs.heston_call(1.0, k[sel], tau[sel], v[sel], hs.HestonParams(r.kappa, r.theta, r.sigma, r.rho))
    d[name] = price
    d[name + "_iv"] = [fd.implied_vol(p, 1.0, kk, t) for p, kk, t in zip(price, k, tau)]
M = {"bs": "Black-Scholes", "heston": "Heston, fixed 2010-18", "heston_12m": "Heston, 12-month", "heston_6m": "Heston, 6-month",
     "heston_exp": "Heston, expanding", "rough_a1": "alpha=1 control", "rough": "Rough Heston"}
def table(g, title, block):
    e = {m: (g[m + "_iv"] - g.market_iv) * 100 for m in M}
    base = (e["bs"] ** 2).to_numpy()
    rows = []
    for m in M:
        x = e[m]; sq = (x ** 2).to_numpy(); dd = sq - base
        shape = x - x.groupby(g.date).transform("mean")
        z = dd.mean() / block_bootstrap_se(dd, block) if m != "bs" else 0.0
        rows.append((M[m], x.mean(), np.sqrt(np.nanmean(sq)), np.sqrt((shape ** 2).mean()),
                     100 * dd.mean() / base.mean() if m != "bs" else 0.0, z, int(x.isna().sum())))
    rows.sort(key=lambda r: r[2])
    w(f"\n## {title} ({len(g)} options, {g.date.nunique()} days)\n")
    w("| Rank | Model | Bias (vol pts) | RMSE (vol pts) | Shape RMSE | vs BS (sq. error) | z |")
    w("|---|---|---|---|---|---|---|")
    for i, r in enumerate(rows, 1):
        w(f"| {i} | {r[0]} | {r[1]:+.2f} | {r[2]:.2f} | {r[3]:.2f} | {r[4]:+.0f}% | {r[5]:+.2f} |" + (f" ({r[6]} no IV)" if r[6] else ""))
w("# Option pricing: all models, traded NIFTY calls, test period 2019-2026")
w("\nError = model implied vol - market implied vol (vol points). Shape RMSE = after removing each day's average error. "
      "vs BS = change in mean squared error vs Black-Scholes; z from a moving-block bootstrap (|z|>2 ~ significant). Ranked by RMSE.")
table(d[d.atm].reset_index(drop=True), "ATM call, ~3 months (the paper's option)", 63)
table(d, "All traded calls, strikes 0.90-1.10 x futures", 63 * 18)
by = d.assign(b=pd.cut(d.m, [0.899, 0.95, 0.99, 1.01, 1.05, 1.101], labels=["0.90-0.95", "0.95-0.99", "0.99-1.01", "1.01-1.05", "1.05-1.10"]))
w("\n## Mean error by strike (vol pts)\n\n| K/F | Market IV % | " + " | ".join(M.values()) + " |\n|" + "---|" * (2 + len(M)))
for b, g in by.groupby("b", observed=True):
    w(f"| {b} | {g.market_iv.mean()*100:.1f} | " + " | ".join(f"{((g[m+'_iv']-g.market_iv)*100).mean():+.2f}" for m in M) + " |")

(PROJECT_ROOT / "results" / "pricing_test" / "all_models.md").write_text("\n".join(out) + "\n")
print("\n".join(out))
