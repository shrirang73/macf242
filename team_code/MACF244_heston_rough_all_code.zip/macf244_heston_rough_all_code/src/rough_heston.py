"""Rough Heston model: price, delta and minimum-variance delta, plus estimation.

Rough Heston = the rough Hawkes--Heston model of the base paper WITHOUT jumps
(El Euch & Rosenbaum 2019). alpha = 1 gives the classical Heston model.

    dS/S = sqrt(V) dW,
    V_t  = V_0 + int_0^t K(t-s) [lam (theta - V_s) ds + nu sqrt(V_s) dB_s],
    K(t) = t^(alpha-1) / Gamma(alpha),   d<W, B> = rho dt.

Forward-variance form. With xi_t(u) = E[V_u | F_t], the forward variances are
martingales, d xi_t(u) = r(u - t) nu sqrt(V_t) dB_t, where r is the resolvent
of lam*K: R(x) = int_0^x r solves D^alpha R = 1 - lam R, R(0) = 0
(alpha = 1: r(x) = exp(-lam x)). The characteristic function of X_T = ln(S_T/S_t) is

    E[exp(i a X_T) | F_t] = exp( int_0^tau xi_t(T - s) G(a, psi(a, s)) ds ),
    D^alpha psi = G(a, psi) - lam psi,   psi(a, 0) = 0,
    G(a, x) = (-a^2 - i a)/2 + i a rho nu x + nu^2 x^2 / 2.

Approximation used on NIFTY: the forward-variance curve over the option's life
is taken FLAT at today's (VIX/100)^2, so log CF = xi * I(a, tau) with
I(a, tau) = int_0^tau G(a, psi(a, s)) ds.

Hedges (r = 0):
    delta    dC/dS = P1                              (Gil-Pelaez, as in heston.py)
    minvar   dC/dS + (rho nu / S) int_0^tau dC/dxi(t+s) r(s) ds,
  which is d<C,S>/d<S> (V cancels). The functional derivative of log CF at
  xi(t+s) is G(a, psi(a, tau - s)), so the weighted sensitivity uses
  J(a, tau) = int_0^tau G(a, psi(a, tau - s)) r(s) ds. For alpha = 1, J = D(tau)
  of Heston and minvar equals heston.minvar_delta with v = theta (checked in tests).

Numerics: fractional Riccati by the Adams predictor--corrector scheme
(Diethelm et al. 2002), vectorised over the frequency grid; Gil-Pelaez integrals
by the midpoint rule on [0, A(tau)].
"""

from __future__ import annotations

from dataclasses import dataclass
from math import gamma

import numpy as np

CHUNK = 400  # option-days per integration batch (memory control)


@dataclass(frozen=True)
class RoughParams:
    alpha: float  # roughness: kernel t^(alpha-1)/Gamma(alpha); 1 = Heston
    lam: float    # mean reversion
    nu: float     # vol of vol
    rho: float    # correlation of price and variance shocks

    def as_dict(self) -> dict:
        return {"alpha": self.alpha, "lam": self.lam, "nu": self.nu, "rho": self.rho}


# ---------------------------------------------------------------------------
# Fractional Adams scheme for y(t) = I^alpha f(y)(t), y(0) = 0
# ---------------------------------------------------------------------------


def adams(f, alpha: float, h: float, n: int, shape) -> np.ndarray:
    """y on t_k = k h, k = 0..n, for y = (1/Gamma(alpha)) int (t-s)^(alpha-1) f(y(s)) ds."""
    y0 = np.zeros(shape, dtype=complex)
    ys = np.empty((n + 1,) + tuple(np.shape(y0)), dtype=complex)
    fs = np.empty_like(ys)
    ys[0] = y0
    fs[0] = f(y0)
    ca = h**alpha / gamma(alpha + 2.0)
    cb = h**alpha / gamma(alpha + 1.0)
    for k in range(n):
        j = np.arange(k + 1)
        b = cb * ((k + 1 - j) ** alpha - (k - j) ** alpha)
        a = ca * ((k - j + 2.0) ** (alpha + 1) + (k - j + 0.0) ** (alpha + 1)
                  - 2.0 * (k - j + 1.0) ** (alpha + 1))
        a[0] = ca * (k ** (alpha + 1) - (k - alpha) * (k + 1.0) ** alpha)
        hist = fs[:k + 1].reshape(k + 1, -1)
        pred = (b @ hist).reshape(np.shape(y0))
        ys[k + 1] = (a @ hist).reshape(np.shape(y0)) + ca * f(pred)
        fs[k + 1] = f(ys[k + 1])
    return ys


def resolvent_integral(alpha: float, lam: float, h: float, n: int) -> np.ndarray:
    """R(t_k) = int_0^{t_k} r, from D^alpha R = 1 - lam R (alpha = 1: (1-e^{-lam t})/lam).

    Same Adams weights as ``adams`` but with the corrector solved implicitly
    (the equation is linear), so it is stable for any lam * h^alpha.
    """
    R = np.zeros(n + 1)
    F = np.zeros(n + 1)
    F[0] = 1.0
    ca = h**alpha / gamma(alpha + 2.0)
    for k in range(n):
        j = np.arange(k + 1)
        a = ca * ((k - j + 2.0) ** (alpha + 1) + (k - j + 0.0) ** (alpha + 1)
                  - 2.0 * (k - j + 1.0) ** (alpha + 1))
        a[0] = ca * (k ** (alpha + 1) - (k - alpha) * (k + 1.0) ** alpha)
        R[k + 1] = (a @ F[:k + 1] + ca) / (1.0 + ca * lam)
        F[k + 1] = 1.0 - lam * R[k + 1]
    return R


# ---------------------------------------------------------------------------
# Riccati quantities I(a, tau) and J(a, tau) on a frequency grid
# ---------------------------------------------------------------------------


def riccati_IJ(a: np.ndarray, tau: float, p: RoughParams, steps: int = 200):
    """I(a,tau) = int_0^tau G(psi(s)) ds and J(a,tau) = int_0^tau G(psi(tau-s)) dR(s)."""
    a = np.asarray(a, dtype=complex)
    h = tau / steps

    def G(x):
        return 0.5 * (-a * a - 1j * a) + 1j * a * p.rho * p.nu * x + 0.5 * p.nu**2 * x * x

    psi = adams(lambda x: G(x) - p.lam * x, p.alpha, h, steps, a.shape)
    g = G(psi)                                     # (steps+1, n_a)
    I = h * (0.5 * g[0] + g[1:-1].sum(axis=0) + 0.5 * g[-1])
    R = resolvent_integral(p.alpha, p.lam, h, steps)
    dR = np.diff(R)                                # mass of r on [s_j, s_{j+1}]
    gm = 0.5 * (g[::-1][:-1] + g[::-1][1:])        # G(psi(tau - s)) at interval midpoints
    J = (dR[:, None] * gm).sum(axis=0)
    return I, J


class RoughPricer:
    """Price / delta / min-variance delta for flat forward variance xi.

    Pre-computes the Riccati integrals for each time to maturity in ``taus``
    (years) once; then any (S/K, xi) pair is a cheap quadrature.
    """

    def __init__(self, p: RoughParams, taus, xi_min: float, da: float = 0.25,
                 tail: float = 40.0, steps: int = 200):
        self.p = p
        self.grids = {}
        for tau in np.unique(np.asarray(taus, dtype=float)):
            amax = np.sqrt(2.0 * tail / (xi_min * tau))
            n = int(np.ceil(amax / da))
            a = (np.arange(n) + 0.5) * da
            I2, J2 = riccati_IJ(a, tau, p, steps)
            I1, J1 = riccati_IJ(a - 1j, tau, p, steps)
            self.grids[float(tau)] = (a, da, I1, J1, I2, J2)

    def quantities(self, s, tau: float, xi) -> dict:
        """s = S/K (K = 1), xi = flat forward variance; 1-d arrays for one tau."""
        a, da, I1, J1, I2, J2 = self.grids[float(tau)]
        s = np.atleast_1d(np.asarray(s, dtype=float))
        xi = np.atleast_1d(np.asarray(xi, dtype=float))
        out = {k: np.empty(s.size) for k in ("p1", "p2", "dp1", "dp2")}
        for lo in range(0, s.size, CHUNK):
            sl = slice(lo, lo + CHUNK)
            x = np.log(s[sl])[:, None]
            v = xi[sl][:, None]
            kern = np.exp(1j * a[None, :] * x) / (1j * a[None, :]) * da / np.pi
            f1 = np.exp(v * I1[None, :])
            f2 = np.exp(v * I2[None, :])
            out["p1"][sl] = 0.5 + np.real(kern * f1).sum(axis=1)
            out["p2"][sl] = 0.5 + np.real(kern * f2).sum(axis=1)
            out["dp1"][sl] = np.real(kern * f1 * J1[None, :]).sum(axis=1)
            out["dp2"][sl] = np.real(kern * f2 * J2[None, :]).sum(axis=1)
        call = s * out["p1"] - out["p2"]
        wvega = s * out["dp1"] - out["dp2"]
        minvar = out["p1"] + self.p.rho * self.p.nu / s * wvega
        return {"call": call, "delta": out["p1"], "wvega": wvega, "minvar": minvar}


# ---------------------------------------------------------------------------
# Estimation (training data only)
# ---------------------------------------------------------------------------


def roughness_H(log_vol: np.ndarray, lags=range(1, 51), q: float = 2.0) -> float:
    """Gatheral-Jaisson-Rosenbaum: mean |dlog vol over D|^q ~ D^(qH); returns H."""
    x = np.asarray(log_vol, dtype=float)
    lags = np.asarray(list(lags))
    m = [np.mean(np.abs(x[l:] - x[:-l]) ** q) for l in lags]
    return float(np.polyfit(np.log(lags), np.log(m), 1)[0] / q)


def garman_klass_logvol(o, h, l, c) -> np.ndarray:
    """0.5 * log of the Garman-Klass daily variance estimate from OHLC."""
    gk = 0.5 * np.log(h / l) ** 2 - (2 * np.log(2) - 1) * np.log(c / o) ** 2
    if np.any(gk <= 0):
        raise ValueError("non-positive Garman-Klass variance")
    return 0.5 * np.log(gk)


def vix_variogram_shape(alpha: float, lam: float, lags_days, window_days: int = 21,
                        year: int = 252, sub: int = 4, horizon_years: float = 6.0) -> np.ndarray:
    """Model variogram of VIX^2 divided by nu^2 * mean(V).

    VIX^2_t ~ (1/Delta) int_t^{t+Delta} xi_t(u) du  =>  VIX^2_t - mean = int w(t-s) nu sqrt(V) dB_s,
    w(a) = (R(a+Delta) - R(a)) / Delta, and
    E[(VIX^2_{t+h} - VIX^2_t)^2] / (nu^2 E V) = int_0^inf (w(a+h) - w(a))^2 da + int_0^h w(a)^2 da.
    """
    h = 1.0 / (year * sub)
    n = int(horizon_years * year * sub)
    R = resolvent_integral(alpha, lam, h, n + window_days * sub)
    d = window_days * sub
    w = (R[d:d + n + 1] - R[:n + 1]) / (window_days / year)
    out = []
    for lag in lags_days:
        k = lag * sub
        diff = w[k:] - w[:-k]
        out.append(h * np.sum(diff**2) + h * np.sum(w[:k] ** 2))
    return np.array(out)


def fit_lam_nu(vix_pct: np.ndarray, alpha: float, lags_days=range(1, 127),
               lam_grid=None, window_days: int = 21) -> tuple[float, float, dict]:
    """Fit lam, nu to the empirical variogram of VIX^2 (log least squares), alpha fixed."""
    v = (np.asarray(vix_pct, dtype=float) / 100.0) ** 2
    lags = np.asarray(list(lags_days))
    emp = np.array([np.mean((v[l:] - v[:-l]) ** 2) for l in lags])
    vbar = float(v.mean())
    if lam_grid is None:
        lam_grid = np.exp(np.linspace(np.log(0.2), np.log(100.0), 61))
    best = None
    for lam in lam_grid:
        shape = vix_variogram_shape(alpha, lam, lags, window_days)
        log_nu2 = np.mean(np.log(emp) - np.log(vbar * shape))
        loss = float(np.sum((np.log(emp) - log_nu2 - np.log(vbar * shape)) ** 2))
        if best is None or loss < best[0]:
            best = (loss, float(lam), float(np.sqrt(np.exp(log_nu2))))
    loss, lam, nu = best
    edge = lam in (float(lam_grid[0]), float(lam_grid[-1]))
    return lam, nu, {"loss": loss, "mean_variance": vbar, "lam_at_grid_edge": edge}
