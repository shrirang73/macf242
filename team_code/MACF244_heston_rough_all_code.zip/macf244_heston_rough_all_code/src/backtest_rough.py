"""NIFTY backtest with ROUGH Heston hedges (rough Hawkes--Heston without jumps).

Same design as ``backtest_heston.py`` (premium = BS with VIX, rules, placebos,
costs later); only the target hedge changes:

    rough        rough Heston delta dC/dS              alpha estimated (~0.55)
    rough_mv     rough Heston minimum-variance delta   alpha estimated
    rough_a1     same framework with alpha = 1         (Heston, control)
    rough_mv_a1  same framework with alpha = 1         (Heston, control)

The alpha = 1 versions use exactly the same estimation and approximations, so
"rough_mv" vs "rough_mv_a1" isolates the effect of roughness.

Estimation, training period only (2010-07-20 .. 2018-12-31):
  * alpha = H + 1/2, H from the log-volatility variogram of the Garman--Klass
    daily range volatility of NIFTY (OHLC, data/processed/nifty50.csv),
    lags 1-50 days, q = 2 (Gatheral, Jaisson & Rosenbaum 2018).
  * lam, nu: fit of the model variogram of VIX^2 (VIX^2 = 21-day average of
    forward variance) to the empirical one, lags 1-126 days, alpha fixed.
  * rho: as in heston.estimate_params.
Approximation: the forward-variance curve is flat at (VIX/100)^2 over each
option's remaining life (VIX gives only one 30-day number per day).

Outputs: results/backtest_heston/<hedge>/maturity_21/ (+ rough_params.json).
Usage: python -m src.backtest_rough
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import backtest_real as bt
from . import heston as hs
from . import rebalancing as rb
from . import rough_heston as rh
from .backtest_heston import OUT
from .upstream import PROJECT_ROOT

OHLC_CSV = PROJECT_ROOT / "data" / "processed" / "nifty50.csv"
LABELS = ["vix_hyst", "vix_q75", "rv21_q75", "ms_filter"]
XI_MIN = 0.08**2  # integration-grid floor, below every VIX value in the data (min 9.15)
TRAIN_END = "2018-12-31"


def estimate(panel: pd.DataFrame) -> dict:
    train = panel[panel["split"] == "train"]
    o = pd.read_csv(OHLC_CSV, parse_dates=["date"]).set_index("date")
    o = o[(o.index >= train.index[0]) & (o.index <= TRAIN_END) & ~o["special_session"].astype(bool)]
    H = rh.roughness_H(rh.garman_klass_logvol(o["open"], o["high"], o["low"], o["close"]))
    rho = hs.estimate_params(train["vix"].to_numpy(), train["nifty"].to_numpy()).rho
    out = {"H": H, "ohlc_days": int(len(o))}
    for tag, alpha in (("rough", H + 0.5), ("a1", 1.0)):
        lam, nu, info = rh.fit_lam_nu(train["vix"].to_numpy(), alpha)
        out[tag] = {"alpha": alpha, "lam": lam, "nu": nu, "rho": rho, **info}
    return out


def targets(stock, vol, p: rh.RoughParams, maturity: int) -> tuple[np.ndarray, np.ndarray]:
    """(delta, minvar) at decision closes k = 0..N-1."""
    taus = (maturity - np.arange(maturity)) / bt.YEAR
    pricer = rh.RoughPricer(p, taus, XI_MIN)
    delta = np.empty((stock.shape[0], maturity))
    minvar = np.empty_like(delta)
    for k in range(maturity):
        q = pricer.quantities(stock[:, k], taus[k], vol[:, k] ** 2)
        delta[:, k], minvar[:, k] = q["delta"], q["minvar"]
    return delta, minvar


def evaluate(panel, period, maturity, hedge_targets: dict) -> dict:
    """hedge_targets: name -> function(stock, vol) -> target array."""
    labels = bt.label_variants(panel, LABELS)
    starts = bt.option_starts(panel, period, maturity)
    stock, vol, lab = bt.build_paths(panel, starts, maturity, labels)
    base = {"start_dates": panel.index[starts].strftime("%Y-%m-%d").to_numpy().astype("U10"),
            "premium": bt.bs_call(1.0, 1.0, maturity / bt.YEAR, vol[:, 0]),
            "payoff": np.maximum(stock[:, -1] - 1.0, 0.0)}
    results = {}
    for name, target in hedge_targets(stock, vol).items():
        if not np.all(np.isfinite(target)):
            raise FloatingPointError(f"non-finite hedge ratios for {name}")
        out = dict(base, target0=target[:, 0])
        for rname, rule, variant in bt.build_rules(list(labels), maturity):
            phi, _ = rb.held_positions(target, rule, lab[variant] if variant is not None else None)
            res = rb.trading_outcome(phi, stock)
            out[f"gain|{rname}"] = res["gain"]
            out[f"notional|{rname}"] = (res["notional_initial"] + res["notional_rebalance"]
                                        + res["notional_terminal"])
            out[f"trades|{rname}"] = res["trades"]
        results[name] = out
    return results


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--maturity", type=int, default=21)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args(argv)
    panel = bt.load_panel()
    est = estimate(panel)
    print(json.dumps(est, indent=2))
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "rough_params.json").write_text(json.dumps(est, indent=2))
    params = {tag: rh.RoughParams(est[tag]["alpha"], est[tag]["lam"], est[tag]["nu"], est[tag]["rho"])
              for tag in ("rough", "a1")}

    def hedge_targets(stock, vol):
        out = {}
        for tag, suffix in (("rough", ""), ("a1", "_a1")):
            d, mv = targets(stock, vol, params[tag], args.maturity)
            out[f"rough{suffix}"], out[f"rough_mv{suffix}"] = d, mv
        return out

    for period in ("train", "test"):
        for name, res in evaluate(panel, period, args.maturity, hedge_targets).items():
            d = args.out / name / f"maturity_{args.maturity}"
            d.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(d / f"per_option_{period}.npz", **res)
            cfg_path = d / "config.json"
            cfg = json.loads(cfg_path.read_text()) if cfg_path.exists() and period == "test" else {
                "maturity_days": args.maturity, "labels": LABELS, "labels_csv": str(bt.LABELS_CSV),
                "year_days": bt.YEAR, "placebo_lag": bt.PLACEBO_LAG, "hedge": name,
                "rough_params": params["a1" if name.endswith("_a1") else "rough"].as_dict(),
                "forward_variance": "flat at (VIX/100)^2", "periods": {}}
            cfg["periods"][period] = {
                "options": int(len(res["premium"])), "first_start": str(res["start_dates"][0]),
                "last_start": str(res["start_dates"][-1]),
                "mean_premium": float(res["premium"].mean()), "mean_payoff": float(res["payoff"].mean()),
                "mean_initial_hedge": float(res["target0"].mean())}
            cfg_path.write_text(json.dumps(cfg, indent=2))
            print(name, period, cfg["periods"][period])


if __name__ == "__main__":
    main()
