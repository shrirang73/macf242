"""Pricing robustness (test period 2019-2026, traded NIFTY calls):
 1. liquidity filter on the saved 3-month results (only actively traded contracts)
 2. the same models on ~1-month contracts (15-28 trading days to expiry)

Needs: the full option data (data/raw/bhavcopy), python -m src.pricing_test, and the
monthly Heston runs (backtest_heston_rolling --window 252, 126, 0).
Usage: python -m src.pricing_robustness
Writes results/pricing_test/robustness.md and smile_1m_test.csv.
"""
import json
import numpy as np
import pandas as pd
from . import pricing_test as pt, fo_data as fd, heston as hs, rough_heston as rh, backtest_real as bt
from . import backtest_heston as bh, backtest_rough as br
from .backtest_options import Market
from .upstream import PROJECT_ROOT

ROOT = PROJECT_ROOT / "results" / "backtest_heston"
M = {"bs": "Black-Scholes", "heston": "Heston, fixed 2010-18", "heston_12m": "Heston, 12-month",
     "heston_6m": "Heston, 6-month", "heston_exp": "Heston, expanding", "rough_a1": "alpha=1 control",
     "rough": "Rough Heston"}
B = 1000
out = []
w = out.append


def collect2(mkt, fo, vix, split, target, lo, hi):
    """pricing_test.collect, plus contracts traded for each call, for any target maturity."""
    _, opt = fd.split_fo(fo)
    if mkt.aliases:
        opt = opt.assign(expiry=opt["expiry"].replace(mkt.aliases))
    calls = opt[(opt["instrument"] == "CE") & (opt["contracts"] > 0)]
    vol = calls.set_index(["date", "expiry", "strike"])["contracts"].to_dict()
    old = (pt.TARGET, pt.LO, pt.HI)
    pt.TARGET, pt.LO, pt.HI = target, lo, hi
    rows = []
    try:
        for day, labels in mkt.expiries.items():
            if day not in vix.index or not np.isfinite(vix[day]):
                continue
            cands = []
            for e in labels:
                actual = mkt.actual_expiry.get(e)
                if actual is None:
                    continue
                n = mkt.days_to(day, actual)
                if lo <= n <= hi and (day, e) in mkt.strikes and (day, e) in mkt.fut_close:
                    cands.append((abs(n - target), n, e))
            if not cands:
                continue
            _, n, e = min(cands)
            f = mkt.fut_close[(day, e)]
            strikes = mkt.strikes[(day, e)]
            atm = float(strikes[np.abs(strikes - f).argmin()])
            for k in strikes:
                m = k / f
                if not (pt.MONEYNESS[0] <= m <= pt.MONEYNESS[1]):
                    continue
                price = mkt.call_close[(day, e, k)]
                iv = fd.implied_vol(price, f, k, n / fd.YEAR)
                if not np.isfinite(iv):
                    continue
                rows.append({"date": day, "n": n, "f": f, "strike": float(k), "m": m, "atm": bool(k == atm),
                             "market": price / f, "market_iv": iv, "vix": vix[day] / 100,
                             "period": split.get(day, "none"), "contracts": vol[(day, e, k)]})
    finally:
        pt.TARGET, pt.LO, pt.HI = old
    return pd.DataFrame(rows)


def add_heston_variants(d):
    tau = d.n.to_numpy() / fd.YEAR; k = d.m.to_numpy(); v = d.vix.to_numpy() ** 2
    month = d.date.dt.to_period("M").astype(str)
    for name, folder in (("heston_12m", "heston_roll252"), ("heston_6m", "heston_roll126"), ("heston_exp", "heston_rollexp")):
        P = pd.read_csv(ROOT / folder / "maturity_21" / "monthly_params.csv").set_index("month")
        price = np.empty(len(d))
        for m in month.unique():
            sel = (month == m).to_numpy(); r = P.loc[m]
            price[sel] = hs.heston_call(1.0, k[sel], tau[sel], v[sel], hs.HestonParams(r.kappa, r.theta, r.sigma, r.rho))
        d[name] = price
        d[name + "_iv"] = [fd.implied_vol(p, 1.0, kk, t) for p, kk, t in zip(price, k, tau)]
    for m in M:
        d[m + "_ev"] = (d[m + "_iv"] - d.market_iv) * 100
    return d


def mbb(n, L, seed=7):
    rng = np.random.default_rng(seed)
    st = rng.integers(0, n - L + 1, size=(B, int(np.ceil(n / L))))
    return (st[:, :, None] + np.arange(L)[None, None, :]).reshape(B, -1)[:, :n]


def ranking(g, title):
    days = np.array(sorted(g.date.unique()))
    idx = mbb(len(days), min(63, len(days)))
    agg = {m: g.groupby("date")[m + "_ev"].agg(lambda x: np.nansum(x ** 2)).reindex(days).to_numpy() for m in M}
    cnt = g.groupby("date").size().reindex(days).to_numpy()
    rm = lambda m, ix=None: np.sqrt(agg[m].sum() / cnt.sum()) if ix is None else np.sqrt(agg[m][ix].sum(1) / cnt[ix].sum(1))
    w(f"### {title} ({len(g)} options, {len(days)} days)\n")
    w("| Rank | Model | Bias (vol pts) | RMSE (vol pts) | vs Black-Scholes [95% CI] | vs Rough Heston [95% CI] |")
    w("|---|---|---|---|---|---|")
    for i, m in enumerate(sorted(M, key=lambda m: rm(m)), 1):
        cells = []
        for ref in ("bs", "rough"):
            if m == ref:
                cells.append("-"); continue
            p = rm(m) - rm(ref); lo, hi = np.percentile(rm(m, idx) - rm(ref, idx), [2.5, 97.5])
            s = "**" if lo > 0 or hi < 0 else ""
            cells.append(f"{s}{p:+.2f} [{lo:+.2f}, {hi:+.2f}]{s}")
        w(f"| {i} | {M[m]} | {g[m+'_ev'].mean():+.2f} | {rm(m):.2f} | " + " | ".join(cells) + " |")
    w("")


nifty = pd.read_csv(PROJECT_ROOT / "data" / "processed" / "nifty50.csv", index_col=0, parse_dates=True)
panel = bt.load_panel()
fo = pt.load_fo_available()
mkt = Market(fo, nifty.index)

w("# Pricing robustness checks (test period 2019-2026, traded NIFTY calls)\n")
w("Error = model minus market implied vol (vol points). Differences in RMSE with 95% intervals from a block "
  f"bootstrap over days (block 63 days, {B} resamples); **bold** = interval excludes 0.\n")

# ---- 1. liquidity filter on the 3-month set
three = collect2(mkt, fo, panel["vix"], panel["split"], 63, 40, 90)
three = three[three.period == "test"]
saved = pd.read_csv(PROJECT_ROOT / "results" / "pricing_test" / "smile_3m.csv", parse_dates=["date"])
saved = saved[saved.period == "test"]
d3 = saved.merge(three[["date", "strike", "contracts"]], on=["date", "strike"], how="left", validate="one_to_one")
assert d3.contracts.notna().all() and len(d3) == len(saved)
d3 = add_heston_variants(d3.sort_values(["date", "strike"]).reset_index(drop=True))
w("## 1. Liquidity filter, ~3-month calls\n")
q = d3.groupby("date").contracts.transform("median")
liquid = d3[d3.contracts >= q]
atm = d3[d3.atm]
atm_thr = atm.groupby(atm.date.dt.year).contracts.transform("median")
atm_liq = atm[atm.contracts >= atm_thr]
w(f"Contracts traded per option: median {d3.contracts.median():.0f}; ATM median {atm.contracts.median():.0f}. "
  "Liquid = at least that day's median contracts (all strikes) / at least that year's median ATM contracts (ATM).\n")
ranking(d3[d3.atm], "ATM, all days (as before)")
ranking(atm_liq, "ATM, liquid days only")
ranking(d3, "All strikes, all contracts (as before)")
ranking(liquid, "All strikes, liquid contracts only (top half by contracts each day)")

# ---- 2. one-month contracts
one = collect2(mkt, fo, panel["vix"], panel["split"], 21, 15, 28)
one = one[one.period == "test"].sort_values(["date", "strike"]).reset_index(drop=True)
hp = bh.train_params(panel)
est = br.estimate(panel)
rparams = {"rough": rh.RoughParams(est["rough"]["alpha"], est["rough"]["lam"], est["rough"]["nu"], est["rough"]["rho"]),
           "rough_a1": rh.RoughParams(1.0, est["a1"]["lam"], est["a1"]["nu"], est["a1"]["rho"])}
one = pt.model_prices(one, hp, rparams)
one = add_heston_variants(one)
w("## 2. ~1-month calls (15-28 trading days to expiry)\n")
w(f"Days to expiry: median {one.n.median():.0f}, range {one.n.min()}-{one.n.max()}.\n")
ranking(one[one.atm], "ATM, ~1 month")
ranking(one, "All strikes 0.90-1.10, ~1 month")
by = one.assign(b=pd.cut(one.m, [0.899, 0.95, 0.99, 1.01, 1.05, 1.101], labels=["0.90-0.95", "0.95-0.99", "0.99-1.01", "1.01-1.05", "1.05-1.10"]))
w("### Mean error by strike, ~1 month (vol pts)\n")
w("| K/F | Options | Market IV % | " + " | ".join(M.values()) + " |")
w("|---|---|---|" + "---|" * len(M))
for b, g in by.groupby("b", observed=True):
    w(f"| {b} | {len(g)} | {g.market_iv.mean()*100:.1f} | " + " | ".join(f"{g[m+'_ev'].mean():+.2f}" for m in M) + " |")
w("")
OUTDIR = PROJECT_ROOT / "results" / "pricing_test"
one.to_csv(OUTDIR / "smile_1m_test.csv", index=False)
(OUTDIR / "robustness.md").write_text("\n".join(out) + "\n")
print("\n".join(out))
