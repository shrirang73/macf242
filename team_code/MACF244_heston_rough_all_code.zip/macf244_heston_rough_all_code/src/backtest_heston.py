"""Real-data backtest with Heston hedges instead of the Black--Scholes delta.

Same design as ``backtest_real.py`` (1-month ATM NIFTY calls sold at every
close, premium = BS price with India VIX, P&L per unit notional, rules fixed /
regime / band, placebos, costs applied later by ``backtest_analysis.py``). The
ONLY change is the target hedge ratio held by the rules:

    bs         BS delta with sigma = VIX/100           (reproduces backtest_real)
    heston     Heston delta dC/dS = P1                 v = (VIX/100)^2
    heston_mv  Heston minimum-variance delta
               dC/dS + (rho sigma / S) dC/dv           v = (VIX/100)^2

Heston parameters (kappa, theta, sigma, rho) are estimated ONCE on the training
period (split == "train", 2010-07-20 .. 2018-12-31) and kept fixed for the test
period, so the test is out of sample. The premium is the same for every hedge
(BS with VIX = the market-price proxy), so differences in P&L come only from
the hedge.

Heston is the alpha = 1, no-jump special case of the rough Hawkes--Heston model.

Outputs: results/backtest_heston/<hedge>/maturity_<m>/{per_option_train.npz,
per_option_test.npz, config.json}, readable by ``backtest_analysis.py``.

Usage: python -m src.backtest_heston [--maturity 21] [--hedges bs heston heston_mv]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import backtest_real as bt
from . import heston as hs
from . import rebalancing as rb
from .upstream import PROJECT_ROOT

OUT = PROJECT_ROOT / "results" / "backtest_heston"
HEDGES = ("bs", "heston", "heston_mv")


def train_params(panel: pd.DataFrame) -> hs.HestonParams:
    """Heston parameters from the training rows only (no test information)."""
    train = panel[panel["split"] == "train"]
    return hs.estimate_params(train["vix"].to_numpy(), train["nifty"].to_numpy(),
                              dt=1.0 / bt.YEAR)


def target_hedge(stock: np.ndarray, vol: np.ndarray, hedge: str,
                 params: hs.HestonParams | None, strike: float = 1.0) -> np.ndarray:
    """Target holdings at decision closes k = 0..N-1, shape (options, N)."""
    if hedge == "bs":
        return bt.target_deltas(stock, vol, strike)
    n_steps = stock.shape[1] - 1
    tau = np.broadcast_to(((n_steps - np.arange(n_steps)) / bt.YEAR)[None, :],
                          (stock.shape[0], n_steps))
    s = stock[:, :-1]
    v = vol[:, :-1] ** 2
    if hedge == "heston":
        return hs.heston_delta(s, strike, tau, v, params)
    if hedge == "heston_mv":
        return hs.minvar_delta(s, strike, tau, v, params)
    raise ValueError(f"unknown hedge {hedge!r}")


def evaluate_period(panel: pd.DataFrame, period: str, maturity: int,
                    label_names: list[str], hedge: str,
                    params: hs.HestonParams | None) -> dict:
    labels = bt.label_variants(panel, label_names)
    variants = list(labels)
    starts = bt.option_starts(panel, period, maturity)
    stock, vol, lab = bt.build_paths(panel, starts, maturity, labels)
    premium = bt.bs_call(1.0, 1.0, maturity / bt.YEAR, vol[:, 0])
    payoff = np.maximum(stock[:, -1] - 1.0, 0.0)
    target = target_hedge(stock, vol, hedge, params)
    if not np.all(np.isfinite(target)):
        raise FloatingPointError(f"non-finite hedge ratios for {hedge}")
    out = {"start_dates": panel.index[starts].strftime("%Y-%m-%d").to_numpy().astype("U10"),
           "premium": premium, "payoff": payoff, "target0": target[:, 0]}
    for name, rule, variant in bt.build_rules(variants, maturity):
        proxy = lab[variant] if variant is not None else None
        phi, _ = rb.held_positions(target, rule, proxy)
        res = rb.trading_outcome(phi, stock)
        out[f"gain|{name}"] = res["gain"]
        out[f"notional|{name}"] = (res["notional_initial"] + res["notional_rebalance"]
                                   + res["notional_terminal"])
        out[f"trades|{name}"] = res["trades"]
    return out


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--maturity", type=int, default=21, help="trading days")
    parser.add_argument("--hedges", nargs="+", default=list(HEDGES), choices=HEDGES)
    parser.add_argument("--labels", nargs="+",
                        default=["vix_hyst", "vix_q75", "rv21_q75", "ms_filter"])
    parser.add_argument("--labels-csv", type=Path, default=bt.LABELS_CSV)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args(argv)

    panel = bt.load_panel(args.labels_csv)
    params = train_params(panel)
    print("Heston parameters (train):", params.as_dict())
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "heston_params.json").write_text(json.dumps(
        {**params.as_dict(), "feller_2kt_minus_s2": 2 * params.kappa * params.theta - params.sigma**2,
         "estimated_on": "split == train", "variance_input": "(VIX/100)^2"}, indent=2))

    for hedge in args.hedges:
        out = args.out / hedge / f"maturity_{args.maturity}"
        out.mkdir(parents=True, exist_ok=True)
        config = {"maturity_days": args.maturity, "labels": args.labels,
                  "labels_csv": str(args.labels_csv), "year_days": bt.YEAR,
                  "placebo_lag": bt.PLACEBO_LAG, "hedge": hedge,
                  "heston_params": params.as_dict() if hedge != "bs" else None,
                  "periods": {}}
        for period in ("train", "test"):
            res = evaluate_period(panel, period, args.maturity, args.labels, hedge,
                                  params if hedge != "bs" else None)
            np.savez_compressed(out / f"per_option_{period}.npz", **res)
            config["periods"][period] = {
                "options": int(len(res["premium"])),
                "first_start": str(res["start_dates"][0]),
                "last_start": str(res["start_dates"][-1]),
                "mean_premium": float(res["premium"].mean()),
                "mean_payoff": float(res["payoff"].mean()),
                "mean_initial_hedge": float(res["target0"].mean()),
            }
            print(hedge, period, config["periods"][period])
        (out / "config.json").write_text(json.dumps(config, indent=2))


if __name__ == "__main__":
    main()
