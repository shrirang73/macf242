"""Compare the BS, Heston and Heston minimum-variance hedges on NIFTY (test period).

For each hedge and cost level, the best rule of each family (fixed / regime with
the main label / band) is PICKED ON THE TRAIN PERIOD of that hedge, then
evaluated on the test period, with and without the COVID window. Reported per
(hedge, strategy):

    rmse_bp      sqrt(J), J = Var(e) + (E[cost])^2  (same criterion as the project)
    mean_bp      mean P&L of the short-call + hedge position
    sd_bp        standard deviation of the P&L
    var95/var99  95% / 99% Value at Risk of the loss (loss = -P&L)
    es95/es99    expected shortfall = mean loss beyond that VaR
    worst_bp     largest loss
    trades       mean number of rebalances per option
    vs_bs_*      change in mean squared (cost-adjusted) error vs the BS hedge with
                 the same strategy family, % and z (moving-block bootstrap SE)

All numbers in basis points of notional (1 bp = 0.01%).

Usage: python -m src.compare_hedges [--root results/backtest_heston] [--maturity 21]
       [--hedges bs heston heston_mv ...] [--name comparison]
The first hedge listed is the reference ("vs_bs_*" columns compare against it;
keep bs first). Writes <root>/<name>.csv and <root>/<name>.md.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

from . import backtest_analysis as ba
from .metrics import block_bootstrap_se
from .upstream import PROJECT_ROOT

BP = 1e4
KAPPAS_BP = (0.0, 5.0, 20.0)
COVID = ("2020-01-15", "2020-06-30")
HEDGES = ("bs", "heston", "heston_mv")
FAMILIES = ("fixed", "regime", "band")


def tail(e: np.ndarray) -> dict:
    loss = -e
    var95, var99 = np.quantile(loss, 0.95), np.quantile(loss, 0.99)
    return {"var95_bp": var95 * BP, "es95_bp": loss[loss >= var95].mean() * BP,
            "var99_bp": var99 * BP, "es99_bp": loss[loss >= var99].mean() * BP,
            "worst_bp": loss.max() * BP}


def pick(train: dict, kappa: float, fam: str, main_label: str) -> str:
    if fam == "regime":
        return ba.best_rule(train, kappa,
                            lambda r: ba.family(r) == "regime" and ba.label_of(r) == main_label)
    return ba.best_rule(train, kappa, lambda r: ba.family(r) == fam)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT / "results" / "backtest_heston")
    parser.add_argument("--maturity", type=int, default=21)
    parser.add_argument("--main-label", default="vix_hyst")
    parser.add_argument("--hedges", nargs="+", default=list(HEDGES))
    parser.add_argument("--name", default="comparison", help="output file stem")
    args = parser.parse_args(argv)

    hedges = tuple(args.hedges)
    dirs = {h: args.root / h / f"maturity_{args.maturity}" for h in hedges}
    block = 2 * args.maturity
    rows = []
    for sample, exclude in (("test_all", None), ("test_excl_covid", COVID)):
        train = {h: ba.load(d, "train") for h, d in dirs.items()}
        test = {h: ba.load(d, "test", exclude) for h, d in dirs.items()}
        for kbp in KAPPAS_BP:
            kappa = kbp / BP
            for fam in FAMILIES:
                ref = None
                for hedge in hedges:
                    rule = pick(train[hedge], kappa, fam, args.main_label)
                    data = test[hedge]
                    e = ba.pnl(data, rule, kappa)
                    adj = ba.adjusted(data, rule, kappa)
                    row = {"sample": sample, "kappa_bp": kbp, "strategy": fam,
                           "hedge": hedge, "rule_picked_on_train": rule,
                           "options": len(e),
                           "rmse_bp": math.sqrt(np.mean(adj**2)) * BP,
                           "mean_bp": e.mean() * BP, "sd_bp": e.std() * BP,
                           **tail(e),
                           "trades": float(data[f"trades|{rule}"].mean())}
                    if hedge == hedges[0]:
                        ref = adj
                        row["vs_bs_mse_change_pct"] = 0.0
                        row["vs_bs_z"] = 0.0
                    else:
                        d = adj**2 - ref**2
                        se = block_bootstrap_se(d, block)
                        row["vs_bs_mse_change_pct"] = 100 * d.mean() / np.mean(ref**2)
                        row["vs_bs_z"] = d.mean() / se if se > 0 else 0.0
                    rows.append(row)

    with (args.root / f"{args.name}.csv").open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(rows)

    params = json.loads((args.root / "heston_params.json").read_text())
    lines = ["# Heston vs Black-Scholes hedges on NIFTY (test period, rules picked on train)", "",
             "Heston parameters (estimated on train): " + ", ".join(
                 f"{k}={params[k]:.4g}" for k in ("kappa", "theta", "sigma", "rho")), "",
             "All values in bp of notional. Loss = -P&L. vs BS: change in mean squared error "
             "vs the BS hedge with the same strategy (negative = Heston better); "
             "|z| > 2 is roughly significant.", ""]
    head = ("| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 "
            "| ES99 | worst | trades | vs BS % | z |")
    for sample in ("test_all", "test_excl_covid"):
        lines += [f"## {sample}", "", head, "|" + "---|" * 15]
        for r in rows:
            if r["sample"] != sample:
                continue
            lines.append(
                f"| {sample} | {r['kappa_bp']:g} | {r['strategy']} | {r['hedge']} "
                f"| {r['rule_picked_on_train']} | {r['rmse_bp']:.1f} | {r['mean_bp']:.1f} "
                f"| {r['sd_bp']:.1f} | {r['var95_bp']:.1f} | {r['es95_bp']:.1f} "
                f"| {r['es99_bp']:.1f} | {r['worst_bp']:.1f} | {r['trades']:.1f} "
                f"| {r['vs_bs_mse_change_pct']:+.1f} | {r['vs_bs_z']:+.2f} |")
        lines.append("")
    (args.root / f"{args.name}.md").write_text("\n".join(lines))
    print(f"wrote {args.root}/{args.name}.csv and {args.name}.md")


if __name__ == "__main__":
    main()
