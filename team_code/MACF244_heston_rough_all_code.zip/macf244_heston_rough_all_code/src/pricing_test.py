"""Pricing test on traded NIFTY options: Black-Scholes vs Heston vs rough Heston.

Option (as in the base paper's numerics): an at-the-money call with about
3 months (T = 0.25, i.e. ~63 trading days) to expiry. For each trading day with
option data we take the NIFTY monthly contract whose time to expiry is closest
to 63 trading days (allowed 40-90), the futures price F of that expiry, and

  * ATM:   the traded call with strike nearest to F;
  * smile: every traded call with 0.90 <= K/F <= 1.10 (extra, same expiry).

Market price = bhavcopy close of a TRADED call (contracts > 0) that is inside
the no-arbitrage bounds (has a Black-76 implied vol). Prices are per unit of F
(Black-76, zero discounting, as in src/fo_data.py).

Models, all fed only that day's India VIX (no fitting to option prices):
  bs           Black-76 with vol = VIX/100
  heston       Heston, v = (VIX/100)^2, parameters estimated on 2010-2018
               (src/backtest_heston.train_params)
  rough        rough Heston, alpha ~ 0.555, flat forward variance (VIX/100)^2,
               parameters estimated on 2010-2018 (src/backtest_rough.estimate)
  rough_a1     same framework with alpha = 1 (control)

Errors: model - market, in bp of F and in implied-vol points (model price
converted to Black-76 implied vol). Reported for days in the train period
(2010-2018, in-sample for the parameters) and test period (2019-2026).

Data: data/raw/bhavcopy/ (git-ignored; rebuild with `python -m src.bhavcopy`,
~1.5 h). Whatever days are present are used; the number of days is reported.

Usage: python -m src.pricing_test
Writes results/pricing_test/{atm_3m.csv, smile_3m.csv, summary.json, summary.md}.
"""

from __future__ import annotations

import gzip
import json

import numpy as np
import pandas as pd

from . import backtest_heston as bh
from . import backtest_real as bt
from . import backtest_rough as br
from . import fo_data as fd
from . import heston as hs
from . import rough_heston as rh
from .backtest_options import Market
from .upstream import PROJECT_ROOT

OUT = PROJECT_ROOT / "results" / "pricing_test"
TARGET, LO, HI = 63, 40, 90
MONEYNESS = (0.90, 1.10)
MODELS = ("bs", "heston", "rough", "rough_a1")
BP = 1e4


def load_fo_available() -> pd.DataFrame:
    """Like fo_data.load_fo, but uses only the daily files present on disk
    (the bhavcopy folder is git-ignored and may be partial)."""
    manifest = [json.loads(line) for line in (fd.RAW / "MANIFEST.jsonl").read_text().splitlines()
                if line.strip()]
    files = sorted({m["file"] for m in manifest if "file" in m and (PROJECT_ROOT / m["file"]).exists()})
    parts = []
    for rel in files:
        with gzip.open(PROJECT_ROOT / rel, "rt") as handle:
            day = pd.read_csv(handle)
        monthly = set(day.loc[day["instrument"] == "FUT", "expiry"])
        parts.append(day[(day["instrument"] == "FUT") | day["expiry"].isin(monthly)])
    if not parts:
        raise SystemExit("no bhavcopy files found: run python -m src.bhavcopy")
    fo = pd.concat(parts, ignore_index=True)
    fo["date"] = pd.to_datetime(fo["date"])
    fo["expiry"] = pd.to_datetime(fo["expiry"])
    return fo


def collect(mkt: Market, vix: pd.Series, split: pd.Series) -> pd.DataFrame:
    rows = []
    for day, labels in mkt.expiries.items():
        if day not in vix.index or not np.isfinite(vix[day]):
            continue
        cands = []
        for e in labels:
            actual = mkt.actual_expiry.get(e)
            if actual is None:
                continue
            n = mkt.days_to(day, actual)
            if LO <= n <= HI and (day, e) in mkt.strikes and (day, e) in mkt.fut_close:
                cands.append((abs(n - TARGET), n, e))
        if not cands:
            continue
        _, n, e = min(cands)
        f = mkt.fut_close[(day, e)]
        strikes = mkt.strikes[(day, e)]
        atm = float(strikes[np.abs(strikes - f).argmin()])
        for k in strikes:
            m = k / f
            if not (MONEYNESS[0] <= m <= MONEYNESS[1]):
                continue
            price = mkt.call_close[(day, e, k)]
            iv = fd.implied_vol(price, f, k, n / fd.YEAR)
            if not np.isfinite(iv):
                continue
            rows.append({"date": day, "expiry": mkt.actual_expiry[e], "n": n, "f": f, "strike": float(k),
                         "m": m, "atm": bool(k == atm), "market": price / f, "market_iv": iv,
                         "vix": vix[day] / 100, "period": split.get(day, "none")})
    return pd.DataFrame(rows)


def model_prices(df: pd.DataFrame, hp: hs.HestonParams, rparams: dict) -> pd.DataFrame:
    df = df.copy()
    tau = df["n"].to_numpy() / fd.YEAR
    k = df["m"].to_numpy()
    vol = df["vix"].to_numpy()
    df["bs"] = fd.black_call(1.0, k, tau, vol)
    df["heston"] = hs.heston_call(1.0, k, tau, vol**2, hp)
    for name, p in rparams.items():
        out = np.empty(len(df))
        pricer = rh.RoughPricer(p, np.unique(tau), br.XI_MIN, steps=200)
        for t in np.unique(tau):
            sel = tau == t
            # pricer has K = 1: C(F=1, K=k) = k * C(S/K = 1/k)
            out[sel] = k[sel] * pricer.quantities(1.0 / k[sel], t, vol[sel] ** 2)["call"]
        df[name] = out
    for name in MODELS:
        df[f"{name}_iv"] = [fd.implied_vol(p, 1.0, kk, t) for p, kk, t in zip(df[name], k, tau)]
    return df


def stats(df: pd.DataFrame) -> dict:
    out = {"n": int(len(df)), "days": int(df["date"].nunique())}
    for name in MODELS:
        e = (df[name] - df["market"]) * BP
        ev = (df[f"{name}_iv"] - df["market_iv"]) * 100
        out[name] = {"bias_bp": float(e.mean()), "rmse_bp": float(np.sqrt(np.mean(e**2))),
                     "mae_bp": float(e.abs().mean()),
                     "bias_volpts": float(ev.mean()), "rmse_volpts": float(np.sqrt(np.nanmean(ev**2)))}
    return out


def main(argv=None):
    nifty = pd.read_csv(PROJECT_ROOT / "data" / "processed" / "nifty50.csv", index_col=0, parse_dates=True)
    panel = bt.load_panel()
    mkt = Market(load_fo_available(), nifty.index)
    df = collect(mkt, panel["vix"], panel["split"])
    if df.empty:
        raise SystemExit("no usable option days found in data/raw/bhavcopy")
    hp = bh.train_params(panel)
    est = br.estimate(panel)
    rparams = {"rough": rh.RoughParams(est["rough"]["alpha"], est["rough"]["lam"], est["rough"]["nu"], est["rough"]["rho"]),
               "rough_a1": rh.RoughParams(1.0, est["a1"]["lam"], est["a1"]["nu"], est["a1"]["rho"])}
    df = model_prices(df, hp, rparams)
    OUT.mkdir(parents=True, exist_ok=True)
    atm = df[df["atm"]]
    atm.to_csv(OUT / "atm_3m.csv", index=False)
    df.to_csv(OUT / "smile_3m.csv", index=False)
    summary = {"data_days": int(df["date"].nunique()), "first": str(df["date"].min().date()),
               "last": str(df["date"].max().date()),
               "years": {str(y): int(c) for y, c in atm.groupby(atm["date"].dt.year).size().items()},
               "heston_params": hp.as_dict(), "rough_params": {k: v.as_dict() for k, v in rparams.items()},
               "atm": {}, "smile": {}, "smile_by_moneyness": {}}
    for period in ("train", "test", "all"):
        a = atm if period == "all" else atm[atm["period"] == period]
        s = df if period == "all" else df[df["period"] == period]
        if len(a):
            summary["atm"][period] = stats(a)
        if len(s):
            summary["smile"][period] = stats(s)
    buckets = pd.cut(df["m"], [0.899, 0.95, 0.99, 1.01, 1.05, 1.101],
                     labels=["0.90-0.95", "0.95-0.99", "0.99-1.01", "1.01-1.05", "1.05-1.10"])
    for b, g in df.groupby(buckets, observed=True):
        summary["smile_by_moneyness"][str(b)] = {
            "n": int(len(g)), "market_iv": float(g["market_iv"].mean() * 100),
            **{f"{m}_iv_bias_volpts": float(((g[f"{m}_iv"] - g["market_iv"]) * 100).mean()) for m in MODELS}}
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))

    lines = ["# Pricing 3-month NIFTY calls: model vs market", "",
             f"Option days: {summary['data_days']} ({summary['first']} .. {summary['last']}); "
             f"ATM days by year: {summary['years']}", "",
             "Error = model - market. bp of the futures price; vol pts = implied-vol points.", ""]
    for key, title in (("atm", "ATM call, ~3 months (the paper's option)"),
                       ("smile", "All traded calls 0.90 <= K/F <= 1.10, same expiry")):
        lines += [f"## {title}", "",
                  "| period | options | model | bias bp | RMSE bp | MAE bp | bias vol pts | RMSE vol pts |",
                  "|---|---|---|---|---|---|---|---|"]
        for period, st in summary[key].items():
            for m in MODELS:
                x = st[m]
                lines.append(f"| {period} | {st['n']} | {m} | {x['bias_bp']:+.1f} | {x['rmse_bp']:.1f} | "
                             f"{x['mae_bp']:.1f} | {x['bias_volpts']:+.2f} | {x['rmse_volpts']:.2f} |")
        lines.append("")
    lines += ["## Smile: mean implied-vol error by moneyness (vol pts)", "",
              "| K/F | options | market IV % | " + " | ".join(MODELS) + " |", "|---" * (3 + len(MODELS)) + "|"]
    for b, x in summary["smile_by_moneyness"].items():
        lines.append(f"| {b} | {x['n']} | {x['market_iv']:.1f} | "
                     + " | ".join(f"{x[f'{m}_iv_bias_volpts']:+.2f}" for m in MODELS) + " |")
    (OUT / "summary.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
