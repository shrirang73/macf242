"""Heston (1993) model: option price, delta and minimum-variance delta.

Model (zero interest rate, no dividends), under one measure used for both pricing
and hedging:

    dS = S sqrt(v) dW1
    dv = kappa (theta - v) dt + sigma sqrt(v) dW2,     corr(dW1, dW2) = rho

Heston is the alpha = 1, no-jump special case of the rough Hawkes--Heston model.

Pricing is by Fourier inversion (Gil-Pelaez) of the two probabilities
    C = S P1 - K P2,
using the numerically stable "little trap" form of the characteristic function
(Albrecher et al. 2007). The integral is done by Gauss--Legendre quadrature on a
frequency grid scaled by the option's total volatility, vectorised over options.

Hedge ratios
------------
* ``heston_delta``      dC/dS = P1                       (Heston delta; r = 0)
* ``minvar_delta``      dC/dS + (rho sigma / S) dC/dv    (locally risk-minimising
  delta: also hedges the part of the variance move that is correlated with S;
  Hull & White 2017, Bartlett 2006, Poulsen et al. 2008)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

CHUNK = 4000  # options per quadrature batch (memory control)


@dataclass(frozen=True)
class HestonParams:
    kappa: float  # speed of mean reversion of v (per year)
    theta: float  # long-run variance
    sigma: float  # volatility of variance
    rho: float    # correlation between price and variance shocks

    def as_dict(self) -> dict:
        return {"kappa": self.kappa, "theta": self.theta, "sigma": self.sigma, "rho": self.rho}


def _nodes(n: int, umax: float):
    x, w = np.polynomial.legendre.leggauss(n)
    return 0.5 * umax * (x + 1.0), 0.5 * umax * w


def _terms(phi, tau, v, p: HestonParams, j: int):
    """exp(C + D v) and D of the characteristic function of ln S_T (little-trap form).

    j = 1: share-measure probability P1;  j = 2: risk-neutral probability P2.
    """
    u, b = (0.5, p.kappa - p.rho * p.sigma) if j == 1 else (-0.5, p.kappa)
    sig2 = p.sigma**2
    i_phi = 1j * phi
    q = b - p.rho * p.sigma * i_phi
    d = np.sqrt(q * q - sig2 * (2.0 * u * i_phi - phi * phi))
    g = (q - d) / (q + d)
    e = np.exp(-d * tau)
    D = (q - d) / sig2 * (1.0 - e) / (1.0 - g * e)
    C = p.kappa * p.theta / sig2 * ((q - d) * tau - 2.0 * np.log((1.0 - g * e) / (1.0 - g)))
    return np.exp(C + D * v), D


def _batch(S, K, tau, v, p: HestonParams, n: int, umax: float):
    """P1, P2, dP1/dv, dP2/dv for 1-d arrays S, K, tau, v."""
    u, w = _nodes(n, umax)
    scale = np.sqrt(0.5 * (v + p.theta) * tau)           # total-volatility scale, shape (m,)
    phi = u[None, :] / scale[:, None]                    # frequency grid, shape (m, n)
    jac = w[None, :] / scale[:, None]
    x = np.log(S / K)[:, None]
    out = []
    for j in (1, 2):
        f, D = _terms(phi, tau[:, None], v[:, None], p, j)
        kernel = np.exp(1j * phi * x) / (1j * phi)
        P = 0.5 + np.sum(np.real(kernel * f) * jac, axis=1) / np.pi
        dP = np.sum(np.real(kernel * f * D) * jac, axis=1) / np.pi
        out.append((P, dP))
    (p1, dp1), (p2, dp2) = out
    return p1, p2, dp1, dp2


def heston_quantities(S, K, tau, v, p: HestonParams, n: int = 256, umax: float = 30.0) -> dict:
    """Call price, delta (P1) and dC/dv. Inputs broadcast to a common shape.

    tau in years, v the instantaneous variance (not volatility).
    """
    S, K, tau, v = np.broadcast_arrays(*(np.asarray(a, dtype=float) for a in (S, K, tau, v)))
    shape = S.shape
    s, k, t, vv = (a.ravel() for a in (S, K, tau, v))
    keys = ("p1", "p2", "dp1", "dp2")
    res = {key: np.empty(s.size) for key in keys}
    for lo in range(0, s.size, CHUNK):
        sl = slice(lo, lo + CHUNK)
        for key, val in zip(keys, _batch(s[sl], k[sl], t[sl], vv[sl], p, n, umax)):
            res[key][sl] = val
    call = s * res["p1"] - k * res["p2"]
    dcdv = s * res["dp1"] - k * res["dp2"]
    return {"call": call.reshape(shape), "delta": res["p1"].reshape(shape),
            "dcdv": dcdv.reshape(shape), "p2": res["p2"].reshape(shape)}


def heston_call(S, K, tau, v, p: HestonParams, **kw):
    return heston_quantities(S, K, tau, v, p, **kw)["call"]


def heston_delta(S, K, tau, v, p: HestonParams, **kw):
    return heston_quantities(S, K, tau, v, p, **kw)["delta"]


def minvar_delta(S, K, tau, v, p: HestonParams, **kw):
    q = heston_quantities(S, K, tau, v, p, **kw)
    return q["delta"] + p.rho * p.sigma / np.asarray(S, dtype=float) * q["dcdv"]


# ---------------------------------------------------------------------------
# Parameter estimation from the VIX and index history (training period only)
# ---------------------------------------------------------------------------


def estimate_params(vix_pct: np.ndarray, price: np.ndarray, dt: float = 1.0 / 252.0) -> HestonParams:
    """Method-of-moments Heston parameters from daily closes.

    v_t = (VIX_t / 100)^2 is used as the instantaneous variance (a simplification:
    VIX is a 30-day risk-neutral average, not the instantaneous variance).

    * v_{t+1} = a + b v_t + e_t   (OLS)  ->  kappa = -ln(b)/dt,  theta = a/(1-b)
    * Var(e_t | v_t) = sigma^2 v_t dt     ->  sigma^2 = mean(e_t^2 / v_t) / dt
    * rho = corr(r_{t+1}/sqrt(v_t), e_t/sqrt(v_t)),  r = daily log return
    """
    vix_pct = np.asarray(vix_pct, dtype=float)
    price = np.asarray(price, dtype=float)
    if vix_pct.shape != price.shape or vix_pct.ndim != 1:
        raise ValueError("vix and price must be 1-d arrays of equal length")
    v = (vix_pct / 100.0) ** 2
    v0, v1 = v[:-1], v[1:]
    r = np.diff(np.log(price))
    b, a = np.polyfit(v0, v1, 1)
    if not 0.0 < b < 1.0:
        raise ValueError(f"AR(1) slope {b:.4f} outside (0,1): variance not mean reverting")
    resid = v1 - (a + b * v0)
    kappa = -np.log(b) / dt
    theta = a / (1.0 - b)
    sigma = float(np.sqrt(np.mean(resid**2 / v0) / dt))
    rho = float(np.corrcoef(r / np.sqrt(v0), resid / np.sqrt(v0))[0, 1])
    return HestonParams(kappa=float(kappa), theta=float(theta), sigma=sigma, rho=rho)
