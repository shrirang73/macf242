"""Heston hedges on NIFTY with parameters re-estimated EVERY MONTH (test period).

Robustness check for ``backtest_heston.py``: instead of one parameter set
estimated on 2010-2018, the Heston parameters (kappa, theta, sigma, rho) are
re-estimated at the start of every month from the ``window`` trading days
strictly BEFORE the first trading day of that month (no look-ahead).
``--window 0`` = EXPANDING window: all data from the first day of the panel
(2010-07-20) up to the day before the month (e.g. options starting in March
2020 use 2010-07-20 .. 2020-02-28). Every
option starting in month M is hedged with month M's parameters for its whole
life. If an estimate fails (variance not mean reverting in the window, or a
non-positive theta/sigma), the previous month's parameters are reused.

Only the TEST period (2019-2026) is re-done. The train file is copied from the
fixed-parameter run of the same hedge (``results/backtest_heston/<hedge>/``),
so ``backtest_analysis`` / ``compare_hedges`` pick the same rules on train;
the comparison is therefore purely about the test-period hedge.

Requires: ``python -m src.backtest_heston`` has been run first.

Outputs: results/backtest_heston/<hedge>_roll<window>/maturity_<m>/
  (<hedge>_rollexp/ for the expanding window)
  per_option_train.npz (copy), per_option_test.npz, config.json,
  monthly_params.csv  (month, kappa, theta, sigma, rho, reused_previous)

Usage: python -m src.backtest_heston_rolling [--window 252 | --window 0] [--maturity 21]
"""

from __future__ import annotations

import argparse
import csv
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from . import backtest_real as bt
from . import heston as hs
from . import rebalancing as rb
from .backtest_heston import OUT

LABELS = ["vix_hyst", "vix_q75", "rv21_q75", "ms_filter"]


def monthly_params(panel: pd.DataFrame, months: list, window: int) -> tuple[dict, dict]:
    """Parameters per month from the ``window`` rows before the month's first row
    (window = 0: every row before it, i.e. an expanding window)."""
    period = panel.index.to_period("M")
    params, reused, prev = {}, {}, None
    for m in months:
        first = int(np.argmax(period == m))
        if first < max(window, 252):
            raise ValueError(f"not enough history before {m} for window {window}")
        d = panel.iloc[(first - window if window > 0 else 0):first]
        try:
            p = hs.estimate_params(d["vix"].to_numpy(), d["nifty"].to_numpy(), dt=1.0 / bt.YEAR)
            if not (p.theta > 0 and p.sigma > 0):
                raise ValueError("non-positive theta or sigma")
            prev, reused[m] = p, False
        except ValueError:
            if prev is None:
                raise
            p, reused[m] = prev, True
        params[m] = p
    return params, reused


def evaluate_test(panel: pd.DataFrame, maturity: int, hedge: str, window: int) -> tuple[dict, dict, dict]:
    labels = bt.label_variants(panel, LABELS)
    starts = bt.option_starts(panel, "test", maturity)
    stock, vol, lab = bt.build_paths(panel, starts, maturity, labels)
    start_month = panel.index[starts].to_period("M")
    params, reused = monthly_params(panel, sorted(set(start_month)), window)
    fn = {"heston": hs.heston_delta, "heston_mv": hs.minvar_delta}[hedge]
    n = maturity
    tau = np.broadcast_to(((n - np.arange(n)) / bt.YEAR)[None, :], (len(starts), n))
    target = np.full((len(starts), n), np.nan)
    for m, p in params.items():
        sel = np.asarray(start_month == m)
        target[sel] = fn(stock[sel, :-1], 1.0, tau[sel], vol[sel, :-1] ** 2, p)
    if not np.all(np.isfinite(target)):
        raise FloatingPointError("non-finite hedge ratios")
    out = {"start_dates": panel.index[starts].strftime("%Y-%m-%d").to_numpy().astype("U10"),
           "premium": bt.bs_call(1.0, 1.0, maturity / bt.YEAR, vol[:, 0]),
           "payoff": np.maximum(stock[:, -1] - 1.0, 0.0), "target0": target[:, 0]}
    for name, rule, variant in bt.build_rules(list(labels), maturity):
        phi, _ = rb.held_positions(target, rule, lab[variant] if variant is not None else None)
        res = rb.trading_outcome(phi, stock)
        out[f"gain|{name}"] = res["gain"]
        out[f"notional|{name}"] = (res["notional_initial"] + res["notional_rebalance"]
                                   + res["notional_terminal"])
        out[f"trades|{name}"] = res["trades"]
    return out, params, reused


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--window", type=int, default=252,
                        help="trading days of history; 0 = expanding (all data since 2010)")
    parser.add_argument("--maturity", type=int, default=21)
    parser.add_argument("--root", type=Path, default=OUT)
    args = parser.parse_args(argv)
    panel = bt.load_panel()
    for hedge in ("heston", "heston_mv"):
        src = args.root / hedge / f"maturity_{args.maturity}"
        if not (src / "per_option_train.npz").exists():
            raise FileNotFoundError(f"{src} missing: run python -m src.backtest_heston first")
        tag = "rollexp" if args.window == 0 else f"roll{args.window}"
        out_dir = args.root / f"{hedge}_{tag}" / f"maturity_{args.maturity}"
        out_dir.mkdir(parents=True, exist_ok=True)
        res, params, reused = evaluate_test(panel, args.maturity, hedge, args.window)
        np.savez_compressed(out_dir / "per_option_test.npz", **res)
        shutil.copy(src / "per_option_train.npz", out_dir / "per_option_train.npz")
        config = json.loads((src / "config.json").read_text())
        config.update({"hedge": f"{hedge}_{tag}", "heston_params": "monthly_params.csv",
                       "rolling_window_days": args.window,
                       "train_file": f"copied from {hedge}/ (fixed 2010-2018 parameters)"})
        config["periods"]["test"]["mean_initial_hedge"] = float(res["target0"].mean())
        (out_dir / "config.json").write_text(json.dumps(config, indent=2))
        with (out_dir / "monthly_params.csv").open("w", newline="") as fh:
            w = csv.writer(fh, lineterminator="\n")
            w.writerow(["month", "kappa", "theta", "sigma", "rho", "reused_previous"])
            for m, p in params.items():
                w.writerow([str(m), p.kappa, p.theta, p.sigma, p.rho, reused[m]])
        k = np.array([p.kappa for p in params.values()])
        print(f"{hedge}_{tag}: {len(params)} months, {sum(reused.values())} reused; "
              f"kappa range {k.min():.2f}-{k.max():.2f}; options {len(res['premium'])}")


if __name__ == "__main__":
    main()
