"""Checks for the rough Heston pricer/hedges (src/rough_heston.py) and its backtest.

Run: python -m pytest tests/test_rough_heston.py -q
"""

from __future__ import annotations

from math import gamma

import numpy as np
import pytest

from src import backtest_real as bt
from src import backtest_rough as br
from src import heston as hs
from src import rough_heston as rh


def test_resolvent_closed_forms():
    h = 1 / 1008
    t = np.arange(2001) * h
    R = rh.resolvent_integral(1.0, 10.0, h, 2000)
    assert np.max(np.abs(R - (1 - np.exp(-10.0 * t)) / 10.0)) < 1e-6
    R0 = rh.resolvent_integral(0.55, 0.0, h, 2000)
    assert np.max(np.abs(R0 - t**0.55 / gamma(1.55))) < 1e-10


@pytest.mark.parametrize("tau_days", [1, 10, 21])
def test_alpha_one_equals_heston(tau_days):
    """alpha = 1, flat forward variance xi = v = theta: price, delta, min-var delta = heston.py."""
    p = rh.RoughParams(1.0, 8.6, 0.34, -0.53)
    hp = hs.HestonParams(8.6, 0.03, 0.34, -0.53)
    tau = tau_days / 252
    s = np.array([0.9, 0.97, 1.0, 1.03, 1.1])
    q = rh.RoughPricer(p, [tau], xi_min=0.0081).quantities(s, tau, np.full(5, 0.03))
    assert np.max(np.abs(q["call"] - hs.heston_call(s, 1.0, tau, 0.03, hp))) < 1e-7
    assert np.max(np.abs(q["delta"] - hs.heston_delta(s, 1.0, tau, 0.03, hp))) < 1e-6
    assert np.max(np.abs(q["minvar"] - hs.minvar_delta(s, 1.0, tau, 0.03, hp))) < 1e-6


def test_rough_converges_in_time_steps():
    p = rh.RoughParams(0.55, 3.0, 0.15, -0.6)
    tau = 21 / 252
    s, xi = np.array([0.95, 1.0, 1.05]), np.full(3, 0.04)
    a = rh.RoughPricer(p, [tau], 0.0064, steps=200).quantities(s, tau, xi)
    b = rh.RoughPricer(p, [tau], 0.0064, steps=800).quantities(s, tau, xi)
    for k in ("call", "delta", "minvar"):
        assert np.max(np.abs(a[k] - b[k])) < 2e-5


def test_rough_price_against_monte_carlo():
    """Reference values from a 40,000-path Volterra Euler simulation (420 steps, seed 3):
    calls at K = 0.95, 1.00, 1.05 = 0.057023, 0.022686, 0.005104 (s.e. 2.3e-4, 1.6e-4, 7e-5)."""
    p = rh.RoughParams(0.55, 3.0, 0.15, -0.6)
    tau = 21 / 252
    K = np.array([0.95, 1.0, 1.05])
    q = rh.RoughPricer(p, [tau], 0.0064).quantities(1 / K, tau, np.full(3, 0.04))
    mc, se = np.array([0.057023, 0.022686, 0.005104]), np.array([2.3e-4, 1.6e-4, 7e-5])
    assert np.all(np.abs(q["call"] * K - mc) < 3 * se)


def test_roughness_estimator_on_known_series():
    rng = np.random.default_rng(0)
    n, H = 4096, 0.1
    k = np.arange(n)
    g = 0.5 * (np.abs(k + 1) ** (2 * H) - 2 * np.abs(k) ** (2 * H) + np.abs(k - 1) ** (2 * H))
    c = np.concatenate([g, g[-2:0:-1]])
    lam = np.clip(np.fft.fft(c).real, 0, None)
    z = rng.standard_normal(len(c)) + 1j * rng.standard_normal(len(c))
    x = np.cumsum(np.fft.fft(np.sqrt(lam / len(c)) * z).real[:n])
    assert abs(rh.roughness_H(x) - H) < 0.03


def test_estimation_uses_train_only_and_is_sensible():
    panel = bt.load_panel()
    est = br.estimate(panel)
    changed = panel.copy()
    test = changed["split"] == "test"
    changed.loc[test, "vix"] *= 2.0
    assert br.estimate(changed) == est
    assert 0.5 < est["rough"]["alpha"] < 0.7
    assert est["rough"]["lam"] > 0 and est["rough"]["nu"] > 0 and -1 < est["rough"]["rho"] < 0
    assert not est["rough"]["lam_at_grid_edge"] and not est["a1"]["lam_at_grid_edge"]
