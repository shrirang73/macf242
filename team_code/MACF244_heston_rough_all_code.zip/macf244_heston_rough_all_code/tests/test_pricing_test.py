"""Checks for src/pricing_test.py (runs on whatever bhavcopy days are on disk).

Run: python -m pytest tests/test_pricing_test.py -q
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src import backtest_real as bt
from src import fo_data as fd
from src import pricing_test as pt
from src.backtest_options import Market
from src.upstream import PROJECT_ROOT


@pytest.fixture(scope="module")
def sample():
    nifty = pd.read_csv(PROJECT_ROOT / "data" / "processed" / "nifty50.csv", index_col=0, parse_dates=True)
    panel = bt.load_panel()
    df = pt.collect(Market(pt.load_fo_available(), nifty.index), panel["vix"], panel["split"])
    if df.empty:
        pytest.skip("no bhavcopy option data on disk")
    return df


def test_contract_choice_and_market_iv(sample):
    assert sample["n"].between(pt.LO, pt.HI).all()
    assert sample["m"].between(*pt.MONEYNESS).all()
    assert (sample.groupby("date")["atm"].sum() == 1).all()
    back = fd.black_call(1.0, sample["m"], sample["n"] / fd.YEAR, sample["market_iv"])
    assert np.allclose(back, sample["market"], atol=1e-9)


def test_black_scholes_column(sample):
    from src import heston as hs
    from src import rough_heston as rh
    small = sample.head(30)
    hp = hs.HestonParams(8.6, 0.0337, 0.341, -0.526)
    rp = {"rough": rh.RoughParams(0.555, 0.95, 0.19, -0.526), "rough_a1": rh.RoughParams(1.0, 10.2, 0.6, -0.526)}
    out = pt.model_prices(small, hp, rp)
    tau = small["n"] / fd.YEAR
    assert np.allclose(out["bs"], fd.black_call(1.0, small["m"], tau, small["vix"]))
    assert np.allclose(out["bs_iv"], small["vix"], atol=1e-8)
    for m in pt.MODELS:
        assert np.all(np.isfinite(out[m])) and np.all(out[m] > 0)
