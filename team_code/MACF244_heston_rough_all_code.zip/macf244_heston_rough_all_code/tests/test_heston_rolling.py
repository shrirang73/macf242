"""Checks for the monthly re-estimated Heston hedge (src/backtest_heston_rolling.py).

Run: python -m pytest tests/test_heston_rolling.py -q
"""

from __future__ import annotations

import numpy as np
import pytest

from src import backtest_heston_rolling as roll
from src import backtest_real as bt
from src import heston as hs


@pytest.fixture(scope="module")
def panel():
    return bt.load_panel()


def test_monthly_params_use_only_past_data(panel):
    """Month M's parameters must not change when data from M onwards is changed."""
    month = panel.index.to_period("M")[panel.index.get_loc(panel.index[panel.index >= "2020-03-01"][0])]
    p1, _ = roll.monthly_params(panel, [month], 252)
    changed = panel.copy()
    later = changed.index >= "2020-03-01"
    changed.loc[later, "vix"] = changed.loc[later, "vix"] * 2.0
    changed.loc[later, "nifty"] = changed.loc[later, "nifty"] * 0.5
    p2, _ = roll.monthly_params(changed, [month], 252)
    assert p1[month] == p2[month]


def test_monthly_params_match_direct_estimate(panel):
    """Parameters for a month = estimate on exactly the 252 rows before its first day."""
    month = panel.index[panel.index >= "2021-06-01"][0].to_period("M")
    params, reused = roll.monthly_params(panel, [month], 252)
    first = int(np.argmax(panel.index.to_period("M") == month))
    d = panel.iloc[first - 252:first]
    direct = hs.estimate_params(d["vix"].to_numpy(), d["nifty"].to_numpy())
    assert params[month] == direct and not reused[month]
    assert d.index[-1] < panel.index[first]


def test_one_option_by_hand(panel):
    """Daily rebalancing with the rolling Heston delta equals a scalar loop."""
    res, params, _ = roll.evaluate_test(panel, 21, "heston", 252)
    i = 300
    t0 = bt.option_starts(panel, "test", 21)[i]
    p = params[panel.index[t0].to_period("M")]
    s = panel["nifty"].to_numpy()[t0:t0 + 22] / panel["nifty"].to_numpy()[t0]
    vix = panel["vix"].to_numpy()[t0:t0 + 22] / 100
    gain = sum(float(hs.heston_delta(s[k], 1.0, (21 - k) / 252, vix[k] ** 2, p)) * (s[k + 1] - s[k])
               for k in range(21))
    assert abs(res["gain|fixed/every=1"][i] - gain) < 1e-12


def test_expanding_window_uses_all_past_data_only(panel):
    """window = 0: month M uses every row from 2010-07-20 to the day before M, nothing after."""
    month = panel.index[panel.index >= "2020-03-01"][0].to_period("M")
    params, _ = roll.monthly_params(panel, [month], 0)
    first = int(np.argmax(panel.index.to_period("M") == month))
    d = panel.iloc[:first]
    assert d.index[0] == panel.index[0] and d.index[-1] < panel.index[first]
    assert params[month] == hs.estimate_params(d["vix"].to_numpy(), d["nifty"].to_numpy())
    changed = panel.copy()
    changed.loc[changed.index >= "2020-03-01", "vix"] *= 2.0
    assert roll.monthly_params(changed, [month], 0)[0][month] == params[month]
