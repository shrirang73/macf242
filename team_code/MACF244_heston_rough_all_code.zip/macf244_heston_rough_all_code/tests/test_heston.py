"""Checks for the Heston pricer/hedges (src/heston.py) and the Heston backtest.

Run: python -m pytest tests/test_heston.py -q
"""

from __future__ import annotations

import numpy as np
import pytest

from src import backtest_heston as bh
from src import backtest_real as bt
from src import heston as hs
from src import rebalancing as rb

NIFTY_LIKE = hs.HestonParams(kappa=8.6, theta=0.0337, sigma=0.341, rho=-0.526)


# --- 1. Pricing ----------------------------------------------------------------------


def test_reference_price_fang_oosterlee():
    """Benchmark from Fang & Oosterlee (2008, COS method), r = q = 0: 5.785155450."""
    p = hs.HestonParams(kappa=1.5768, theta=0.0398, sigma=0.5751, rho=-0.5711)
    price = float(hs.heston_call(100.0, 100.0, 1.0, 0.0175, p))
    assert abs(price - 5.785155450) < 1e-6


def test_small_vol_of_vol_gives_black_scholes():
    """sigma -> 0 and v0 = theta: variance is constant, so Heston = BS(sqrt(theta))."""
    p = hs.HestonParams(kappa=3.0, theta=0.04, sigma=1e-4, rho=-0.5)
    s = np.array([0.9, 1.0, 1.1])
    tau = 21 / 252
    q = hs.heston_quantities(s, 1.0, tau, 0.04, p)
    assert np.max(np.abs(q["call"] - bt.bs_call(s, 1.0, tau, 0.2))) < 1e-6
    assert np.max(np.abs(q["delta"] - bt.bs_delta(s, 1.0, tau, 0.2))) < 1e-5


def test_put_call_parity_and_bounds():
    """P2 is a probability; call within (S-K)^+ <= C <= S; put = C - S + K >= 0."""
    s = np.linspace(0.8, 1.2, 9)
    q = hs.heston_quantities(s, 1.0, 10 / 252, 0.15**2, NIFTY_LIKE)
    assert np.all(q["call"] >= np.maximum(s - 1.0, 0.0) - 1e-10)
    assert np.all(q["call"] <= s)
    assert np.all((q["p2"] >= -1e-10) & (q["p2"] <= 1 + 1e-10))
    assert np.all(q["delta"] >= -1e-10) and np.all(q["delta"] <= 1 + 1e-10)


# --- 2. Greeks are derivatives of the price ------------------------------------------


@pytest.mark.parametrize("s,tau,v", [(1.0, 21 / 252, 0.15**2), (0.95, 5 / 252, 0.3**2),
                                     (1.07, 15 / 252, 0.1**2)])
def test_delta_and_vega_are_finite_differences(s, tau, v):
    h = 1e-5
    q = hs.heston_quantities(s, 1.0, tau, v, NIFTY_LIKE)
    fd_s = (hs.heston_call(s + h, 1.0, tau, v, NIFTY_LIKE)
            - hs.heston_call(s - h, 1.0, tau, v, NIFTY_LIKE)) / (2 * h)
    hv = 1e-6
    fd_v = (hs.heston_call(s, 1.0, tau, v + hv, NIFTY_LIKE)
            - hs.heston_call(s, 1.0, tau, v - hv, NIFTY_LIKE)) / (2 * hv)
    assert abs(fd_s - q["delta"]) < 1e-6
    assert abs(fd_v - q["dcdv"]) < 1e-4 * max(1.0, abs(fd_v))


def test_minvar_delta_formula():
    s, tau, v = 1.02, 12 / 252, 0.18**2
    q = hs.heston_quantities(s, 1.0, tau, v, NIFTY_LIKE)
    expected = q["delta"] + NIFTY_LIKE.rho * NIFTY_LIKE.sigma / s * q["dcdv"]
    assert abs(hs.minvar_delta(s, 1.0, tau, v, NIFTY_LIKE) - expected) < 1e-12
    # with rho < 0 and dC/dv > 0 the minimum-variance delta is below the Heston delta
    assert hs.minvar_delta(s, 1.0, tau, v, NIFTY_LIKE) < q["delta"]
    zero_rho = hs.HestonParams(NIFTY_LIKE.kappa, NIFTY_LIKE.theta, NIFTY_LIKE.sigma, 0.0)
    assert abs(hs.minvar_delta(s, 1.0, tau, v, zero_rho)
               - hs.heston_delta(s, 1.0, tau, v, zero_rho)) < 1e-12


def test_vectorised_matches_scalar():
    s = np.array([[0.97, 1.0], [1.03, 1.1]])
    tau = np.array([[5 / 252, 21 / 252], [1 / 252, 10 / 252]])
    v = np.array([[0.01, 0.04], [0.09, 0.02]])
    arr = hs.heston_delta(s, 1.0, tau, v, NIFTY_LIKE)
    for i in range(2):
        for j in range(2):
            assert abs(arr[i, j] - hs.heston_delta(s[i, j], 1.0, tau[i, j], v[i, j],
                                                  NIFTY_LIKE)) < 1e-12


# --- 3. Parameter estimation ---------------------------------------------------------


def test_estimation_recovers_simulated_parameters():
    """Simulate a long daily Heston path (fine Euler steps) and re-estimate."""
    true = hs.HestonParams(kappa=6.0, theta=0.04, sigma=0.4, rho=-0.6)
    rng = np.random.default_rng(1)
    days, sub = 40 * 252, 10
    dt = 1.0 / 252 / sub
    v, logs = true.theta, 0.0
    vs, ss = [v], [logs]
    for _ in range(days):
        z1 = rng.standard_normal(sub)
        z2 = true.rho * z1 + np.sqrt(1 - true.rho**2) * rng.standard_normal(sub)
        for a, b in zip(z1, z2):
            sv = np.sqrt(max(v, 0.0))
            logs += -0.5 * v * dt + sv * np.sqrt(dt) * a
            v = max(v + true.kappa * (true.theta - v) * dt + true.sigma * sv * np.sqrt(dt) * b, 1e-8)
        vs.append(v)
        ss.append(logs)
    vix = 100 * np.sqrt(np.array(vs))
    est = hs.estimate_params(vix, np.exp(np.array(ss)))
    assert abs(est.kappa - true.kappa) / true.kappa < 0.25
    assert abs(est.theta - true.theta) / true.theta < 0.10
    assert abs(est.sigma - true.sigma) / true.sigma < 0.05
    assert abs(est.rho - true.rho) < 0.05


def test_estimation_rejects_bad_input():
    with pytest.raises(ValueError):
        hs.estimate_params(np.ones(5), np.ones(4))


# --- 4. Backtest wiring --------------------------------------------------------------


@pytest.fixture(scope="module")
def panel():
    return bt.load_panel()


def test_train_params_use_train_rows_only(panel):
    p1 = bh.train_params(panel)
    changed = panel.copy()
    test_rows = changed["split"] == "test"
    changed.loc[test_rows, "vix"] = changed.loc[test_rows, "vix"] * 3.0
    p2 = bh.train_params(changed)
    assert p1 == p2
    assert p1.kappa > 0 and p1.theta > 0 and p1.sigma > 0 and -1 < p1.rho < 0


def test_bs_hedge_reproduces_backtest_real(panel):
    """hedge='bs' must give exactly the numbers of the original backtest."""
    labels = ["vix_hyst"]
    old = bt.evaluate_period(panel, "test", 21, labels)
    new = bh.evaluate_period(panel, "test", 21, labels, "bs", None)
    for key in old:
        if key == "start_dates":
            assert np.array_equal(old[key], new[key])
        else:
            assert np.allclose(old[key], new[key], rtol=0, atol=1e-14), key


def test_heston_backtest_one_option_by_hand(panel):
    """Daily rebalancing with the Heston delta: P&L equals a scalar loop."""
    params = bh.train_params(panel)
    maturity = 21
    res = bh.evaluate_period(panel, "test", maturity, ["vix_hyst"], "heston", params)
    i = 100
    t0 = bt.option_starts(panel, "test", maturity)[i]
    price = panel["nifty"].to_numpy()[t0:t0 + maturity + 1]
    vix = panel["vix"].to_numpy()[t0:t0 + maturity + 1] / 100
    s = price / price[0]
    gain, notional, prev = 0.0, 0.0, 0.0
    for k in range(maturity):
        tau = (maturity - k) / 252
        d = float(hs.heston_delta(s[k], 1.0, tau, vix[k] ** 2, params))
        notional += s[k] * abs(d - prev)
        gain += d * (s[k + 1] - s[k])
        prev = d
    notional += s[-1] * abs(prev)
    assert abs(res["gain|fixed/every=1"][i] - gain) < 1e-12
    assert abs(res["notional|fixed/every=1"][i] - notional) < 1e-12
    assert abs(res["premium"][i] - bt.bs_call(1.0, 1.0, maturity / 252, vix[0])) < 1e-15


def test_rules_see_same_targets(panel):
    """Band rule never trades more than daily; all hedges finite and in [0, 1.2]."""
    params = bh.train_params(panel)
    for hedge in ("heston", "heston_mv"):
        res = bh.evaluate_period(panel, "train", 21, ["vix_hyst"], hedge, params)
        assert np.all(res["trades|band/h=0.02"] <= res["trades|fixed/every=1"])
        assert np.all((res["target0"] > 0) & (res["target0"] < 1.2))
