# Instructions: add Heston hedges to the NIFTY backtest (MAC F244 repo)

Audience: a coding agent working on a **fresh machine** that has only the GitHub
repository `https://github.com/shrirang73/macf242`. Follow the steps in order.
Every file to create is given **in full** below: copy it byte for byte, do not
rewrite, "improve", reformat or shorten it. All code here was run and tested
against repo commit `beeb9551b342cb3a0f8e63ee3144e4dfd6de4cd7` (6 Nov 2026).

---

## 0. What this task is (context for the agent)

The repo hedges a short 1-month at-the-money NIFTY call on real data
(`src/backtest_real.py`) with three rebalancing strategies: **fixed** schedule
(e.g. daily), **regime-aware** (trade more often when the VIX regime label says
"stress"), and **no-trade band**. The hedge ratio used today is the
**Black-Scholes delta** with volatility = India VIX / 100.

This task adds two hedge ratios from the **Heston stochastic-volatility model**
(Heston = the alpha = 1, no-jump special case of the rough Hawkes-Heston model
studied in the project's simulation part):

| hedge name | hedge ratio | variance input |
|---|---|---|
| `bs` | Black-Scholes delta, sigma = VIX/100 (reproduces the existing backtest exactly) | - |
| `heston` | Heston delta, dC/dS = P1 | v = (VIX/100)^2 |
| `heston_mv` | Heston minimum-variance delta, dC/dS + (rho*sigma/S) * dC/dv | v = (VIX/100)^2 |

Everything else (option sample, premium, payoff, rules, placebos, costs,
train/test split, COVID exclusion, criterion J, bootstrap) is unchanged and is
reused from the existing code. The premium is the same BS-with-VIX price for all
three hedges, so P&L differences come **only** from the hedge.

Heston parameters (kappa, theta, sigma, rho) are estimated **once, on the
training period only** (rows with `split == "train"`, 2010-07-20 to 2018-12-31),
by method of moments on daily VIX and NIFTY, and kept fixed on the test period
(2019-01-01 to 2026-10-21). Do **not** tune them to make Heston look better.

### Hard rules
1. **Do not modify any existing file** in the repo. Only create the 11 new files
   listed in step 3. (Outputs go to a new folder `results/backtest_heston/`.)
2. Do not commit or push unless the user explicitly asks. `*.npz` files are
   git-ignored by the repo on purpose; leave that alone.
3. Do not edit the LaTeX report.
4. Do not change numbers, defaults or parameters in the code below.
5. If any check in step 5 or 7 fails, stop and report it; do not "fix" the
   code by loosening tests.

---

## 1. Set up the machine

Requirements: `git`, Python **3.13 or 3.14** (3.13.18 and 3.14.7 both worked),
internet access to GitHub and PyPI.

```bash
git clone --recurse-submodules https://github.com/shrirang73/macf242.git
cd macf242
git checkout beeb9551b342cb3a0f8e63ee3144e4dfd6de4cd7   # optional: exact tested commit; skip if told to use latest main
git submodule update --init --recursive
```

The submodule `external/hedging_rough_hawkes_heston` (authors' code, commit
`c6a65578d62c8b90b53d62b757b2c6a91a436fec`) **must** be present: every script in
`src/` imports `src/upstream.py`, which raises `ImportError` if
`external/hedging_rough_hawkes_heston/numerics/` is missing. Check:

```bash
ls external/hedging_rough_hawkes_heston/numerics/original_market_stability.py
```

Create a virtual environment and install the pinned packages from the repo:

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:  .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

`requirements.txt` pins numpy==2.5.4, scipy==1.18.1, matplotlib==3.11.2,
pytest==9.1.1, pandas==3.0.6. No other packages are needed.

All commands below are run **from the repo root** (`macf242/`) with the venv
active. Use `python -m ...` exactly as written (the code uses package-relative
imports, so `python src/backtest_heston.py` will NOT work).

---

## 2. Check the existing repo works before adding anything

```bash
python -m pytest tests -q
```

Expected: all existing tests pass (41 checks across 4 files). If they fail, the
environment is wrong; fix the environment (submodule, Python, packages) before
continuing.

Input data used by the new code (already tracked in git, nothing to download):
`results/regimes/regime_labels.csv`, columns
`date,split,nifty,logret,vix,vix_verified,vix_filled,special_session,rv21,ms_prob_stress,vix_q75,vix_hyst,rv21_q75,ms_filter`,
3,9xx daily rows from 2010-07-20 to 2026-10-21. `split` is `train` or `test`.

Existing functions the new code reuses (do not change them):
- `src/backtest_real.py`: `YEAR=252`, `PLACEBO_LAG=252`, `LABELS_CSV`, `bs_call`,
  `bs_delta`, `load_panel`, `label_variants`, `option_starts`, `build_paths`,
  `target_deltas`, `build_rules`, `evaluate_period`.
- `src/rebalancing.py`: `held_positions(target, rule, proxy)`,
  `trading_outcome(phi, stock)`.
- `src/backtest_analysis.py`: `load`, `pnl`, `adjusted`, `best_rule`, `family`,
  `label_of`, and its CLI.
- `src/metrics.py`: `block_bootstrap_se`.
- `src/upstream.py`: `PROJECT_ROOT`.

---

## 3. Create these 11 files (exact contents)

| new file | purpose |
|---|---|
| `src/heston.py` | Heston price, delta, dC/dv, minimum-variance delta (Fourier / Gil-Pelaez, "little trap" characteristic function, Gauss-Legendre quadrature, vectorised) + parameter estimation |
| `src/backtest_heston.py` | Backtest identical to `backtest_real.py` except the target hedge (`bs`, `heston`, `heston_mv`) |
| `src/compare_hedges.py` | Side-by-side table: hedges x strategies x costs, rules picked on train, test RMSE + VaR/ES + significance vs BS |
| `src/backtest_heston_rolling.py` | Robustness check: Heston parameters re-estimated every month from the trailing 252 (or 126) trading days, test period only |
| `tests/test_heston_rolling.py` | 4 checks (incl. expanding window): monthly parameters use only past data, equal a direct estimate, one option by hand |
| `src/rough_heston.py` | Rough Heston (= rough Hawkes-Heston without jumps): fractional Riccati (Adams scheme), price, delta, minimum-variance delta with flat forward variance = VIX^2; roughness estimator; VIX-variogram fit of lam, nu |
| `src/backtest_rough.py` | NIFTY backtest with rough Heston hedges (alpha estimated ~0.55) and the same framework at alpha = 1 as control |
| `tests/test_rough_heston.py` | 8 checks: alpha = 1 equals heston.py exactly, convergence, Monte Carlo reference prices, roughness estimator, train-only estimation |
| `src/pricing_test.py` | Pricing test on traded NIFTY calls (paper's option: ATM, ~3 months, plus 0.90-1.10 smile): BS vs Heston vs rough Heston vs alpha = 1 control, all fed only that day's VIX |
| `tests/test_pricing_test.py` | 2 checks on the option-data selection and the BS column (skipped if no option data) |
| `tests/test_heston.py` | 14 checks: benchmark price, BS limit, greeks vs finite differences, estimation on simulated data, train-only estimation, `bs` reproduces old backtest exactly, one option by hand |

Use UTF-8, LF or CRLF line endings both fine. File contents follow.

### `src/heston.py`

```python
"""Heston (1993) model: option price, delta and minimum-variance delta.

Model (zero interest rate, no dividends), under one measure used for both pricing
and hedging:

    dS = S sqrt(v) dW1
    dv = kappa (theta - v) dt + sigma sqrt(v) dW2,     corr(dW1, dW2) = rho

Heston is the alpha = 1, no-jump special case of the rough Hawkes--Heston model.

Pricing is by Fourier inversion (Gil-Pelaez) of the two probabilities
    C = S P1 - K P2,
using the numerically stable "little trap" form of the characteristic function
(Albrecher et al. 2007). The integral is done by Gauss--Legendre quadrature on a
frequency grid scaled by the option's total volatility, vectorised over options.

Hedge ratios
------------
* ``heston_delta``      dC/dS = P1                       (Heston delta; r = 0)
* ``minvar_delta``      dC/dS + (rho sigma / S) dC/dv    (locally risk-minimising
  delta: also hedges the part of the variance move that is correlated with S;
  Hull & White 2017, Bartlett 2006, Poulsen et al. 2008)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

CHUNK = 4000  # options per quadrature batch (memory control)


@dataclass(frozen=True)
class HestonParams:
    kappa: float  # speed of mean reversion of v (per year)
    theta: float  # long-run variance
    sigma: float  # volatility of variance
    rho: float    # correlation between price and variance shocks

    def as_dict(self) -> dict:
        return {"kappa": self.kappa, "theta": self.theta, "sigma": self.sigma, "rho": self.rho}


def _nodes(n: int, umax: float):
    x, w = np.polynomial.legendre.leggauss(n)
    return 0.5 * umax * (x + 1.0), 0.5 * umax * w


def _terms(phi, tau, v, p: HestonParams, j: int):
    """exp(C + D v) and D of the characteristic function of ln S_T (little-trap form).

    j = 1: share-measure probability P1;  j = 2: risk-neutral probability P2.
    """
    u, b = (0.5, p.kappa - p.rho * p.sigma) if j == 1 else (-0.5, p.kappa)
    sig2 = p.sigma**2
    i_phi = 1j * phi
    q = b - p.rho * p.sigma * i_phi
    d = np.sqrt(q * q - sig2 * (2.0 * u * i_phi - phi * phi))
    g = (q - d) / (q + d)
    e = np.exp(-d * tau)
    D = (q - d) / sig2 * (1.0 - e) / (1.0 - g * e)
    C = p.kappa * p.theta / sig2 * ((q - d) * tau - 2.0 * np.log((1.0 - g * e) / (1.0 - g)))
    return np.exp(C + D * v), D


def _batch(S, K, tau, v, p: HestonParams, n: int, umax: float):
    """P1, P2, dP1/dv, dP2/dv for 1-d arrays S, K, tau, v."""
    u, w = _nodes(n, umax)
    scale = np.sqrt(0.5 * (v + p.theta) * tau)           # total-volatility scale, shape (m,)
    phi = u[None, :] / scale[:, None]                    # frequency grid, shape (m, n)
    jac = w[None, :] / scale[:, None]
    x = np.log(S / K)[:, None]
    out = []
    for j in (1, 2):
        f, D = _terms(phi, tau[:, None], v[:, None], p, j)
        kernel = np.exp(1j * phi * x) / (1j * phi)
        P = 0.5 + np.sum(np.real(kernel * f) * jac, axis=1) / np.pi
        dP = np.sum(np.real(kernel * f * D) * jac, axis=1) / np.pi
        out.append((P, dP))
    (p1, dp1), (p2, dp2) = out
    return p1, p2, dp1, dp2


def heston_quantities(S, K, tau, v, p: HestonParams, n: int = 256, umax: float = 30.0) -> dict:
    """Call price, delta (P1) and dC/dv. Inputs broadcast to a common shape.

    tau in years, v the instantaneous variance (not volatility).
    """
    S, K, tau, v = np.broadcast_arrays(*(np.asarray(a, dtype=float) for a in (S, K, tau, v)))
    shape = S.shape
    s, k, t, vv = (a.ravel() for a in (S, K, tau, v))
    keys = ("p1", "p2", "dp1", "dp2")
    res = {key: np.empty(s.size) for key in keys}
    for lo in range(0, s.size, CHUNK):
        sl = slice(lo, lo + CHUNK)
        for key, val in zip(keys, _batch(s[sl], k[sl], t[sl], vv[sl], p, n, umax)):
            res[key][sl] = val
    call = s * res["p1"] - k * res["p2"]
    dcdv = s * res["dp1"] - k * res["dp2"]
    return {"call": call.reshape(shape), "delta": res["p1"].reshape(shape),
            "dcdv": dcdv.reshape(shape), "p2": res["p2"].reshape(shape)}


def heston_call(S, K, tau, v, p: HestonParams, **kw):
    return heston_quantities(S, K, tau, v, p, **kw)["call"]


def heston_delta(S, K, tau, v, p: HestonParams, **kw):
    return heston_quantities(S, K, tau, v, p, **kw)["delta"]


def minvar_delta(S, K, tau, v, p: HestonParams, **kw):
    q = heston_quantities(S, K, tau, v, p, **kw)
    return q["delta"] + p.rho * p.sigma / np.asarray(S, dtype=float) * q["dcdv"]


# ---------------------------------------------------------------------------
# Parameter estimation from the VIX and index history (training period only)
# ---------------------------------------------------------------------------


def estimate_params(vix_pct: np.ndarray, price: np.ndarray, dt: float = 1.0 / 252.0) -> HestonParams:
    """Method-of-moments Heston parameters from daily closes.

    v_t = (VIX_t / 100)^2 is used as the instantaneous variance (a simplification:
    VIX is a 30-day risk-neutral average, not the instantaneous variance).

    * v_{t+1} = a + b v_t + e_t   (OLS)  ->  kappa = -ln(b)/dt,  theta = a/(1-b)
    * Var(e_t | v_t) = sigma^2 v_t dt     ->  sigma^2 = mean(e_t^2 / v_t) / dt
    * rho = corr(r_{t+1}/sqrt(v_t), e_t/sqrt(v_t)),  r = daily log return
    """
    vix_pct = np.asarray(vix_pct, dtype=float)
    price = np.asarray(price, dtype=float)
    if vix_pct.shape != price.shape or vix_pct.ndim != 1:
        raise ValueError("vix and price must be 1-d arrays of equal length")
    v = (vix_pct / 100.0) ** 2
    v0, v1 = v[:-1], v[1:]
    r = np.diff(np.log(price))
    b, a = np.polyfit(v0, v1, 1)
    if not 0.0 < b < 1.0:
        raise ValueError(f"AR(1) slope {b:.4f} outside (0,1): variance not mean reverting")
    resid = v1 - (a + b * v0)
    kappa = -np.log(b) / dt
    theta = a / (1.0 - b)
    sigma = float(np.sqrt(np.mean(resid**2 / v0) / dt))
    rho = float(np.corrcoef(r / np.sqrt(v0), resid / np.sqrt(v0))[0, 1])
    return HestonParams(kappa=float(kappa), theta=float(theta), sigma=sigma, rho=rho)
```

### `src/backtest_heston.py`

```python
"""Real-data backtest with Heston hedges instead of the Black--Scholes delta.

Same design as ``backtest_real.py`` (1-month ATM NIFTY calls sold at every
close, premium = BS price with India VIX, P&L per unit notional, rules fixed /
regime / band, placebos, costs applied later by ``backtest_analysis.py``). The
ONLY change is the target hedge ratio held by the rules:

    bs         BS delta with sigma = VIX/100           (reproduces backtest_real)
    heston     Heston delta dC/dS = P1                 v = (VIX/100)^2
    heston_mv  Heston minimum-variance delta
               dC/dS + (rho sigma / S) dC/dv           v = (VIX/100)^2

Heston parameters (kappa, theta, sigma, rho) are estimated ONCE on the training
period (split == "train", 2010-07-20 .. 2018-12-31) and kept fixed for the test
period, so the test is out of sample. The premium is the same for every hedge
(BS with VIX = the market-price proxy), so differences in P&L come only from
the hedge.

Heston is the alpha = 1, no-jump special case of the rough Hawkes--Heston model.

Outputs: results/backtest_heston/<hedge>/maturity_<m>/{per_option_train.npz,
per_option_test.npz, config.json}, readable by ``backtest_analysis.py``.

Usage: python -m src.backtest_heston [--maturity 21] [--hedges bs heston heston_mv]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import backtest_real as bt
from . import heston as hs
from . import rebalancing as rb
from .upstream import PROJECT_ROOT

OUT = PROJECT_ROOT / "results" / "backtest_heston"
HEDGES = ("bs", "heston", "heston_mv")


def train_params(panel: pd.DataFrame) -> hs.HestonParams:
    """Heston parameters from the training rows only (no test information)."""
    train = panel[panel["split"] == "train"]
    return hs.estimate_params(train["vix"].to_numpy(), train["nifty"].to_numpy(),
                              dt=1.0 / bt.YEAR)


def target_hedge(stock: np.ndarray, vol: np.ndarray, hedge: str,
                 params: hs.HestonParams | None, strike: float = 1.0) -> np.ndarray:
    """Target holdings at decision closes k = 0..N-1, shape (options, N)."""
    if hedge == "bs":
        return bt.target_deltas(stock, vol, strike)
    n_steps = stock.shape[1] - 1
    tau = np.broadcast_to(((n_steps - np.arange(n_steps)) / bt.YEAR)[None, :],
                          (stock.shape[0], n_steps))
    s = stock[:, :-1]
    v = vol[:, :-1] ** 2
    if hedge == "heston":
        return hs.heston_delta(s, strike, tau, v, params)
    if hedge == "heston_mv":
        return hs.minvar_delta(s, strike, tau, v, params)
    raise ValueError(f"unknown hedge {hedge!r}")


def evaluate_period(panel: pd.DataFrame, period: str, maturity: int,
                    label_names: list[str], hedge: str,
                    params: hs.HestonParams | None) -> dict:
    labels = bt.label_variants(panel, label_names)
    variants = list(labels)
    starts = bt.option_starts(panel, period, maturity)
    stock, vol, lab = bt.build_paths(panel, starts, maturity, labels)
    premium = bt.bs_call(1.0, 1.0, maturity / bt.YEAR, vol[:, 0])
    payoff = np.maximum(stock[:, -1] - 1.0, 0.0)
    target = target_hedge(stock, vol, hedge, params)
    if not np.all(np.isfinite(target)):
        raise FloatingPointError(f"non-finite hedge ratios for {hedge}")
    out = {"start_dates": panel.index[starts].strftime("%Y-%m-%d").to_numpy().astype("U10"),
           "premium": premium, "payoff": payoff, "target0": target[:, 0]}
    for name, rule, variant in bt.build_rules(variants, maturity):
        proxy = lab[variant] if variant is not None else None
        phi, _ = rb.held_positions(target, rule, proxy)
        res = rb.trading_outcome(phi, stock)
        out[f"gain|{name}"] = res["gain"]
        out[f"notional|{name}"] = (res["notional_initial"] + res["notional_rebalance"]
                                   + res["notional_terminal"])
        out[f"trades|{name}"] = res["trades"]
    return out


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--maturity", type=int, default=21, help="trading days")
    parser.add_argument("--hedges", nargs="+", default=list(HEDGES), choices=HEDGES)
    parser.add_argument("--labels", nargs="+",
                        default=["vix_hyst", "vix_q75", "rv21_q75", "ms_filter"])
    parser.add_argument("--labels-csv", type=Path, default=bt.LABELS_CSV)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args(argv)

    panel = bt.load_panel(args.labels_csv)
    params = train_params(panel)
    print("Heston parameters (train):", params.as_dict())
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "heston_params.json").write_text(json.dumps(
        {**params.as_dict(), "feller_2kt_minus_s2": 2 * params.kappa * params.theta - params.sigma**2,
         "estimated_on": "split == train", "variance_input": "(VIX/100)^2"}, indent=2))

    for hedge in args.hedges:
        out = args.out / hedge / f"maturity_{args.maturity}"
        out.mkdir(parents=True, exist_ok=True)
        config = {"maturity_days": args.maturity, "labels": args.labels,
                  "labels_csv": str(args.labels_csv), "year_days": bt.YEAR,
                  "placebo_lag": bt.PLACEBO_LAG, "hedge": hedge,
                  "heston_params": params.as_dict() if hedge != "bs" else None,
                  "periods": {}}
        for period in ("train", "test"):
            res = evaluate_period(panel, period, args.maturity, args.labels, hedge,
                                  params if hedge != "bs" else None)
            np.savez_compressed(out / f"per_option_{period}.npz", **res)
            config["periods"][period] = {
                "options": int(len(res["premium"])),
                "first_start": str(res["start_dates"][0]),
                "last_start": str(res["start_dates"][-1]),
                "mean_premium": float(res["premium"].mean()),
                "mean_payoff": float(res["payoff"].mean()),
                "mean_initial_hedge": float(res["target0"].mean()),
            }
            print(hedge, period, config["periods"][period])
        (out / "config.json").write_text(json.dumps(config, indent=2))


if __name__ == "__main__":
    main()
```

### `src/compare_hedges.py`

```python
"""Compare the BS, Heston and Heston minimum-variance hedges on NIFTY (test period).

For each hedge and cost level, the best rule of each family (fixed / regime with
the main label / band) is PICKED ON THE TRAIN PERIOD of that hedge, then
evaluated on the test period, with and without the COVID window. Reported per
(hedge, strategy):

    rmse_bp      sqrt(J), J = Var(e) + (E[cost])^2  (same criterion as the project)
    mean_bp      mean P&L of the short-call + hedge position
    sd_bp        standard deviation of the P&L
    var95/var99  95% / 99% Value at Risk of the loss (loss = -P&L)
    es95/es99    expected shortfall = mean loss beyond that VaR
    worst_bp     largest loss
    trades       mean number of rebalances per option
    vs_bs_*      change in mean squared (cost-adjusted) error vs the BS hedge with
                 the same strategy family, % and z (moving-block bootstrap SE)

All numbers in basis points of notional (1 bp = 0.01%).

Usage: python -m src.compare_hedges [--root results/backtest_heston] [--maturity 21]
       [--hedges bs heston heston_mv ...] [--name comparison]
The first hedge listed is the reference ("vs_bs_*" columns compare against it;
keep bs first). Writes <root>/<name>.csv and <root>/<name>.md.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

from . import backtest_analysis as ba
from .metrics import block_bootstrap_se
from .upstream import PROJECT_ROOT

BP = 1e4
KAPPAS_BP = (0.0, 5.0, 20.0)
COVID = ("2020-01-15", "2020-06-30")
HEDGES = ("bs", "heston", "heston_mv")
FAMILIES = ("fixed", "regime", "band")


def tail(e: np.ndarray) -> dict:
    loss = -e
    var95, var99 = np.quantile(loss, 0.95), np.quantile(loss, 0.99)
    return {"var95_bp": var95 * BP, "es95_bp": loss[loss >= var95].mean() * BP,
            "var99_bp": var99 * BP, "es99_bp": loss[loss >= var99].mean() * BP,
            "worst_bp": loss.max() * BP}


def pick(train: dict, kappa: float, fam: str, main_label: str) -> str:
    if fam == "regime":
        return ba.best_rule(train, kappa,
                            lambda r: ba.family(r) == "regime" and ba.label_of(r) == main_label)
    return ba.best_rule(train, kappa, lambda r: ba.family(r) == fam)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT / "results" / "backtest_heston")
    parser.add_argument("--maturity", type=int, default=21)
    parser.add_argument("--main-label", default="vix_hyst")
    parser.add_argument("--hedges", nargs="+", default=list(HEDGES))
    parser.add_argument("--name", default="comparison", help="output file stem")
    args = parser.parse_args(argv)

    hedges = tuple(args.hedges)
    dirs = {h: args.root / h / f"maturity_{args.maturity}" for h in hedges}
    block = 2 * args.maturity
    rows = []
    for sample, exclude in (("test_all", None), ("test_excl_covid", COVID)):
        train = {h: ba.load(d, "train") for h, d in dirs.items()}
        test = {h: ba.load(d, "test", exclude) for h, d in dirs.items()}
        for kbp in KAPPAS_BP:
            kappa = kbp / BP
            for fam in FAMILIES:
                ref = None
                for hedge in hedges:
                    rule = pick(train[hedge], kappa, fam, args.main_label)
                    data = test[hedge]
                    e = ba.pnl(data, rule, kappa)
                    adj = ba.adjusted(data, rule, kappa)
                    row = {"sample": sample, "kappa_bp": kbp, "strategy": fam,
                           "hedge": hedge, "rule_picked_on_train": rule,
                           "options": len(e),
                           "rmse_bp": math.sqrt(np.mean(adj**2)) * BP,
                           "mean_bp": e.mean() * BP, "sd_bp": e.std() * BP,
                           **tail(e),
                           "trades": float(data[f"trades|{rule}"].mean())}
                    if hedge == hedges[0]:
                        ref = adj
                        row["vs_bs_mse_change_pct"] = 0.0
                        row["vs_bs_z"] = 0.0
                    else:
                        d = adj**2 - ref**2
                        se = block_bootstrap_se(d, block)
                        row["vs_bs_mse_change_pct"] = 100 * d.mean() / np.mean(ref**2)
                        row["vs_bs_z"] = d.mean() / se if se > 0 else 0.0
                    rows.append(row)

    with (args.root / f"{args.name}.csv").open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(rows)

    params = json.loads((args.root / "heston_params.json").read_text())
    lines = ["# Heston vs Black-Scholes hedges on NIFTY (test period, rules picked on train)", "",
             "Heston parameters (estimated on train): " + ", ".join(
                 f"{k}={params[k]:.4g}" for k in ("kappa", "theta", "sigma", "rho")), "",
             "All values in bp of notional. Loss = -P&L. vs BS: change in mean squared error "
             "vs the BS hedge with the same strategy (negative = Heston better); "
             "|z| > 2 is roughly significant.", ""]
    head = ("| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 "
            "| ES99 | worst | trades | vs BS % | z |")
    for sample in ("test_all", "test_excl_covid"):
        lines += [f"## {sample}", "", head, "|" + "---|" * 15]
        for r in rows:
            if r["sample"] != sample:
                continue
            lines.append(
                f"| {sample} | {r['kappa_bp']:g} | {r['strategy']} | {r['hedge']} "
                f"| {r['rule_picked_on_train']} | {r['rmse_bp']:.1f} | {r['mean_bp']:.1f} "
                f"| {r['sd_bp']:.1f} | {r['var95_bp']:.1f} | {r['es95_bp']:.1f} "
                f"| {r['es99_bp']:.1f} | {r['worst_bp']:.1f} | {r['trades']:.1f} "
                f"| {r['vs_bs_mse_change_pct']:+.1f} | {r['vs_bs_z']:+.2f} |")
        lines.append("")
    (args.root / f"{args.name}.md").write_text("\n".join(lines))
    print(f"wrote {args.root}/{args.name}.csv and {args.name}.md")


if __name__ == "__main__":
    main()
```

### `tests/test_heston.py`

```python
"""Checks for the Heston pricer/hedges (src/heston.py) and the Heston backtest.

Run: python -m pytest tests/test_heston.py -q
"""

from __future__ import annotations

import numpy as np
import pytest

from src import backtest_heston as bh
from src import backtest_real as bt
from src import heston as hs
from src import rebalancing as rb

NIFTY_LIKE = hs.HestonParams(kappa=8.6, theta=0.0337, sigma=0.341, rho=-0.526)


# --- 1. Pricing ----------------------------------------------------------------------


def test_reference_price_fang_oosterlee():
    """Benchmark from Fang & Oosterlee (2008, COS method), r = q = 0: 5.785155450."""
    p = hs.HestonParams(kappa=1.5768, theta=0.0398, sigma=0.5751, rho=-0.5711)
    price = float(hs.heston_call(100.0, 100.0, 1.0, 0.0175, p))
    assert abs(price - 5.785155450) < 1e-6


def test_small_vol_of_vol_gives_black_scholes():
    """sigma -> 0 and v0 = theta: variance is constant, so Heston = BS(sqrt(theta))."""
    p = hs.HestonParams(kappa=3.0, theta=0.04, sigma=1e-4, rho=-0.5)
    s = np.array([0.9, 1.0, 1.1])
    tau = 21 / 252
    q = hs.heston_quantities(s, 1.0, tau, 0.04, p)
    assert np.max(np.abs(q["call"] - bt.bs_call(s, 1.0, tau, 0.2))) < 1e-6
    assert np.max(np.abs(q["delta"] - bt.bs_delta(s, 1.0, tau, 0.2))) < 1e-5


def test_put_call_parity_and_bounds():
    """P2 is a probability; call within (S-K)^+ <= C <= S; put = C - S + K >= 0."""
    s = np.linspace(0.8, 1.2, 9)
    q = hs.heston_quantities(s, 1.0, 10 / 252, 0.15**2, NIFTY_LIKE)
    assert np.all(q["call"] >= np.maximum(s - 1.0, 0.0) - 1e-10)
    assert np.all(q["call"] <= s)
    assert np.all((q["p2"] >= -1e-10) & (q["p2"] <= 1 + 1e-10))
    assert np.all(q["delta"] >= -1e-10) and np.all(q["delta"] <= 1 + 1e-10)


# --- 2. Greeks are derivatives of the price ------------------------------------------


@pytest.mark.parametrize("s,tau,v", [(1.0, 21 / 252, 0.15**2), (0.95, 5 / 252, 0.3**2),
                                     (1.07, 15 / 252, 0.1**2)])
def test_delta_and_vega_are_finite_differences(s, tau, v):
    h = 1e-5
    q = hs.heston_quantities(s, 1.0, tau, v, NIFTY_LIKE)
    fd_s = (hs.heston_call(s + h, 1.0, tau, v, NIFTY_LIKE)
            - hs.heston_call(s - h, 1.0, tau, v, NIFTY_LIKE)) / (2 * h)
    hv = 1e-6
    fd_v = (hs.heston_call(s, 1.0, tau, v + hv, NIFTY_LIKE)
            - hs.heston_call(s, 1.0, tau, v - hv, NIFTY_LIKE)) / (2 * hv)
    assert abs(fd_s - q["delta"]) < 1e-6
    assert abs(fd_v - q["dcdv"]) < 1e-4 * max(1.0, abs(fd_v))


def test_minvar_delta_formula():
    s, tau, v = 1.02, 12 / 252, 0.18**2
    q = hs.heston_quantities(s, 1.0, tau, v, NIFTY_LIKE)
    expected = q["delta"] + NIFTY_LIKE.rho * NIFTY_LIKE.sigma / s * q["dcdv"]
    assert abs(hs.minvar_delta(s, 1.0, tau, v, NIFTY_LIKE) - expected) < 1e-12
    # with rho < 0 and dC/dv > 0 the minimum-variance delta is below the Heston delta
    assert hs.minvar_delta(s, 1.0, tau, v, NIFTY_LIKE) < q["delta"]
    zero_rho = hs.HestonParams(NIFTY_LIKE.kappa, NIFTY_LIKE.theta, NIFTY_LIKE.sigma, 0.0)
    assert abs(hs.minvar_delta(s, 1.0, tau, v, zero_rho)
               - hs.heston_delta(s, 1.0, tau, v, zero_rho)) < 1e-12


def test_vectorised_matches_scalar():
    s = np.array([[0.97, 1.0], [1.03, 1.1]])
    tau = np.array([[5 / 252, 21 / 252], [1 / 252, 10 / 252]])
    v = np.array([[0.01, 0.04], [0.09, 0.02]])
    arr = hs.heston_delta(s, 1.0, tau, v, NIFTY_LIKE)
    for i in range(2):
        for j in range(2):
            assert abs(arr[i, j] - hs.heston_delta(s[i, j], 1.0, tau[i, j], v[i, j],
                                                  NIFTY_LIKE)) < 1e-12


# --- 3. Parameter estimation ---------------------------------------------------------


def test_estimation_recovers_simulated_parameters():
    """Simulate a long daily Heston path (fine Euler steps) and re-estimate."""
    true = hs.HestonParams(kappa=6.0, theta=0.04, sigma=0.4, rho=-0.6)
    rng = np.random.default_rng(1)
    days, sub = 40 * 252, 10
    dt = 1.0 / 252 / sub
    v, logs = true.theta, 0.0
    vs, ss = [v], [logs]
    for _ in range(days):
        z1 = rng.standard_normal(sub)
        z2 = true.rho * z1 + np.sqrt(1 - true.rho**2) * rng.standard_normal(sub)
        for a, b in zip(z1, z2):
            sv = np.sqrt(max(v, 0.0))
            logs += -0.5 * v * dt + sv * np.sqrt(dt) * a
            v = max(v + true.kappa * (true.theta - v) * dt + true.sigma * sv * np.sqrt(dt) * b, 1e-8)
        vs.append(v)
        ss.append(logs)
    vix = 100 * np.sqrt(np.array(vs))
    est = hs.estimate_params(vix, np.exp(np.array(ss)))
    assert abs(est.kappa - true.kappa) / true.kappa < 0.25
    assert abs(est.theta - true.theta) / true.theta < 0.10
    assert abs(est.sigma - true.sigma) / true.sigma < 0.05
    assert abs(est.rho - true.rho) < 0.05


def test_estimation_rejects_bad_input():
    with pytest.raises(ValueError):
        hs.estimate_params(np.ones(5), np.ones(4))


# --- 4. Backtest wiring --------------------------------------------------------------


@pytest.fixture(scope="module")
def panel():
    return bt.load_panel()


def test_train_params_use_train_rows_only(panel):
    p1 = bh.train_params(panel)
    changed = panel.copy()
    test_rows = changed["split"] == "test"
    changed.loc[test_rows, "vix"] = changed.loc[test_rows, "vix"] * 3.0
    p2 = bh.train_params(changed)
    assert p1 == p2
    assert p1.kappa > 0 and p1.theta > 0 and p1.sigma > 0 and -1 < p1.rho < 0


def test_bs_hedge_reproduces_backtest_real(panel):
    """hedge='bs' must give exactly the numbers of the original backtest."""
    labels = ["vix_hyst"]
    old = bt.evaluate_period(panel, "test", 21, labels)
    new = bh.evaluate_period(panel, "test", 21, labels, "bs", None)
    for key in old:
        if key == "start_dates":
            assert np.array_equal(old[key], new[key])
        else:
            assert np.allclose(old[key], new[key], rtol=0, atol=1e-14), key


def test_heston_backtest_one_option_by_hand(panel):
    """Daily rebalancing with the Heston delta: P&L equals a scalar loop."""
    params = bh.train_params(panel)
    maturity = 21
    res = bh.evaluate_period(panel, "test", maturity, ["vix_hyst"], "heston", params)
    i = 100
    t0 = bt.option_starts(panel, "test", maturity)[i]
    price = panel["nifty"].to_numpy()[t0:t0 + maturity + 1]
    vix = panel["vix"].to_numpy()[t0:t0 + maturity + 1] / 100
    s = price / price[0]
    gain, notional, prev = 0.0, 0.0, 0.0
    for k in range(maturity):
        tau = (maturity - k) / 252
        d = float(hs.heston_delta(s[k], 1.0, tau, vix[k] ** 2, params))
        notional += s[k] * abs(d - prev)
        gain += d * (s[k + 1] - s[k])
        prev = d
    notional += s[-1] * abs(prev)
    assert abs(res["gain|fixed/every=1"][i] - gain) < 1e-12
    assert abs(res["notional|fixed/every=1"][i] - notional) < 1e-12
    assert abs(res["premium"][i] - bt.bs_call(1.0, 1.0, maturity / 252, vix[0])) < 1e-15


def test_rules_see_same_targets(panel):
    """Band rule never trades more than daily; all hedges finite and in [0, 1.2]."""
    params = bh.train_params(panel)
    for hedge in ("heston", "heston_mv"):
        res = bh.evaluate_period(panel, "train", 21, ["vix_hyst"], hedge, params)
        assert np.all(res["trades|band/h=0.02"] <= res["trades|fixed/every=1"])
        assert np.all((res["target0"] > 0) & (res["target0"] < 1.2))
```

### `src/backtest_heston_rolling.py`

```python
"""Heston hedges on NIFTY with parameters re-estimated EVERY MONTH (test period).

Robustness check for ``backtest_heston.py``: instead of one parameter set
estimated on 2010-2018, the Heston parameters (kappa, theta, sigma, rho) are
re-estimated at the start of every month from the ``window`` trading days
strictly BEFORE the first trading day of that month (no look-ahead).
``--window 0`` = EXPANDING window: all data from the first day of the panel
(2010-07-20) up to the day before the month (e.g. options starting in March
2020 use 2010-07-20 .. 2020-02-28). Every
option starting in month M is hedged with month M's parameters for its whole
life. If an estimate fails (variance not mean reverting in the window, or a
non-positive theta/sigma), the previous month's parameters are reused.

Only the TEST period (2019-2026) is re-done. The train file is copied from the
fixed-parameter run of the same hedge (``results/backtest_heston/<hedge>/``),
so ``backtest_analysis`` / ``compare_hedges`` pick the same rules on train;
the comparison is therefore purely about the test-period hedge.

Requires: ``python -m src.backtest_heston`` has been run first.

Outputs: results/backtest_heston/<hedge>_roll<window>/maturity_<m>/
  (<hedge>_rollexp/ for the expanding window)
  per_option_train.npz (copy), per_option_test.npz, config.json,
  monthly_params.csv  (month, kappa, theta, sigma, rho, reused_previous)

Usage: python -m src.backtest_heston_rolling [--window 252 | --window 0] [--maturity 21]
"""

from __future__ import annotations

import argparse
import csv
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from . import backtest_real as bt
from . import heston as hs
from . import rebalancing as rb
from .backtest_heston import OUT

LABELS = ["vix_hyst", "vix_q75", "rv21_q75", "ms_filter"]


def monthly_params(panel: pd.DataFrame, months: list, window: int) -> tuple[dict, dict]:
    """Parameters per month from the ``window`` rows before the month's first row
    (window = 0: every row before it, i.e. an expanding window)."""
    period = panel.index.to_period("M")
    params, reused, prev = {}, {}, None
    for m in months:
        first = int(np.argmax(period == m))
        if first < max(window, 252):
            raise ValueError(f"not enough history before {m} for window {window}")
        d = panel.iloc[(first - window if window > 0 else 0):first]
        try:
            p = hs.estimate_params(d["vix"].to_numpy(), d["nifty"].to_numpy(), dt=1.0 / bt.YEAR)
            if not (p.theta > 0 and p.sigma > 0):
                raise ValueError("non-positive theta or sigma")
            prev, reused[m] = p, False
        except ValueError:
            if prev is None:
                raise
            p, reused[m] = prev, True
        params[m] = p
    return params, reused


def evaluate_test(panel: pd.DataFrame, maturity: int, hedge: str, window: int) -> tuple[dict, dict, dict]:
    labels = bt.label_variants(panel, LABELS)
    starts = bt.option_starts(panel, "test", maturity)
    stock, vol, lab = bt.build_paths(panel, starts, maturity, labels)
    start_month = panel.index[starts].to_period("M")
    params, reused = monthly_params(panel, sorted(set(start_month)), window)
    fn = {"heston": hs.heston_delta, "heston_mv": hs.minvar_delta}[hedge]
    n = maturity
    tau = np.broadcast_to(((n - np.arange(n)) / bt.YEAR)[None, :], (len(starts), n))
    target = np.full((len(starts), n), np.nan)
    for m, p in params.items():
        sel = np.asarray(start_month == m)
        target[sel] = fn(stock[sel, :-1], 1.0, tau[sel], vol[sel, :-1] ** 2, p)
    if not np.all(np.isfinite(target)):
        raise FloatingPointError("non-finite hedge ratios")
    out = {"start_dates": panel.index[starts].strftime("%Y-%m-%d").to_numpy().astype("U10"),
           "premium": bt.bs_call(1.0, 1.0, maturity / bt.YEAR, vol[:, 0]),
           "payoff": np.maximum(stock[:, -1] - 1.0, 0.0), "target0": target[:, 0]}
    for name, rule, variant in bt.build_rules(list(labels), maturity):
        phi, _ = rb.held_positions(target, rule, lab[variant] if variant is not None else None)
        res = rb.trading_outcome(phi, stock)
        out[f"gain|{name}"] = res["gain"]
        out[f"notional|{name}"] = (res["notional_initial"] + res["notional_rebalance"]
                                   + res["notional_terminal"])
        out[f"trades|{name}"] = res["trades"]
    return out, params, reused


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--window", type=int, default=252,
                        help="trading days of history; 0 = expanding (all data since 2010)")
    parser.add_argument("--maturity", type=int, default=21)
    parser.add_argument("--root", type=Path, default=OUT)
    args = parser.parse_args(argv)
    panel = bt.load_panel()
    for hedge in ("heston", "heston_mv"):
        src = args.root / hedge / f"maturity_{args.maturity}"
        if not (src / "per_option_train.npz").exists():
            raise FileNotFoundError(f"{src} missing: run python -m src.backtest_heston first")
        tag = "rollexp" if args.window == 0 else f"roll{args.window}"
        out_dir = args.root / f"{hedge}_{tag}" / f"maturity_{args.maturity}"
        out_dir.mkdir(parents=True, exist_ok=True)
        res, params, reused = evaluate_test(panel, args.maturity, hedge, args.window)
        np.savez_compressed(out_dir / "per_option_test.npz", **res)
        shutil.copy(src / "per_option_train.npz", out_dir / "per_option_train.npz")
        config = json.loads((src / "config.json").read_text())
        config.update({"hedge": f"{hedge}_{tag}", "heston_params": "monthly_params.csv",
                       "rolling_window_days": args.window,
                       "train_file": f"copied from {hedge}/ (fixed 2010-2018 parameters)"})
        config["periods"]["test"]["mean_initial_hedge"] = float(res["target0"].mean())
        (out_dir / "config.json").write_text(json.dumps(config, indent=2))
        with (out_dir / "monthly_params.csv").open("w", newline="") as fh:
            w = csv.writer(fh, lineterminator="\n")
            w.writerow(["month", "kappa", "theta", "sigma", "rho", "reused_previous"])
            for m, p in params.items():
                w.writerow([str(m), p.kappa, p.theta, p.sigma, p.rho, reused[m]])
        k = np.array([p.kappa for p in params.values()])
        print(f"{hedge}_{tag}: {len(params)} months, {sum(reused.values())} reused; "
              f"kappa range {k.min():.2f}-{k.max():.2f}; options {len(res['premium'])}")


if __name__ == "__main__":
    main()
```

### `tests/test_heston_rolling.py`

```python
"""Checks for the monthly re-estimated Heston hedge (src/backtest_heston_rolling.py).

Run: python -m pytest tests/test_heston_rolling.py -q
"""

from __future__ import annotations

import numpy as np
import pytest

from src import backtest_heston_rolling as roll
from src import backtest_real as bt
from src import heston as hs


@pytest.fixture(scope="module")
def panel():
    return bt.load_panel()


def test_monthly_params_use_only_past_data(panel):
    """Month M's parameters must not change when data from M onwards is changed."""
    month = panel.index.to_period("M")[panel.index.get_loc(panel.index[panel.index >= "2020-03-01"][0])]
    p1, _ = roll.monthly_params(panel, [month], 252)
    changed = panel.copy()
    later = changed.index >= "2020-03-01"
    changed.loc[later, "vix"] = changed.loc[later, "vix"] * 2.0
    changed.loc[later, "nifty"] = changed.loc[later, "nifty"] * 0.5
    p2, _ = roll.monthly_params(changed, [month], 252)
    assert p1[month] == p2[month]


def test_monthly_params_match_direct_estimate(panel):
    """Parameters for a month = estimate on exactly the 252 rows before its first day."""
    month = panel.index[panel.index >= "2021-06-01"][0].to_period("M")
    params, reused = roll.monthly_params(panel, [month], 252)
    first = int(np.argmax(panel.index.to_period("M") == month))
    d = panel.iloc[first - 252:first]
    direct = hs.estimate_params(d["vix"].to_numpy(), d["nifty"].to_numpy())
    assert params[month] == direct and not reused[month]
    assert d.index[-1] < panel.index[first]


def test_one_option_by_hand(panel):
    """Daily rebalancing with the rolling Heston delta equals a scalar loop."""
    res, params, _ = roll.evaluate_test(panel, 21, "heston", 252)
    i = 300
    t0 = bt.option_starts(panel, "test", 21)[i]
    p = params[panel.index[t0].to_period("M")]
    s = panel["nifty"].to_numpy()[t0:t0 + 22] / panel["nifty"].to_numpy()[t0]
    vix = panel["vix"].to_numpy()[t0:t0 + 22] / 100
    gain = sum(float(hs.heston_delta(s[k], 1.0, (21 - k) / 252, vix[k] ** 2, p)) * (s[k + 1] - s[k])
               for k in range(21))
    assert abs(res["gain|fixed/every=1"][i] - gain) < 1e-12


def test_expanding_window_uses_all_past_data_only(panel):
    """window = 0: month M uses every row from 2010-07-20 to the day before M, nothing after."""
    month = panel.index[panel.index >= "2020-03-01"][0].to_period("M")
    params, _ = roll.monthly_params(panel, [month], 0)
    first = int(np.argmax(panel.index.to_period("M") == month))
    d = panel.iloc[:first]
    assert d.index[0] == panel.index[0] and d.index[-1] < panel.index[first]
    assert params[month] == hs.estimate_params(d["vix"].to_numpy(), d["nifty"].to_numpy())
    changed = panel.copy()
    changed.loc[changed.index >= "2020-03-01", "vix"] *= 2.0
    assert roll.monthly_params(changed, [month], 0)[0][month] == params[month]
```

### `src/rough_heston.py`

```python
"""Rough Heston model: price, delta and minimum-variance delta, plus estimation.

Rough Heston = the rough Hawkes--Heston model of the base paper WITHOUT jumps
(El Euch & Rosenbaum 2019). alpha = 1 gives the classical Heston model.

    dS/S = sqrt(V) dW,
    V_t  = V_0 + int_0^t K(t-s) [lam (theta - V_s) ds + nu sqrt(V_s) dB_s],
    K(t) = t^(alpha-1) / Gamma(alpha),   d<W, B> = rho dt.

Forward-variance form. With xi_t(u) = E[V_u | F_t], the forward variances are
martingales, d xi_t(u) = r(u - t) nu sqrt(V_t) dB_t, where r is the resolvent
of lam*K: R(x) = int_0^x r solves D^alpha R = 1 - lam R, R(0) = 0
(alpha = 1: r(x) = exp(-lam x)). The characteristic function of X_T = ln(S_T/S_t) is

    E[exp(i a X_T) | F_t] = exp( int_0^tau xi_t(T - s) G(a, psi(a, s)) ds ),
    D^alpha psi = G(a, psi) - lam psi,   psi(a, 0) = 0,
    G(a, x) = (-a^2 - i a)/2 + i a rho nu x + nu^2 x^2 / 2.

Approximation used on NIFTY: the forward-variance curve over the option's life
is taken FLAT at today's (VIX/100)^2, so log CF = xi * I(a, tau) with
I(a, tau) = int_0^tau G(a, psi(a, s)) ds.

Hedges (r = 0):
    delta    dC/dS = P1                              (Gil-Pelaez, as in heston.py)
    minvar   dC/dS + (rho nu / S) int_0^tau dC/dxi(t+s) r(s) ds,
  which is d<C,S>/d<S> (V cancels). The functional derivative of log CF at
  xi(t+s) is G(a, psi(a, tau - s)), so the weighted sensitivity uses
  J(a, tau) = int_0^tau G(a, psi(a, tau - s)) r(s) ds. For alpha = 1, J = D(tau)
  of Heston and minvar equals heston.minvar_delta with v = theta (checked in tests).

Numerics: fractional Riccati by the Adams predictor--corrector scheme
(Diethelm et al. 2002), vectorised over the frequency grid; Gil-Pelaez integrals
by the midpoint rule on [0, A(tau)].
"""

from __future__ import annotations

from dataclasses import dataclass
from math import gamma

import numpy as np

CHUNK = 400  # option-days per integration batch (memory control)


@dataclass(frozen=True)
class RoughParams:
    alpha: float  # roughness: kernel t^(alpha-1)/Gamma(alpha); 1 = Heston
    lam: float    # mean reversion
    nu: float     # vol of vol
    rho: float    # correlation of price and variance shocks

    def as_dict(self) -> dict:
        return {"alpha": self.alpha, "lam": self.lam, "nu": self.nu, "rho": self.rho}


# ---------------------------------------------------------------------------
# Fractional Adams scheme for y(t) = I^alpha f(y)(t), y(0) = 0
# ---------------------------------------------------------------------------


def adams(f, alpha: float, h: float, n: int, shape) -> np.ndarray:
    """y on t_k = k h, k = 0..n, for y = (1/Gamma(alpha)) int (t-s)^(alpha-1) f(y(s)) ds."""
    y0 = np.zeros(shape, dtype=complex)
    ys = np.empty((n + 1,) + tuple(np.shape(y0)), dtype=complex)
    fs = np.empty_like(ys)
    ys[0] = y0
    fs[0] = f(y0)
    ca = h**alpha / gamma(alpha + 2.0)
    cb = h**alpha / gamma(alpha + 1.0)
    for k in range(n):
        j = np.arange(k + 1)
        b = cb * ((k + 1 - j) ** alpha - (k - j) ** alpha)
        a = ca * ((k - j + 2.0) ** (alpha + 1) + (k - j + 0.0) ** (alpha + 1)
                  - 2.0 * (k - j + 1.0) ** (alpha + 1))
        a[0] = ca * (k ** (alpha + 1) - (k - alpha) * (k + 1.0) ** alpha)
        hist = fs[:k + 1].reshape(k + 1, -1)
        pred = (b @ hist).reshape(np.shape(y0))
        ys[k + 1] = (a @ hist).reshape(np.shape(y0)) + ca * f(pred)
        fs[k + 1] = f(ys[k + 1])
    return ys


def resolvent_integral(alpha: float, lam: float, h: float, n: int) -> np.ndarray:
    """R(t_k) = int_0^{t_k} r, from D^alpha R = 1 - lam R (alpha = 1: (1-e^{-lam t})/lam).

    Same Adams weights as ``adams`` but with the corrector solved implicitly
    (the equation is linear), so it is stable for any lam * h^alpha.
    """
    R = np.zeros(n + 1)
    F = np.zeros(n + 1)
    F[0] = 1.0
    ca = h**alpha / gamma(alpha + 2.0)
    for k in range(n):
        j = np.arange(k + 1)
        a = ca * ((k - j + 2.0) ** (alpha + 1) + (k - j + 0.0) ** (alpha + 1)
                  - 2.0 * (k - j + 1.0) ** (alpha + 1))
        a[0] = ca * (k ** (alpha + 1) - (k - alpha) * (k + 1.0) ** alpha)
        R[k + 1] = (a @ F[:k + 1] + ca) / (1.0 + ca * lam)
        F[k + 1] = 1.0 - lam * R[k + 1]
    return R


# ---------------------------------------------------------------------------
# Riccati quantities I(a, tau) and J(a, tau) on a frequency grid
# ---------------------------------------------------------------------------


def riccati_IJ(a: np.ndarray, tau: float, p: RoughParams, steps: int = 200):
    """I(a,tau) = int_0^tau G(psi(s)) ds and J(a,tau) = int_0^tau G(psi(tau-s)) dR(s)."""
    a = np.asarray(a, dtype=complex)
    h = tau / steps

    def G(x):
        return 0.5 * (-a * a - 1j * a) + 1j * a * p.rho * p.nu * x + 0.5 * p.nu**2 * x * x

    psi = adams(lambda x: G(x) - p.lam * x, p.alpha, h, steps, a.shape)
    g = G(psi)                                     # (steps+1, n_a)
    I = h * (0.5 * g[0] + g[1:-1].sum(axis=0) + 0.5 * g[-1])
    R = resolvent_integral(p.alpha, p.lam, h, steps)
    dR = np.diff(R)                                # mass of r on [s_j, s_{j+1}]
    gm = 0.5 * (g[::-1][:-1] + g[::-1][1:])        # G(psi(tau - s)) at interval midpoints
    J = (dR[:, None] * gm).sum(axis=0)
    return I, J


class RoughPricer:
    """Price / delta / min-variance delta for flat forward variance xi.

    Pre-computes the Riccati integrals for each time to maturity in ``taus``
    (years) once; then any (S/K, xi) pair is a cheap quadrature.
    """

    def __init__(self, p: RoughParams, taus, xi_min: float, da: float = 0.25,
                 tail: float = 40.0, steps: int = 200):
        self.p = p
        self.grids = {}
        for tau in np.unique(np.asarray(taus, dtype=float)):
            amax = np.sqrt(2.0 * tail / (xi_min * tau))
            n = int(np.ceil(amax / da))
            a = (np.arange(n) + 0.5) * da
            I2, J2 = riccati_IJ(a, tau, p, steps)
            I1, J1 = riccati_IJ(a - 1j, tau, p, steps)
            self.grids[float(tau)] = (a, da, I1, J1, I2, J2)

    def quantities(self, s, tau: float, xi) -> dict:
        """s = S/K (K = 1), xi = flat forward variance; 1-d arrays for one tau."""
        a, da, I1, J1, I2, J2 = self.grids[float(tau)]
        s = np.atleast_1d(np.asarray(s, dtype=float))
        xi = np.atleast_1d(np.asarray(xi, dtype=float))
        out = {k: np.empty(s.size) for k in ("p1", "p2", "dp1", "dp2")}
        for lo in range(0, s.size, CHUNK):
            sl = slice(lo, lo + CHUNK)
            x = np.log(s[sl])[:, None]
            v = xi[sl][:, None]
            kern = np.exp(1j * a[None, :] * x) / (1j * a[None, :]) * da / np.pi
            f1 = np.exp(v * I1[None, :])
            f2 = np.exp(v * I2[None, :])
            out["p1"][sl] = 0.5 + np.real(kern * f1).sum(axis=1)
            out["p2"][sl] = 0.5 + np.real(kern * f2).sum(axis=1)
            out["dp1"][sl] = np.real(kern * f1 * J1[None, :]).sum(axis=1)
            out["dp2"][sl] = np.real(kern * f2 * J2[None, :]).sum(axis=1)
        call = s * out["p1"] - out["p2"]
        wvega = s * out["dp1"] - out["dp2"]
        minvar = out["p1"] + self.p.rho * self.p.nu / s * wvega
        return {"call": call, "delta": out["p1"], "wvega": wvega, "minvar": minvar}


# ---------------------------------------------------------------------------
# Estimation (training data only)
# ---------------------------------------------------------------------------


def roughness_H(log_vol: np.ndarray, lags=range(1, 51), q: float = 2.0) -> float:
    """Gatheral-Jaisson-Rosenbaum: mean |dlog vol over D|^q ~ D^(qH); returns H."""
    x = np.asarray(log_vol, dtype=float)
    lags = np.asarray(list(lags))
    m = [np.mean(np.abs(x[l:] - x[:-l]) ** q) for l in lags]
    return float(np.polyfit(np.log(lags), np.log(m), 1)[0] / q)


def garman_klass_logvol(o, h, l, c) -> np.ndarray:
    """0.5 * log of the Garman-Klass daily variance estimate from OHLC."""
    gk = 0.5 * np.log(h / l) ** 2 - (2 * np.log(2) - 1) * np.log(c / o) ** 2
    if np.any(gk <= 0):
        raise ValueError("non-positive Garman-Klass variance")
    return 0.5 * np.log(gk)


def vix_variogram_shape(alpha: float, lam: float, lags_days, window_days: int = 21,
                        year: int = 252, sub: int = 4, horizon_years: float = 6.0) -> np.ndarray:
    """Model variogram of VIX^2 divided by nu^2 * mean(V).

    VIX^2_t ~ (1/Delta) int_t^{t+Delta} xi_t(u) du  =>  VIX^2_t - mean = int w(t-s) nu sqrt(V) dB_s,
    w(a) = (R(a+Delta) - R(a)) / Delta, and
    E[(VIX^2_{t+h} - VIX^2_t)^2] / (nu^2 E V) = int_0^inf (w(a+h) - w(a))^2 da + int_0^h w(a)^2 da.
    """
    h = 1.0 / (year * sub)
    n = int(horizon_years * year * sub)
    R = resolvent_integral(alpha, lam, h, n + window_days * sub)
    d = window_days * sub
    w = (R[d:d + n + 1] - R[:n + 1]) / (window_days / year)
    out = []
    for lag in lags_days:
        k = lag * sub
        diff = w[k:] - w[:-k]
        out.append(h * np.sum(diff**2) + h * np.sum(w[:k] ** 2))
    return np.array(out)


def fit_lam_nu(vix_pct: np.ndarray, alpha: float, lags_days=range(1, 127),
               lam_grid=None, window_days: int = 21) -> tuple[float, float, dict]:
    """Fit lam, nu to the empirical variogram of VIX^2 (log least squares), alpha fixed."""
    v = (np.asarray(vix_pct, dtype=float) / 100.0) ** 2
    lags = np.asarray(list(lags_days))
    emp = np.array([np.mean((v[l:] - v[:-l]) ** 2) for l in lags])
    vbar = float(v.mean())
    if lam_grid is None:
        lam_grid = np.exp(np.linspace(np.log(0.2), np.log(100.0), 61))
    best = None
    for lam in lam_grid:
        shape = vix_variogram_shape(alpha, lam, lags, window_days)
        log_nu2 = np.mean(np.log(emp) - np.log(vbar * shape))
        loss = float(np.sum((np.log(emp) - log_nu2 - np.log(vbar * shape)) ** 2))
        if best is None or loss < best[0]:
            best = (loss, float(lam), float(np.sqrt(np.exp(log_nu2))))
    loss, lam, nu = best
    edge = lam in (float(lam_grid[0]), float(lam_grid[-1]))
    return lam, nu, {"loss": loss, "mean_variance": vbar, "lam_at_grid_edge": edge}
```

### `src/backtest_rough.py`

```python
"""NIFTY backtest with ROUGH Heston hedges (rough Hawkes--Heston without jumps).

Same design as ``backtest_heston.py`` (premium = BS with VIX, rules, placebos,
costs later); only the target hedge changes:

    rough        rough Heston delta dC/dS              alpha estimated (~0.55)
    rough_mv     rough Heston minimum-variance delta   alpha estimated
    rough_a1     same framework with alpha = 1         (Heston, control)
    rough_mv_a1  same framework with alpha = 1         (Heston, control)

The alpha = 1 versions use exactly the same estimation and approximations, so
"rough_mv" vs "rough_mv_a1" isolates the effect of roughness.

Estimation, training period only (2010-07-20 .. 2018-12-31):
  * alpha = H + 1/2, H from the log-volatility variogram of the Garman--Klass
    daily range volatility of NIFTY (OHLC, data/processed/nifty50.csv),
    lags 1-50 days, q = 2 (Gatheral, Jaisson & Rosenbaum 2018).
  * lam, nu: fit of the model variogram of VIX^2 (VIX^2 = 21-day average of
    forward variance) to the empirical one, lags 1-126 days, alpha fixed.
  * rho: as in heston.estimate_params.
Approximation: the forward-variance curve is flat at (VIX/100)^2 over each
option's remaining life (VIX gives only one 30-day number per day).

Outputs: results/backtest_heston/<hedge>/maturity_21/ (+ rough_params.json).
Usage: python -m src.backtest_rough
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import backtest_real as bt
from . import heston as hs
from . import rebalancing as rb
from . import rough_heston as rh
from .backtest_heston import OUT
from .upstream import PROJECT_ROOT

OHLC_CSV = PROJECT_ROOT / "data" / "processed" / "nifty50.csv"
LABELS = ["vix_hyst", "vix_q75", "rv21_q75", "ms_filter"]
XI_MIN = 0.08**2  # integration-grid floor, below every VIX value in the data (min 9.15)
TRAIN_END = "2018-12-31"


def estimate(panel: pd.DataFrame) -> dict:
    train = panel[panel["split"] == "train"]
    o = pd.read_csv(OHLC_CSV, parse_dates=["date"]).set_index("date")
    o = o[(o.index >= train.index[0]) & (o.index <= TRAIN_END) & ~o["special_session"].astype(bool)]
    H = rh.roughness_H(rh.garman_klass_logvol(o["open"], o["high"], o["low"], o["close"]))
    rho = hs.estimate_params(train["vix"].to_numpy(), train["nifty"].to_numpy()).rho
    out = {"H": H, "ohlc_days": int(len(o))}
    for tag, alpha in (("rough", H + 0.5), ("a1", 1.0)):
        lam, nu, info = rh.fit_lam_nu(train["vix"].to_numpy(), alpha)
        out[tag] = {"alpha": alpha, "lam": lam, "nu": nu, "rho": rho, **info}
    return out


def targets(stock, vol, p: rh.RoughParams, maturity: int) -> tuple[np.ndarray, np.ndarray]:
    """(delta, minvar) at decision closes k = 0..N-1."""
    taus = (maturity - np.arange(maturity)) / bt.YEAR
    pricer = rh.RoughPricer(p, taus, XI_MIN)
    delta = np.empty((stock.shape[0], maturity))
    minvar = np.empty_like(delta)
    for k in range(maturity):
        q = pricer.quantities(stock[:, k], taus[k], vol[:, k] ** 2)
        delta[:, k], minvar[:, k] = q["delta"], q["minvar"]
    return delta, minvar


def evaluate(panel, period, maturity, hedge_targets: dict) -> dict:
    """hedge_targets: name -> function(stock, vol) -> target array."""
    labels = bt.label_variants(panel, LABELS)
    starts = bt.option_starts(panel, period, maturity)
    stock, vol, lab = bt.build_paths(panel, starts, maturity, labels)
    base = {"start_dates": panel.index[starts].strftime("%Y-%m-%d").to_numpy().astype("U10"),
            "premium": bt.bs_call(1.0, 1.0, maturity / bt.YEAR, vol[:, 0]),
            "payoff": np.maximum(stock[:, -1] - 1.0, 0.0)}
    results = {}
    for name, target in hedge_targets(stock, vol).items():
        if not np.all(np.isfinite(target)):
            raise FloatingPointError(f"non-finite hedge ratios for {name}")
        out = dict(base, target0=target[:, 0])
        for rname, rule, variant in bt.build_rules(list(labels), maturity):
            phi, _ = rb.held_positions(target, rule, lab[variant] if variant is not None else None)
            res = rb.trading_outcome(phi, stock)
            out[f"gain|{rname}"] = res["gain"]
            out[f"notional|{rname}"] = (res["notional_initial"] + res["notional_rebalance"]
                                        + res["notional_terminal"])
            out[f"trades|{rname}"] = res["trades"]
        results[name] = out
    return results


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--maturity", type=int, default=21)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args(argv)
    panel = bt.load_panel()
    est = estimate(panel)
    print(json.dumps(est, indent=2))
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "rough_params.json").write_text(json.dumps(est, indent=2))
    params = {tag: rh.RoughParams(est[tag]["alpha"], est[tag]["lam"], est[tag]["nu"], est[tag]["rho"])
              for tag in ("rough", "a1")}

    def hedge_targets(stock, vol):
        out = {}
        for tag, suffix in (("rough", ""), ("a1", "_a1")):
            d, mv = targets(stock, vol, params[tag], args.maturity)
            out[f"rough{suffix}"], out[f"rough_mv{suffix}"] = d, mv
        return out

    for period in ("train", "test"):
        for name, res in evaluate(panel, period, args.maturity, hedge_targets).items():
            d = args.out / name / f"maturity_{args.maturity}"
            d.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(d / f"per_option_{period}.npz", **res)
            cfg_path = d / "config.json"
            cfg = json.loads(cfg_path.read_text()) if cfg_path.exists() and period == "test" else {
                "maturity_days": args.maturity, "labels": LABELS, "labels_csv": str(bt.LABELS_CSV),
                "year_days": bt.YEAR, "placebo_lag": bt.PLACEBO_LAG, "hedge": name,
                "rough_params": params["a1" if name.endswith("_a1") else "rough"].as_dict(),
                "forward_variance": "flat at (VIX/100)^2", "periods": {}}
            cfg["periods"][period] = {
                "options": int(len(res["premium"])), "first_start": str(res["start_dates"][0]),
                "last_start": str(res["start_dates"][-1]),
                "mean_premium": float(res["premium"].mean()), "mean_payoff": float(res["payoff"].mean()),
                "mean_initial_hedge": float(res["target0"].mean())}
            cfg_path.write_text(json.dumps(cfg, indent=2))
            print(name, period, cfg["periods"][period])


if __name__ == "__main__":
    main()
```

### `tests/test_rough_heston.py`

```python
"""Checks for the rough Heston pricer/hedges (src/rough_heston.py) and its backtest.

Run: python -m pytest tests/test_rough_heston.py -q
"""

from __future__ import annotations

from math import gamma

import numpy as np
import pytest

from src import backtest_real as bt
from src import backtest_rough as br
from src import heston as hs
from src import rough_heston as rh


def test_resolvent_closed_forms():
    h = 1 / 1008
    t = np.arange(2001) * h
    R = rh.resolvent_integral(1.0, 10.0, h, 2000)
    assert np.max(np.abs(R - (1 - np.exp(-10.0 * t)) / 10.0)) < 1e-6
    R0 = rh.resolvent_integral(0.55, 0.0, h, 2000)
    assert np.max(np.abs(R0 - t**0.55 / gamma(1.55))) < 1e-10


@pytest.mark.parametrize("tau_days", [1, 10, 21])
def test_alpha_one_equals_heston(tau_days):
    """alpha = 1, flat forward variance xi = v = theta: price, delta, min-var delta = heston.py."""
    p = rh.RoughParams(1.0, 8.6, 0.34, -0.53)
    hp = hs.HestonParams(8.6, 0.03, 0.34, -0.53)
    tau = tau_days / 252
    s = np.array([0.9, 0.97, 1.0, 1.03, 1.1])
    q = rh.RoughPricer(p, [tau], xi_min=0.0081).quantities(s, tau, np.full(5, 0.03))
    assert np.max(np.abs(q["call"] - hs.heston_call(s, 1.0, tau, 0.03, hp))) < 1e-7
    assert np.max(np.abs(q["delta"] - hs.heston_delta(s, 1.0, tau, 0.03, hp))) < 1e-6
    assert np.max(np.abs(q["minvar"] - hs.minvar_delta(s, 1.0, tau, 0.03, hp))) < 1e-6


def test_rough_converges_in_time_steps():
    p = rh.RoughParams(0.55, 3.0, 0.15, -0.6)
    tau = 21 / 252
    s, xi = np.array([0.95, 1.0, 1.05]), np.full(3, 0.04)
    a = rh.RoughPricer(p, [tau], 0.0064, steps=200).quantities(s, tau, xi)
    b = rh.RoughPricer(p, [tau], 0.0064, steps=800).quantities(s, tau, xi)
    for k in ("call", "delta", "minvar"):
        assert np.max(np.abs(a[k] - b[k])) < 2e-5


def test_rough_price_against_monte_carlo():
    """Reference values from a 40,000-path Volterra Euler simulation (420 steps, seed 3):
    calls at K = 0.95, 1.00, 1.05 = 0.057023, 0.022686, 0.005104 (s.e. 2.3e-4, 1.6e-4, 7e-5)."""
    p = rh.RoughParams(0.55, 3.0, 0.15, -0.6)
    tau = 21 / 252
    K = np.array([0.95, 1.0, 1.05])
    q = rh.RoughPricer(p, [tau], 0.0064).quantities(1 / K, tau, np.full(3, 0.04))
    mc, se = np.array([0.057023, 0.022686, 0.005104]), np.array([2.3e-4, 1.6e-4, 7e-5])
    assert np.all(np.abs(q["call"] * K - mc) < 3 * se)


def test_roughness_estimator_on_known_series():
    rng = np.random.default_rng(0)
    n, H = 4096, 0.1
    k = np.arange(n)
    g = 0.5 * (np.abs(k + 1) ** (2 * H) - 2 * np.abs(k) ** (2 * H) + np.abs(k - 1) ** (2 * H))
    c = np.concatenate([g, g[-2:0:-1]])
    lam = np.clip(np.fft.fft(c).real, 0, None)
    z = rng.standard_normal(len(c)) + 1j * rng.standard_normal(len(c))
    x = np.cumsum(np.fft.fft(np.sqrt(lam / len(c)) * z).real[:n])
    assert abs(rh.roughness_H(x) - H) < 0.03


def test_estimation_uses_train_only_and_is_sensible():
    panel = bt.load_panel()
    est = br.estimate(panel)
    changed = panel.copy()
    test = changed["split"] == "test"
    changed.loc[test, "vix"] *= 2.0
    assert br.estimate(changed) == est
    assert 0.5 < est["rough"]["alpha"] < 0.7
    assert est["rough"]["lam"] > 0 and est["rough"]["nu"] > 0 and -1 < est["rough"]["rho"] < 0
    assert not est["rough"]["lam_at_grid_edge"] and not est["a1"]["lam_at_grid_edge"]
```

### `src/pricing_test.py`

```python
"""Pricing test on traded NIFTY options: Black-Scholes vs Heston vs rough Heston.

Option (as in the base paper's numerics): an at-the-money call with about
3 months (T = 0.25, i.e. ~63 trading days) to expiry. For each trading day with
option data we take the NIFTY monthly contract whose time to expiry is closest
to 63 trading days (allowed 40-90), the futures price F of that expiry, and

  * ATM:   the traded call with strike nearest to F;
  * smile: every traded call with 0.90 <= K/F <= 1.10 (extra, same expiry).

Market price = bhavcopy close of a TRADED call (contracts > 0) that is inside
the no-arbitrage bounds (has a Black-76 implied vol). Prices are per unit of F
(Black-76, zero discounting, as in src/fo_data.py).

Models, all fed only that day's India VIX (no fitting to option prices):
  bs           Black-76 with vol = VIX/100
  heston       Heston, v = (VIX/100)^2, parameters estimated on 2010-2018
               (src/backtest_heston.train_params)
  rough        rough Heston, alpha ~ 0.555, flat forward variance (VIX/100)^2,
               parameters estimated on 2010-2018 (src/backtest_rough.estimate)
  rough_a1     same framework with alpha = 1 (control)

Errors: model - market, in bp of F and in implied-vol points (model price
converted to Black-76 implied vol). Reported for days in the train period
(2010-2018, in-sample for the parameters) and test period (2019-2026).

Data: data/raw/bhavcopy/ (git-ignored; rebuild with `python -m src.bhavcopy`,
~1.5 h). Whatever days are present are used; the number of days is reported.

Usage: python -m src.pricing_test
Writes results/pricing_test/{atm_3m.csv, smile_3m.csv, summary.json, summary.md}.
"""

from __future__ import annotations

import gzip
import json

import numpy as np
import pandas as pd

from . import backtest_heston as bh
from . import backtest_real as bt
from . import backtest_rough as br
from . import fo_data as fd
from . import heston as hs
from . import rough_heston as rh
from .backtest_options import Market
from .upstream import PROJECT_ROOT

OUT = PROJECT_ROOT / "results" / "pricing_test"
TARGET, LO, HI = 63, 40, 90
MONEYNESS = (0.90, 1.10)
MODELS = ("bs", "heston", "rough", "rough_a1")
BP = 1e4


def load_fo_available() -> pd.DataFrame:
    """Like fo_data.load_fo, but uses only the daily files present on disk
    (the bhavcopy folder is git-ignored and may be partial)."""
    manifest = [json.loads(line) for line in (fd.RAW / "MANIFEST.jsonl").read_text().splitlines()
                if line.strip()]
    files = sorted({m["file"] for m in manifest if "file" in m and (PROJECT_ROOT / m["file"]).exists()})
    parts = []
    for rel in files:
        with gzip.open(PROJECT_ROOT / rel, "rt") as handle:
            day = pd.read_csv(handle)
        monthly = set(day.loc[day["instrument"] == "FUT", "expiry"])
        parts.append(day[(day["instrument"] == "FUT") | day["expiry"].isin(monthly)])
    if not parts:
        raise SystemExit("no bhavcopy files found: run python -m src.bhavcopy")
    fo = pd.concat(parts, ignore_index=True)
    fo["date"] = pd.to_datetime(fo["date"])
    fo["expiry"] = pd.to_datetime(fo["expiry"])
    return fo


def collect(mkt: Market, vix: pd.Series, split: pd.Series) -> pd.DataFrame:
    rows = []
    for day, labels in mkt.expiries.items():
        if day not in vix.index or not np.isfinite(vix[day]):
            continue
        cands = []
        for e in labels:
            actual = mkt.actual_expiry.get(e)
            if actual is None:
                continue
            n = mkt.days_to(day, actual)
            if LO <= n <= HI and (day, e) in mkt.strikes and (day, e) in mkt.fut_close:
                cands.append((abs(n - TARGET), n, e))
        if not cands:
            continue
        _, n, e = min(cands)
        f = mkt.fut_close[(day, e)]
        strikes = mkt.strikes[(day, e)]
        atm = float(strikes[np.abs(strikes - f).argmin()])
        for k in strikes:
            m = k / f
            if not (MONEYNESS[0] <= m <= MONEYNESS[1]):
                continue
            price = mkt.call_close[(day, e, k)]
            iv = fd.implied_vol(price, f, k, n / fd.YEAR)
            if not np.isfinite(iv):
                continue
            rows.append({"date": day, "expiry": mkt.actual_expiry[e], "n": n, "f": f, "strike": float(k),
                         "m": m, "atm": bool(k == atm), "market": price / f, "market_iv": iv,
                         "vix": vix[day] / 100, "period": split.get(day, "none")})
    return pd.DataFrame(rows)


def model_prices(df: pd.DataFrame, hp: hs.HestonParams, rparams: dict) -> pd.DataFrame:
    df = df.copy()
    tau = df["n"].to_numpy() / fd.YEAR
    k = df["m"].to_numpy()
    vol = df["vix"].to_numpy()
    df["bs"] = fd.black_call(1.0, k, tau, vol)
    df["heston"] = hs.heston_call(1.0, k, tau, vol**2, hp)
    for name, p in rparams.items():
        out = np.empty(len(df))
        pricer = rh.RoughPricer(p, np.unique(tau), br.XI_MIN, steps=200)
        for t in np.unique(tau):
            sel = tau == t
            # pricer has K = 1: C(F=1, K=k) = k * C(S/K = 1/k)
            out[sel] = k[sel] * pricer.quantities(1.0 / k[sel], t, vol[sel] ** 2)["call"]
        df[name] = out
    for name in MODELS:
        df[f"{name}_iv"] = [fd.implied_vol(p, 1.0, kk, t) for p, kk, t in zip(df[name], k, tau)]
    return df


def stats(df: pd.DataFrame) -> dict:
    out = {"n": int(len(df)), "days": int(df["date"].nunique())}
    for name in MODELS:
        e = (df[name] - df["market"]) * BP
        ev = (df[f"{name}_iv"] - df["market_iv"]) * 100
        out[name] = {"bias_bp": float(e.mean()), "rmse_bp": float(np.sqrt(np.mean(e**2))),
                     "mae_bp": float(e.abs().mean()),
                     "bias_volpts": float(ev.mean()), "rmse_volpts": float(np.sqrt(np.nanmean(ev**2)))}
    return out


def main(argv=None):
    nifty = pd.read_csv(PROJECT_ROOT / "data" / "processed" / "nifty50.csv", index_col=0, parse_dates=True)
    panel = bt.load_panel()
    mkt = Market(load_fo_available(), nifty.index)
    df = collect(mkt, panel["vix"], panel["split"])
    if df.empty:
        raise SystemExit("no usable option days found in data/raw/bhavcopy")
    hp = bh.train_params(panel)
    est = br.estimate(panel)
    rparams = {"rough": rh.RoughParams(est["rough"]["alpha"], est["rough"]["lam"], est["rough"]["nu"], est["rough"]["rho"]),
               "rough_a1": rh.RoughParams(1.0, est["a1"]["lam"], est["a1"]["nu"], est["a1"]["rho"])}
    df = model_prices(df, hp, rparams)
    OUT.mkdir(parents=True, exist_ok=True)
    atm = df[df["atm"]]
    atm.to_csv(OUT / "atm_3m.csv", index=False)
    df.to_csv(OUT / "smile_3m.csv", index=False)
    summary = {"data_days": int(df["date"].nunique()), "first": str(df["date"].min().date()),
               "last": str(df["date"].max().date()),
               "years": {str(y): int(c) for y, c in atm.groupby(atm["date"].dt.year).size().items()},
               "heston_params": hp.as_dict(), "rough_params": {k: v.as_dict() for k, v in rparams.items()},
               "atm": {}, "smile": {}, "smile_by_moneyness": {}}
    for period in ("train", "test", "all"):
        a = atm if period == "all" else atm[atm["period"] == period]
        s = df if period == "all" else df[df["period"] == period]
        if len(a):
            summary["atm"][period] = stats(a)
        if len(s):
            summary["smile"][period] = stats(s)
    buckets = pd.cut(df["m"], [0.899, 0.95, 0.99, 1.01, 1.05, 1.101],
                     labels=["0.90-0.95", "0.95-0.99", "0.99-1.01", "1.01-1.05", "1.05-1.10"])
    for b, g in df.groupby(buckets, observed=True):
        summary["smile_by_moneyness"][str(b)] = {
            "n": int(len(g)), "market_iv": float(g["market_iv"].mean() * 100),
            **{f"{m}_iv_bias_volpts": float(((g[f"{m}_iv"] - g["market_iv"]) * 100).mean()) for m in MODELS}}
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))

    lines = ["# Pricing 3-month NIFTY calls: model vs market", "",
             f"Option days: {summary['data_days']} ({summary['first']} .. {summary['last']}); "
             f"ATM days by year: {summary['years']}", "",
             "Error = model - market. bp of the futures price; vol pts = implied-vol points.", ""]
    for key, title in (("atm", "ATM call, ~3 months (the paper's option)"),
                       ("smile", "All traded calls 0.90 <= K/F <= 1.10, same expiry")):
        lines += [f"## {title}", "",
                  "| period | options | model | bias bp | RMSE bp | MAE bp | bias vol pts | RMSE vol pts |",
                  "|---|---|---|---|---|---|---|---|"]
        for period, st in summary[key].items():
            for m in MODELS:
                x = st[m]
                lines.append(f"| {period} | {st['n']} | {m} | {x['bias_bp']:+.1f} | {x['rmse_bp']:.1f} | "
                             f"{x['mae_bp']:.1f} | {x['bias_volpts']:+.2f} | {x['rmse_volpts']:.2f} |")
        lines.append("")
    lines += ["## Smile: mean implied-vol error by moneyness (vol pts)", "",
              "| K/F | options | market IV % | " + " | ".join(MODELS) + " |", "|---" * (3 + len(MODELS)) + "|"]
    for b, x in summary["smile_by_moneyness"].items():
        lines.append(f"| {b} | {x['n']} | {x['market_iv']:.1f} | "
                     + " | ".join(f"{x[f'{m}_iv_bias_volpts']:+.2f}" for m in MODELS) + " |")
    (OUT / "summary.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
```

### `tests/test_pricing_test.py`

```python
"""Checks for src/pricing_test.py (runs on whatever bhavcopy days are on disk).

Run: python -m pytest tests/test_pricing_test.py -q
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src import backtest_real as bt
from src import fo_data as fd
from src import pricing_test as pt
from src.backtest_options import Market
from src.upstream import PROJECT_ROOT


@pytest.fixture(scope="module")
def sample():
    nifty = pd.read_csv(PROJECT_ROOT / "data" / "processed" / "nifty50.csv", index_col=0, parse_dates=True)
    panel = bt.load_panel()
    df = pt.collect(Market(pt.load_fo_available(), nifty.index), panel["vix"], panel["split"])
    if df.empty:
        pytest.skip("no bhavcopy option data on disk")
    return df


def test_contract_choice_and_market_iv(sample):
    assert sample["n"].between(pt.LO, pt.HI).all()
    assert sample["m"].between(*pt.MONEYNESS).all()
    assert (sample.groupby("date")["atm"].sum() == 1).all()
    back = fd.black_call(1.0, sample["m"], sample["n"] / fd.YEAR, sample["market_iv"])
    assert np.allclose(back, sample["market"], atol=1e-9)


def test_black_scholes_column(sample):
    from src import heston as hs
    from src import rough_heston as rh
    small = sample.head(30)
    hp = hs.HestonParams(8.6, 0.0337, 0.341, -0.526)
    rp = {"rough": rh.RoughParams(0.555, 0.95, 0.19, -0.526), "rough_a1": rh.RoughParams(1.0, 10.2, 0.6, -0.526)}
    out = pt.model_prices(small, hp, rp)
    tau = small["n"] / fd.YEAR
    assert np.allclose(out["bs"], fd.black_call(1.0, small["m"], tau, small["vix"]))
    assert np.allclose(out["bs_iv"], small["vix"], atol=1e-8)
    for m in pt.MODELS:
        assert np.all(np.isfinite(out[m])) and np.all(out[m] > 0)
```

---

## 4. Maths behind `src/heston.py` (for the report; the code already implements it)

Model, zero rates and dividends, one measure for pricing and hedging:
dS = S sqrt(v) dW1,  dv = kappa(theta - v) dt + sigma sqrt(v) dW2,  corr = rho.

Price C = S P1 - K P2 with
P_j = 1/2 + (1/pi) * Integral_0^inf Re[ exp(-i phi ln K) f_j(phi) / (i phi) ] dphi,
f_j = exp(C_j + D_j v + i phi ln S). For j = 1: u = 1/2, b = kappa - rho sigma;
j = 2: u = -1/2, b = kappa. With q = b - rho sigma i phi,
d = sqrt(q^2 - sigma^2 (2 u i phi - phi^2)), g = (q - d)/(q + d):
D_j = (q - d)/sigma^2 * (1 - e^{-d tau})/(1 - g e^{-d tau}),
C_j = kappa theta / sigma^2 * [ (q - d) tau - 2 ln((1 - g e^{-d tau})/(1 - g)) ]
("little trap" form, Albrecher et al. 2007).

Greeks: dC/dS = P1 (Heston delta). dC/dv = S dP1/dv - K dP2/dv, where
dP_j/dv = (1/pi) Integral Re[ e^{-i phi ln K} D_j f_j / (i phi) ] dphi.
Minimum-variance (locally risk-minimising) delta = dC/dS + (rho sigma / S) dC/dv
(Bartlett 2006; Poulsen et al. 2008; Hull & White 2017). With rho < 0 it is below the Heston delta.

Quadrature: 256 Gauss-Legendre nodes on [0, 30 / s], s = sqrt((v + theta) tau / 2).
Accuracy checked: max error < 1e-10 vs 2048 nodes on the NIFTY range
(S/K in [0.8, 1.2], 1-21 days, vol 8%-85%); benchmark price 5.785155434 vs
reference 5.785155450 (Fang & Oosterlee 2008).

Estimation (train rows only, dt = 1/252, v_t = (VIX_t/100)^2):
OLS v_{t+1} = a + b v_t + e_t -> kappa = -ln(b)/dt, theta = a/(1 - b);
sigma^2 = mean(e_t^2 / v_t) / dt;
rho = corr(r_{t+1}/sqrt(v_t), e_t/sqrt(v_t)), r = daily log return of NIFTY.
Simplification to state in the report: VIX is a 30-day risk-neutral average
volatility, not the instantaneous volatility; the parameters are time-series
(physical-measure) estimates, not calibrated to the option smile.

---

## 5. Run the new tests

```bash
python -m pytest tests/test_heston.py tests/test_heston_rolling.py -q
```

Expected: `17 passed` (about 20-60 s). Then run everything once more:

```bash
python -m pytest tests -q
```

Expected: `58 passed` (41 old + 17 new) before the rough files are added; with all 11 files `68 passed` (about 2-3 min).

---

## 6. Run the backtest, the standard analysis, and the comparison

```bash
python -m src.backtest_heston
```

Takes about 30 s - 2 min. Expected console output (numbers should match to
~6 significant digits; tiny last-digit differences across platforms are fine):

```
Heston parameters (train): {'kappa': 8.59974517084239, 'theta': 0.03369711247387743, 'sigma': 0.34086918431640645, 'rho': -0.5259281875789147}
bs train {'options': 2076, 'first_start': '2010-07-20', 'last_start': '2018-11-29', 'mean_premium': 0.020514901168464775, 'mean_payoff': 0.022155990782547926, 'mean_initial_hedge': 0.5102574505842324}
bs test {'options': 1914, 'first_start': '2019-01-01', 'last_start': '2026-09-18', 'mean_premium': 0.01970636102091693, 'mean_payoff': 0.02279758741224497, 'mean_initial_hedge': 0.5098531805104585}
heston train {... 'mean_initial_hedge': 0.5335636285254328}
heston test {... 'mean_initial_hedge': 0.5340156722030734}
heston_mv train {... 'mean_initial_hedge': 0.49143651233072555}
heston_mv test {... 'mean_initial_hedge': 0.4900208877305472}
```

It creates:
```
results/backtest_heston/heston_params.json
results/backtest_heston/{bs,heston,heston_mv}/maturity_21/per_option_train.npz
results/backtest_heston/{bs,heston,heston_mv}/maturity_21/per_option_test.npz
results/backtest_heston/{bs,heston,heston_mv}/maturity_21/config.json
```

Run the project's standard analysis on each hedge, with and without the COVID
window (same flags the project already uses for `results/backtest_real`):

Linux/macOS (bash):
```bash
for h in bs heston heston_mv; do
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21 --exclude-test 2020-01-15 2020-06-30 --tag excl_covid
done
```
Windows PowerShell:
```powershell
foreach ($h in "bs","heston","heston_mv") {
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21 --exclude-test 2020-01-15 2020-06-30 --tag excl_covid
}
```
Each writes `analysis.json`, `rules_test.csv`, `fig_frontier_test.{pdf,png}`
(and the `_excl_covid` versions) into that hedge's folder.

Then the monthly re-estimated hedges (needs the backtest outputs above; each
call takes ~30 s):

```bash
python -m src.backtest_heston_rolling --window 252
python -m src.backtest_heston_rolling --window 126
python -m src.backtest_heston_rolling --window 0     # expanding: all data since 2010-07-20
```

Expected console output:
```
heston_roll252: 93 months, 2 reused; kappa range 3.63-48.36; options 1914
heston_mv_roll252: 93 months, 2 reused; kappa range 3.63-48.36; options 1914
heston_roll126: 93 months, 3 reused; kappa range 5.78-86.73; options 1914
heston_mv_roll126: 93 months, 3 reused; kappa range 5.78-86.73; options 1914
```
It creates `results/backtest_heston/{heston,heston_mv}_roll{252,126}/maturity_21/`
with `per_option_{train,test}.npz`, `config.json`, `monthly_params.csv`.

Run the standard analysis on the 4 new folders too:

Linux/macOS (bash):
```bash
for h in heston_roll252 heston_mv_roll252 heston_roll126 heston_mv_roll126; do
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21 --exclude-test 2020-01-15 2020-06-30 --tag excl_covid
done
```
Windows PowerShell:
```powershell
foreach ($h in "heston_roll252","heston_mv_roll252","heston_roll126","heston_mv_roll126") {
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21 --exclude-test 2020-01-15 2020-06-30 --tag excl_covid
}
```

Then the side-by-side comparisons:

```bash
python -m src.compare_hedges
python -m src.compare_hedges --hedges bs heston heston_mv heston_roll252 heston_mv_roll252 heston_roll126 heston_mv_roll126 --name comparison_rolling
```

Then the rough Heston hedges (about 2 min):

```bash
python -m src.backtest_rough
```

Expected estimates printed first (train data only): `H = 0.05467` so
`alpha = 0.5547`; rough: `lam = 0.9457, nu = 0.1879, rho = -0.5259`;
alpha = 1 control: `lam = 10.24, nu = 0.6005, rho = -0.5259`. It writes
`results/backtest_heston/rough_params.json` and the folders `rough`, `rough_mv`,
`rough_a1`, `rough_mv_a1` (each `maturity_21/` with npz + config.json).
Analyse them like the others:

Linux/macOS (bash):
```bash
for h in rough rough_mv rough_a1 rough_mv_a1; do
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21 --exclude-test 2020-01-15 2020-06-30 --tag excl_covid
done
python -m src.compare_hedges --hedges bs heston heston_mv rough rough_mv rough_a1 rough_mv_a1 --name comparison_rough
```
Windows PowerShell:
```powershell
foreach ($h in "rough","rough_mv","rough_a1","rough_mv_a1") {
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21
  python -m src.backtest_analysis results/backtest_heston/$h/maturity_21 --exclude-test 2020-01-15 2020-06-30 --tag excl_covid
}
python -m src.compare_hedges --hedges bs heston heston_mv rough rough_mv rough_a1 rough_mv_a1 --name comparison_rough
```

The first writes `results/backtest_heston/comparison.csv` and `comparison.md`
(main table, section 8). The second writes `comparison_rolling.csv` and
`comparison_rolling.md` (adds the monthly hedges, section 8b). `comparison_rough.md` adds the rough hedges (section 8c).

---

## 7. Verify the results (must all hold)

1. **BS reproduces the old backtest.** In
   `results/backtest_heston/bs/maturity_21/analysis.json`, under
   `kappas -> "5.0" -> train_to_test`, the picks must be
   `fixed/every=1`, `regime[vix_hyst]/calm=2,stress=1`, `band/h=0.02` and
   `rmse_bp.fixed` = 64.83 (same as the tracked file
   `results/backtest_real/maturity_21/analysis.json`). Quick check:
   ```bash
   python -c "import json,math;same=lambda x,y:(isinstance(x,dict) and isinstance(y,dict) and x.keys()==y.keys() and all(same(x[k],y[k]) for k in x)) or (isinstance(x,list) and isinstance(y,list) and len(x)==len(y) and all(map(same,x,y))) or (isinstance(x,(int,float)) and isinstance(y,(int,float)) and math.isclose(x,y,rel_tol=1e-9,abs_tol=1e-9)) or x==y;a=json.load(open('results/backtest_heston/bs/maturity_21/analysis.json'));b=json.load(open('results/backtest_real/maturity_21/analysis.json'));print(same(a['kappas'],b['kappas']))"
   ```
   Expected: `True` (every number of the analysis, at every cost level, agrees
   to 1e-9; exact equality is not expected because the tracked file was made on
   Windows and the last floating-point digit can differ).
2. `heston_params.json`: kappa ~ 8.60, theta ~ 0.0337 (long-run vol ~ 18.4%),
   sigma ~ 0.341, rho ~ -0.526, Feller term 2*kappa*theta - sigma^2 ~ 0.463 > 0.
3. `comparison.md` should match the reference table in section 8 to the
   first decimal (bootstrap z values use a fixed seed, so they match too).

If 1 fails, something in the shared code differs from the tested commit: stop
and report.

---

## 8. Reference results (what the run produced when tested)

Test period, rules picked on train, costs 0/5/20 bp per traded notional.
RMSE = sqrt(J); loss = -P&L; "vs BS %" = change in mean squared error vs the BS
hedge with the same strategy (negative = better than BS); |z| > 2 ~ significant.

#### Heston vs Black-Scholes hedges on NIFTY (test period, rules picked on train)

Heston parameters (estimated on train): kappa=8.6, theta=0.0337, sigma=0.3409, rho=-0.5259

All values in bp of notional. Loss = -P&L. vs BS: change in mean squared error vs the BS hedge with the same strategy (negative = Heston better); |z| > 2 is roughly significant.

#### test_all (whole test period 2019-2026)

| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 | ES99 | worst | trades | vs BS % | z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| test_all | 0 | fixed | bs | fixed/every=1 | 64.0 | 29.9 | 64.0 | 62.9 | 157.4 | 302.2 | 504.8 | 20.0 | +0.0 | +0.00 |
| test_all | 0 | fixed | heston | fixed/every=1 | 64.1 | 30.1 | 64.1 | 70.9 | 153.4 | 282.1 | 478.7 | 20.0 | +0.5 | +0.13 |
| test_all | 0 | fixed | heston_mv | fixed/every=1 | 61.1 | 28.1 | 61.1 | 64.1 | 151.2 | 265.8 | 442.5 | 20.0 | -8.7 | -1.07 |
| test_all | 0 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 70.2 | 24.9 | 70.2 | 76.9 | 177.9 | 349.8 | 504.8 | 12.7 | +0.0 | +0.00 |
| test_all | 0 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 70.3 | 25.4 | 70.3 | 83.7 | 174.0 | 332.3 | 478.7 | 12.7 | +0.3 | +0.09 |
| test_all | 0 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 67.6 | 23.3 | 67.6 | 80.1 | 171.0 | 323.0 | 442.5 | 12.7 | -7.3 | -1.06 |
| test_all | 0 | band | bs | band/h=0.02 | 64.2 | 29.7 | 64.2 | 66.2 | 157.8 | 298.7 | 500.3 | 14.7 | +0.0 | +0.00 |
| test_all | 0 | band | heston | band/h=0.02 | 64.4 | 29.8 | 64.4 | 73.9 | 154.0 | 278.2 | 479.3 | 14.7 | +0.7 | +0.19 |
| test_all | 0 | band | heston_mv | band/h=0.02 | 61.4 | 27.9 | 61.4 | 66.4 | 151.5 | 262.4 | 442.4 | 14.8 | -8.5 | -1.05 |
| test_all | 5 | fixed | bs | fixed/every=1 | 64.8 | 18.0 | 63.7 | 75.0 | 170.7 | 313.1 | 511.8 | 20.0 | +0.0 | +0.00 |
| test_all | 5 | fixed | heston | fixed/every=1 | 64.9 | 18.1 | 63.8 | 83.4 | 167.0 | 293.6 | 486.0 | 20.0 | +0.3 | +0.08 |
| test_all | 5 | fixed | heston_mv | fixed/every=1 | 62.2 | 16.4 | 61.1 | 78.0 | 165.2 | 278.2 | 449.5 | 20.0 | -8.0 | -0.98 |
| test_all | 5 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 70.9 | 14.0 | 70.0 | 89.8 | 190.5 | 361.5 | 511.8 | 12.7 | +0.0 | +0.00 |
| test_all | 5 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 70.9 | 14.4 | 70.1 | 93.8 | 186.9 | 343.8 | 486.0 | 12.7 | +0.1 | +0.03 |
| test_all | 5 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 68.5 | 12.6 | 67.6 | 90.7 | 184.1 | 335.2 | 449.5 | 12.7 | -6.6 | -0.96 |
| test_all | 5 | band | bs | band/h=0.02 | 65.0 | 18.0 | 63.9 | 77.3 | 170.9 | 309.5 | 507.2 | 14.7 | +0.0 | +0.00 |
| test_all | 5 | band | heston | band/h=0.02 | 65.2 | 18.1 | 64.1 | 85.2 | 167.4 | 289.7 | 486.4 | 14.7 | +0.5 | +0.14 |
| test_all | 5 | band | heston_mv | band/h=0.02 | 62.4 | 16.4 | 61.4 | 80.3 | 165.1 | 274.4 | 449.2 | 14.8 | -7.8 | -0.96 |
| test_all | 20 | fixed | bs | fixed/every=1 | 79.6 | -17.7 | 63.8 | 112.8 | 211.7 | 347.0 | 533.0 | 20.0 | +0.0 | +0.00 |
| test_all | 20 | fixed | heston | fixed/every=1 | 79.6 | -17.7 | 63.6 | 118.1 | 208.6 | 330.2 | 508.0 | 20.0 | -0.1 | -0.06 |
| test_all | 20 | fixed | heston_mv | fixed/every=1 | 77.6 | -18.7 | 61.8 | 117.7 | 207.4 | 316.2 | 470.4 | 20.0 | -5.0 | -0.87 |
| test_all | 20 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 82.7 | -18.6 | 70.3 | 126.5 | 229.6 | 396.8 | 533.0 | 12.7 | +0.0 | +0.00 |
| test_all | 20 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 82.6 | -18.4 | 70.1 | 127.7 | 226.3 | 380.1 | 508.0 | 12.7 | -0.1 | -0.06 |
| test_all | 20 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 80.9 | -19.6 | 68.6 | 126.6 | 224.6 | 372.6 | 470.4 | 12.7 | -4.2 | -0.77 |
| test_all | 20 | band | bs | band/h=0.05 | 79.0 | -16.3 | 65.3 | 124.0 | 215.5 | 335.6 | 500.3 | 10.0 | +0.0 | +0.00 |
| test_all | 20 | band | heston | band/h=0.05 | 79.4 | -16.0 | 65.8 | 133.5 | 213.4 | 329.0 | 496.3 | 9.8 | +1.2 | +0.82 |
| test_all | 20 | band | heston_mv | band/h=0.05 | 77.3 | -17.2 | 63.8 | 128.7 | 209.5 | 316.9 | 472.6 | 9.9 | -4.2 | -0.84 |

#### test_excl_covid (options starting 2020-01-15..2020-06-30 removed)

| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 | ES99 | worst | trades | vs BS % | z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| test_excl_covid | 0 | fixed | bs | fixed/every=1 | 50.7 | 29.6 | 50.7 | 50.2 | 119.3 | 196.3 | 283.0 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 0 | fixed | heston | fixed/every=1 | 52.2 | 29.6 | 52.2 | 54.9 | 120.4 | 192.9 | 277.6 | 20.0 | +5.8 | +3.56 |
| test_excl_covid | 0 | fixed | heston_mv | fixed/every=1 | 51.1 | 27.5 | 51.1 | 51.9 | 124.3 | 202.5 | 287.4 | 20.0 | +1.5 | +0.64 |
| test_excl_covid | 0 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 58.3 | 24.6 | 58.3 | 63.5 | 141.5 | 276.8 | 398.9 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 0 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 59.5 | 24.9 | 59.5 | 67.6 | 142.3 | 268.4 | 407.8 | 12.4 | +4.1 | +2.52 |
| test_excl_covid | 0 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 58.7 | 22.6 | 58.7 | 64.9 | 145.7 | 281.9 | 403.4 | 12.4 | +1.3 | +0.65 |
| test_excl_covid | 0 | band | bs | band/h=0.02 | 50.9 | 29.3 | 50.9 | 50.4 | 119.8 | 196.8 | 283.4 | 14.8 | +0.0 | +0.00 |
| test_excl_covid | 0 | band | heston | band/h=0.02 | 52.4 | 29.3 | 52.4 | 55.2 | 120.9 | 193.6 | 278.0 | 14.7 | +6.0 | +3.64 |
| test_excl_covid | 0 | band | heston_mv | band/h=0.02 | 51.4 | 27.2 | 51.4 | 54.6 | 125.2 | 203.2 | 287.5 | 14.8 | +1.8 | +0.74 |
| test_excl_covid | 5 | fixed | bs | fixed/every=1 | 52.3 | 17.7 | 50.9 | 64.2 | 133.9 | 213.5 | 295.9 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 5 | fixed | heston | fixed/every=1 | 53.6 | 17.6 | 52.2 | 66.8 | 135.2 | 210.1 | 298.0 | 20.0 | +5.0 | +2.89 |
| test_excl_covid | 5 | fixed | heston_mv | fixed/every=1 | 52.8 | 15.7 | 51.5 | 64.4 | 139.4 | 219.6 | 300.3 | 20.0 | +2.1 | +0.77 |
| test_excl_covid | 5 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 59.6 | 13.7 | 58.6 | 76.1 | 155.4 | 292.4 | 415.7 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 5 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 60.7 | 14.0 | 59.7 | 81.0 | 156.3 | 283.9 | 424.9 | 12.4 | +3.6 | +2.07 |
| test_excl_covid | 5 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 60.2 | 11.9 | 59.2 | 76.6 | 160.1 | 297.4 | 420.1 | 12.4 | +1.9 | +0.84 |
| test_excl_covid | 5 | band | bs | band/h=0.02 | 52.4 | 17.6 | 51.1 | 62.9 | 134.2 | 213.8 | 296.1 | 14.8 | +0.0 | +0.00 |
| test_excl_covid | 5 | band | heston | band/h=0.02 | 53.8 | 17.5 | 52.5 | 67.2 | 135.5 | 210.7 | 296.4 | 14.7 | +5.2 | +2.98 |
| test_excl_covid | 5 | band | heston_mv | band/h=0.02 | 53.0 | 15.6 | 51.8 | 64.5 | 140.1 | 220.2 | 300.2 | 14.8 | +2.3 | +0.87 |
| test_excl_covid | 20 | fixed | bs | fixed/every=1 | 70.8 | -18.1 | 52.4 | 100.6 | 178.8 | 265.1 | 363.3 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 20 | fixed | heston | fixed/every=1 | 71.5 | -18.2 | 53.2 | 103.6 | 180.4 | 261.9 | 365.5 | 20.0 | +2.0 | +1.28 |
| test_excl_covid | 20 | fixed | heston_mv | fixed/every=1 | 71.2 | -19.4 | 53.6 | 105.7 | 185.3 | 271.0 | 364.3 | 20.0 | +1.0 | +0.46 |
| test_excl_covid | 20 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 74.2 | -18.8 | 60.2 | 110.9 | 198.4 | 339.2 | 466.0 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 20 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 74.9 | -18.7 | 60.9 | 113.4 | 199.1 | 330.6 | 476.2 | 12.4 | +1.8 | +1.11 |
| test_excl_covid | 20 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 74.9 | -20.1 | 61.5 | 115.0 | 203.9 | 344.0 | 470.3 | 12.4 | +1.8 | +0.82 |
| test_excl_covid | 20 | band | bs | band/h=0.05 | 69.9 | -16.6 | 53.9 | 105.4 | 180.7 | 270.3 | 355.2 | 10.0 | +0.0 | +0.00 |
| test_excl_covid | 20 | band | heston | band/h=0.05 | 70.6 | -16.4 | 54.7 | 110.7 | 183.0 | 266.8 | 358.2 | 9.9 | +1.9 | +1.25 |
| test_excl_covid | 20 | band | heston_mv | band/h=0.05 | 70.3 | -17.8 | 55.1 | 103.5 | 186.7 | 277.1 | 361.7 | 9.9 | +1.2 | +0.50 |


### Plain-language reading of these numbers (for the report)

- **With COVID in the test set:** the minimum-variance Heston hedge cuts the
  squared hedging error by about 5-9% vs Black-Scholes, for all three
  strategies and all costs, and lowers the 99% expected shortfall (e.g.
  302 -> 266 bp, daily, no cost). But z ~ -1, so it is **not statistically
  significant**. The plain Heston delta is no better than BS.
- **Without the COVID crash:** neither Heston hedge beats BS. The plain Heston
  delta is **significantly worse** (+4 to +6% squared error, z ~ 2-3.6); the
  minimum-variance delta is slightly worse but not significant.
- **Strategy ranking does not change with the hedge:** daily (fixed) and band
  are about equal and best; the regime-aware rule is worst under every hedge.
  So the project's main real-data conclusion is robust to using Heston.
- Honest summary: a Heston hedge with time-series parameters does not
  reliably beat the BS-with-VIX delta on NIFTY; its only (insignificant)
  benefit comes from the 2020 crash, through the volatility-correlation term
  of the minimum-variance delta. This is consistent with the literature that
  better pricing models do not automatically hedge better.

### Limitations to state
- Synthetic options priced with BS at VIX (no traded-option prices in this test).
- v = (VIX/100)^2 used as instantaneous variance; parameters estimated from
  time series, not calibrated to the option smile.
- Zero rates and dividends, hedge in the index (in practice: NIFTY futures).
- Not the rough Hawkes-Heston hedge itself (it needs hidden states and a
  forward variance curve that NIFTY data do not provide); Heston is its
  alpha = 1, no-jump special case.

---

## 8b. Robustness: Heston parameters updated every month

Why: the fixed 2010-2018 parameters might be out of date in 2019-2026. So at
the start of every test month the parameters are re-estimated from the
previous 252 trading days (about 12 months; e.g. March 2020 options use March
2019 - February 2020), and, as a check, from the previous 126 days (about 6
months). Rules are still picked on train (train file = fixed-parameter run).

Result (reference table below, `comparison_rolling.md`):
- Monthly updating does **not** help. With COVID: plain Heston delta about the
  same as BS, minimum-variance delta slightly better (5-9% lower squared error,
  z ~ -1, not significant) - the same as with fixed parameters.
- Without COVID: plain Heston delta is **worse** than BS, even more than with
  fixed parameters (+4 to +9%, z ~ 2-4); minimum-variance delta slightly worse
  (+2 to +4%, not significant).
- Same picture for all three strategies, all costs, and both windows.
- Reason: the monthly estimates are very noisy (kappa ranges 3.6-48 with a
  12-month window, 5.8-87 with 6 months; theta 0.016-0.10), so updating adds
  noise rather than accuracy. 2-3 of 93 months fail to estimate (variance not
  mean reverting in the window) and reuse the previous month's parameters.
- Conclusion for the report: Heston does not improve on BS for NIFTY whether
  its parameters are fixed or updated monthly; this rules out "the parameters
  were just out of date" as the explanation.

#### Heston vs Black-Scholes hedges on NIFTY (test period, rules picked on train)

Heston parameters (estimated on train): kappa=8.6, theta=0.0337, sigma=0.3409, rho=-0.5259

All values in bp of notional. Loss = -P&L. vs BS: change in mean squared error vs the BS hedge with the same strategy (negative = Heston better); |z| > 2 is roughly significant.

#### test_all

| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 | ES99 | worst | trades | vs BS % | z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| test_all | 0 | fixed | bs | fixed/every=1 | 64.0 | 29.9 | 64.0 | 62.9 | 157.4 | 302.2 | 504.8 | 20.0 | +0.0 | +0.00 |
| test_all | 0 | fixed | heston | fixed/every=1 | 64.1 | 30.1 | 64.1 | 70.9 | 153.4 | 282.1 | 478.7 | 20.0 | +0.5 | +0.13 |
| test_all | 0 | fixed | heston_mv | fixed/every=1 | 61.1 | 28.1 | 61.1 | 64.1 | 151.2 | 265.8 | 442.5 | 20.0 | -8.7 | -1.07 |
| test_all | 0 | fixed | heston_roll252 | fixed/every=1 | 64.1 | 29.9 | 64.1 | 75.6 | 154.4 | 275.1 | 464.9 | 20.0 | +0.3 | +0.07 |
| test_all | 0 | fixed | heston_mv_roll252 | fixed/every=1 | 61.1 | 27.5 | 61.1 | 72.6 | 152.5 | 262.8 | 436.9 | 20.0 | -8.8 | -1.02 |
| test_all | 0 | fixed | heston_roll126 | fixed/every=1 | 64.5 | 29.6 | 64.5 | 73.9 | 155.0 | 280.8 | 485.0 | 20.0 | +1.7 | +0.36 |
| test_all | 0 | fixed | heston_mv_roll126 | fixed/every=1 | 61.1 | 27.4 | 61.1 | 72.2 | 152.5 | 267.1 | 452.5 | 20.0 | -8.6 | -1.06 |
| test_all | 0 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 70.2 | 24.9 | 70.2 | 76.9 | 177.9 | 349.8 | 504.8 | 12.7 | +0.0 | +0.00 |
| test_all | 0 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 70.3 | 25.4 | 70.3 | 83.7 | 174.0 | 332.3 | 478.7 | 12.7 | +0.3 | +0.09 |
| test_all | 0 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 67.6 | 23.3 | 67.6 | 80.1 | 171.0 | 323.0 | 442.5 | 12.7 | -7.3 | -1.06 |
| test_all | 0 | regime | heston_roll252 | regime[vix_hyst]/calm=2,stress=1 | 70.3 | 25.2 | 70.3 | 81.3 | 175.6 | 326.5 | 464.9 | 12.7 | +0.3 | +0.08 |
| test_all | 0 | regime | heston_mv_roll252 | regime[vix_hyst]/calm=2,stress=1 | 67.5 | 22.7 | 67.5 | 81.5 | 172.7 | 319.3 | 436.9 | 12.7 | -7.4 | -1.03 |
| test_all | 0 | regime | heston_roll126 | regime[vix_hyst]/calm=2,stress=1 | 70.7 | 24.9 | 70.7 | 82.1 | 176.4 | 334.3 | 485.0 | 12.7 | +1.5 | +0.37 |
| test_all | 0 | regime | heston_mv_roll126 | regime[vix_hyst]/calm=2,stress=1 | 67.6 | 22.5 | 67.6 | 82.9 | 173.0 | 325.3 | 452.5 | 12.7 | -7.1 | -1.05 |
| test_all | 0 | band | bs | band/h=0.02 | 64.2 | 29.7 | 64.2 | 66.2 | 157.8 | 298.7 | 500.3 | 14.7 | +0.0 | +0.00 |
| test_all | 0 | band | heston | band/h=0.02 | 64.4 | 29.8 | 64.4 | 73.9 | 154.0 | 278.2 | 479.3 | 14.7 | +0.7 | +0.19 |
| test_all | 0 | band | heston_mv | band/h=0.02 | 61.4 | 27.9 | 61.4 | 66.4 | 151.5 | 262.4 | 442.4 | 14.8 | -8.5 | -1.05 |
| test_all | 0 | band | heston_roll252 | band/h=0.02 | 64.3 | 29.8 | 64.3 | 74.7 | 154.7 | 270.9 | 460.2 | 14.7 | +0.4 | +0.07 |
| test_all | 0 | band | heston_mv_roll252 | band/h=0.02 | 61.3 | 27.3 | 61.3 | 75.8 | 152.5 | 258.7 | 431.9 | 14.8 | -8.8 | -1.02 |
| test_all | 0 | band | heston_roll126 | band/h=0.02 | 64.8 | 29.4 | 64.8 | 77.2 | 155.7 | 277.1 | 481.2 | 14.7 | +1.9 | +0.41 |
| test_all | 0 | band | heston_mv_roll126 | band/h=0.02 | 61.4 | 27.2 | 61.4 | 76.8 | 152.9 | 263.8 | 452.8 | 14.7 | -8.5 | -1.05 |
| test_all | 5 | fixed | bs | fixed/every=1 | 64.8 | 18.0 | 63.7 | 75.0 | 170.7 | 313.1 | 511.8 | 20.0 | +0.0 | +0.00 |
| test_all | 5 | fixed | heston | fixed/every=1 | 64.9 | 18.1 | 63.8 | 83.4 | 167.0 | 293.6 | 486.0 | 20.0 | +0.3 | +0.08 |
| test_all | 5 | fixed | heston_mv | fixed/every=1 | 62.2 | 16.4 | 61.1 | 78.0 | 165.2 | 278.2 | 449.5 | 20.0 | -8.0 | -0.98 |
| test_all | 5 | fixed | heston_roll252 | fixed/every=1 | 65.0 | 18.0 | 63.9 | 86.9 | 168.3 | 287.1 | 472.1 | 20.0 | +0.4 | +0.08 |
| test_all | 5 | fixed | heston_mv_roll252 | fixed/every=1 | 62.3 | 15.7 | 61.1 | 84.7 | 166.6 | 275.1 | 443.9 | 20.0 | -7.8 | -0.92 |
| test_all | 5 | fixed | heston_roll126 | fixed/every=1 | 65.4 | 17.6 | 64.3 | 85.6 | 169.2 | 293.1 | 492.3 | 20.0 | +1.9 | +0.40 |
| test_all | 5 | fixed | heston_mv_roll126 | fixed/every=1 | 62.3 | 15.6 | 61.2 | 85.6 | 166.7 | 279.8 | 459.5 | 20.0 | -7.6 | -0.94 |
| test_all | 5 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 70.9 | 14.0 | 70.0 | 89.8 | 190.5 | 361.5 | 511.8 | 12.7 | +0.0 | +0.00 |
| test_all | 5 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 70.9 | 14.4 | 70.1 | 93.8 | 186.9 | 343.8 | 486.0 | 12.7 | +0.1 | +0.03 |
| test_all | 5 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 68.5 | 12.6 | 67.6 | 90.7 | 184.1 | 335.2 | 449.5 | 12.7 | -6.6 | -0.96 |
| test_all | 5 | regime | heston_roll252 | regime[vix_hyst]/calm=2,stress=1 | 71.0 | 14.3 | 70.1 | 91.1 | 188.8 | 338.7 | 472.1 | 12.7 | +0.4 | +0.08 |
| test_all | 5 | regime | heston_mv_roll252 | regime[vix_hyst]/calm=2,stress=1 | 68.5 | 11.9 | 67.7 | 95.5 | 186.1 | 331.6 | 443.9 | 12.7 | -6.5 | -0.92 |
| test_all | 5 | regime | heston_roll126 | regime[vix_hyst]/calm=2,stress=1 | 71.5 | 13.9 | 70.6 | 92.7 | 189.8 | 346.4 | 492.3 | 12.7 | +1.6 | +0.40 |
| test_all | 5 | regime | heston_mv_roll126 | regime[vix_hyst]/calm=2,stress=1 | 68.6 | 11.7 | 67.8 | 94.2 | 186.5 | 337.6 | 459.5 | 12.7 | -6.3 | -0.92 |
| test_all | 5 | band | bs | band/h=0.02 | 65.0 | 18.0 | 63.9 | 77.3 | 170.9 | 309.5 | 507.2 | 14.7 | +0.0 | +0.00 |
| test_all | 5 | band | heston | band/h=0.02 | 65.2 | 18.1 | 64.1 | 85.2 | 167.4 | 289.7 | 486.4 | 14.7 | +0.5 | +0.14 |
| test_all | 5 | band | heston_mv | band/h=0.02 | 62.4 | 16.4 | 61.4 | 80.3 | 165.1 | 274.4 | 449.2 | 14.8 | -7.8 | -0.96 |
| test_all | 5 | band | heston_roll252 | band/h=0.02 | 65.2 | 18.0 | 64.1 | 88.8 | 168.5 | 283.0 | 467.4 | 14.7 | +0.5 | +0.09 |
| test_all | 5 | band | heston_mv_roll252 | band/h=0.02 | 62.4 | 15.8 | 61.3 | 88.0 | 166.3 | 270.7 | 438.8 | 14.8 | -7.8 | -0.91 |
| test_all | 5 | band | heston_roll126 | band/h=0.02 | 65.7 | 17.7 | 64.6 | 90.9 | 169.6 | 289.5 | 488.3 | 14.7 | +2.1 | +0.46 |
| test_all | 5 | band | heston_mv_roll126 | band/h=0.02 | 62.5 | 15.6 | 61.5 | 90.5 | 166.8 | 276.3 | 459.7 | 14.7 | -7.5 | -0.93 |
| test_all | 20 | fixed | bs | fixed/every=1 | 79.6 | -17.7 | 63.8 | 112.8 | 211.7 | 347.0 | 533.0 | 20.0 | +0.0 | +0.00 |
| test_all | 20 | fixed | heston | fixed/every=1 | 79.6 | -17.7 | 63.6 | 118.1 | 208.6 | 330.2 | 508.0 | 20.0 | -0.1 | -0.06 |
| test_all | 20 | fixed | heston_mv | fixed/every=1 | 77.6 | -18.7 | 61.8 | 117.7 | 207.4 | 316.2 | 470.4 | 20.0 | -5.0 | -0.87 |
| test_all | 20 | fixed | heston_roll252 | fixed/every=1 | 79.9 | -17.9 | 64.0 | 126.6 | 210.9 | 324.6 | 493.8 | 20.0 | +0.6 | +0.17 |
| test_all | 20 | fixed | heston_mv_roll252 | fixed/every=1 | 77.9 | -19.6 | 62.1 | 123.8 | 209.5 | 313.7 | 465.0 | 20.0 | -4.2 | -0.70 |
| test_all | 20 | fixed | heston_roll126 | fixed/every=1 | 80.3 | -18.2 | 64.6 | 129.0 | 212.5 | 331.4 | 514.1 | 20.0 | +1.8 | +0.53 |
| test_all | 20 | fixed | heston_mv_roll126 | fixed/every=1 | 78.1 | -19.8 | 62.2 | 124.5 | 210.3 | 318.9 | 480.5 | 20.0 | -3.9 | -0.67 |
| test_all | 20 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 82.7 | -18.6 | 70.3 | 126.5 | 229.6 | 396.8 | 533.0 | 12.7 | +0.0 | +0.00 |
| test_all | 20 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 82.6 | -18.4 | 70.1 | 127.7 | 226.3 | 380.1 | 508.0 | 12.7 | -0.1 | -0.06 |
| test_all | 20 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 80.9 | -19.6 | 68.6 | 126.6 | 224.6 | 372.6 | 470.4 | 12.7 | -4.2 | -0.77 |
| test_all | 20 | regime | heston_roll252 | regime[vix_hyst]/calm=2,stress=1 | 82.9 | -18.6 | 70.4 | 130.3 | 229.2 | 375.0 | 493.8 | 12.7 | +0.5 | +0.16 |
| test_all | 20 | regime | heston_mv_roll252 | regime[vix_hyst]/calm=2,stress=1 | 81.2 | -20.4 | 68.8 | 131.8 | 227.1 | 369.3 | 469.6 | 12.7 | -3.6 | -0.64 |
| test_all | 20 | regime | heston_roll126 | regime[vix_hyst]/calm=2,stress=1 | 83.4 | -18.9 | 71.0 | 130.5 | 230.9 | 382.7 | 514.1 | 12.7 | +1.7 | +0.53 |
| test_all | 20 | regime | heston_mv_roll126 | regime[vix_hyst]/calm=2,stress=1 | 81.4 | -20.6 | 68.9 | 131.6 | 228.2 | 374.5 | 480.5 | 12.7 | -3.2 | -0.59 |
| test_all | 20 | band | bs | band/h=0.05 | 79.0 | -16.3 | 65.3 | 124.0 | 215.5 | 335.6 | 500.3 | 10.0 | +0.0 | +0.00 |
| test_all | 20 | band | heston | band/h=0.05 | 79.4 | -16.0 | 65.8 | 133.5 | 213.4 | 329.0 | 496.3 | 9.8 | +1.2 | +0.82 |
| test_all | 20 | band | heston_mv | band/h=0.05 | 77.3 | -17.2 | 63.8 | 128.7 | 209.5 | 316.9 | 472.6 | 9.9 | -4.2 | -0.84 |
| test_all | 20 | band | heston_roll252 | band/h=0.05 | 79.8 | -16.3 | 66.2 | 133.1 | 215.7 | 326.9 | 495.8 | 9.9 | +2.2 | +0.91 |
| test_all | 20 | band | heston_mv_roll252 | band/h=0.05 | 77.5 | -17.9 | 63.9 | 133.4 | 210.9 | 312.0 | 466.9 | 9.9 | -3.6 | -0.65 |
| test_all | 20 | band | heston_roll126 | band/h=0.05 | 80.3 | -16.8 | 66.8 | 135.9 | 216.1 | 335.0 | 502.3 | 9.9 | +3.4 | +1.26 |
| test_all | 20 | band | heston_mv_roll126 | band/h=0.05 | 77.9 | -18.3 | 64.3 | 131.6 | 213.1 | 321.4 | 468.5 | 9.9 | -2.7 | -0.55 |

#### test_excl_covid

| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 | ES99 | worst | trades | vs BS % | z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| test_excl_covid | 0 | fixed | bs | fixed/every=1 | 50.7 | 29.6 | 50.7 | 50.2 | 119.3 | 196.3 | 283.0 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 0 | fixed | heston | fixed/every=1 | 52.2 | 29.6 | 52.2 | 54.9 | 120.4 | 192.9 | 277.6 | 20.0 | +5.8 | +3.56 |
| test_excl_covid | 0 | fixed | heston_mv | fixed/every=1 | 51.1 | 27.5 | 51.1 | 51.9 | 124.3 | 202.5 | 287.4 | 20.0 | +1.5 | +0.64 |
| test_excl_covid | 0 | fixed | heston_roll252 | fixed/every=1 | 52.9 | 29.3 | 52.9 | 54.3 | 124.1 | 198.5 | 284.3 | 20.0 | +8.6 | +4.18 |
| test_excl_covid | 0 | fixed | heston_mv_roll252 | fixed/every=1 | 51.4 | 27.0 | 51.4 | 55.2 | 126.7 | 201.4 | 285.8 | 20.0 | +2.8 | +1.05 |
| test_excl_covid | 0 | fixed | heston_roll126 | fixed/every=1 | 53.0 | 28.8 | 53.0 | 56.1 | 125.8 | 199.8 | 284.9 | 20.0 | +9.2 | +3.62 |
| test_excl_covid | 0 | fixed | heston_mv_roll126 | fixed/every=1 | 51.5 | 27.1 | 51.5 | 54.1 | 127.0 | 202.1 | 286.2 | 20.0 | +3.0 | +1.17 |
| test_excl_covid | 0 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 58.3 | 24.6 | 58.3 | 63.5 | 141.5 | 276.8 | 398.9 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 0 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 59.5 | 24.9 | 59.5 | 67.6 | 142.3 | 268.4 | 407.8 | 12.4 | +4.1 | +2.52 |
| test_excl_covid | 0 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 58.7 | 22.6 | 58.7 | 64.9 | 145.7 | 281.9 | 403.4 | 12.4 | +1.3 | +0.65 |
| test_excl_covid | 0 | regime | heston_roll252 | regime[vix_hyst]/calm=2,stress=1 | 60.2 | 24.6 | 60.2 | 67.3 | 146.4 | 272.7 | 405.4 | 12.4 | +6.5 | +3.38 |
| test_excl_covid | 0 | regime | heston_mv_roll252 | regime[vix_hyst]/calm=2,stress=1 | 58.9 | 22.2 | 58.9 | 66.8 | 148.2 | 280.0 | 402.5 | 12.4 | +2.1 | +0.96 |
| test_excl_covid | 0 | regime | heston_roll126 | regime[vix_hyst]/calm=2,stress=1 | 60.3 | 24.1 | 60.3 | 69.7 | 148.2 | 274.1 | 405.1 | 12.4 | +7.0 | +3.09 |
| test_excl_covid | 0 | regime | heston_mv_roll126 | regime[vix_hyst]/calm=2,stress=1 | 59.1 | 22.2 | 59.1 | 67.8 | 149.1 | 280.5 | 402.5 | 12.4 | +2.5 | +1.16 |
| test_excl_covid | 0 | band | bs | band/h=0.02 | 50.9 | 29.3 | 50.9 | 50.4 | 119.8 | 196.8 | 283.4 | 14.8 | +0.0 | +0.00 |
| test_excl_covid | 0 | band | heston | band/h=0.02 | 52.4 | 29.3 | 52.4 | 55.2 | 120.9 | 193.6 | 278.0 | 14.7 | +6.0 | +3.64 |
| test_excl_covid | 0 | band | heston_mv | band/h=0.02 | 51.4 | 27.2 | 51.4 | 54.6 | 125.2 | 203.2 | 287.5 | 14.8 | +1.8 | +0.74 |
| test_excl_covid | 0 | band | heston_roll252 | band/h=0.02 | 53.1 | 29.1 | 53.1 | 56.7 | 124.7 | 199.3 | 285.0 | 14.7 | +8.7 | +4.08 |
| test_excl_covid | 0 | band | heston_mv_roll252 | band/h=0.02 | 51.7 | 26.8 | 51.7 | 56.6 | 127.3 | 202.0 | 286.5 | 14.8 | +2.9 | +1.08 |
| test_excl_covid | 0 | band | heston_roll126 | band/h=0.02 | 53.2 | 28.6 | 53.2 | 57.0 | 126.5 | 200.8 | 285.7 | 14.7 | +9.1 | +3.51 |
| test_excl_covid | 0 | band | heston_mv_roll126 | band/h=0.02 | 51.7 | 26.8 | 51.7 | 56.3 | 127.6 | 203.0 | 286.9 | 14.8 | +3.1 | +1.16 |
| test_excl_covid | 5 | fixed | bs | fixed/every=1 | 52.3 | 17.7 | 50.9 | 64.2 | 133.9 | 213.5 | 295.9 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 5 | fixed | heston | fixed/every=1 | 53.6 | 17.6 | 52.2 | 66.8 | 135.2 | 210.1 | 298.0 | 20.0 | +5.0 | +2.89 |
| test_excl_covid | 5 | fixed | heston_mv | fixed/every=1 | 52.8 | 15.7 | 51.5 | 64.4 | 139.4 | 219.6 | 300.3 | 20.0 | +2.1 | +0.77 |
| test_excl_covid | 5 | fixed | heston_roll252 | fixed/every=1 | 54.3 | 17.3 | 53.0 | 68.4 | 139.4 | 215.9 | 298.0 | 20.0 | +8.0 | +3.67 |
| test_excl_covid | 5 | fixed | heston_mv_roll252 | fixed/every=1 | 53.2 | 15.2 | 51.9 | 68.5 | 142.0 | 218.7 | 298.9 | 20.0 | +3.6 | +1.22 |
| test_excl_covid | 5 | fixed | heston_roll126 | fixed/every=1 | 54.5 | 16.8 | 53.2 | 69.9 | 141.3 | 217.3 | 298.7 | 20.0 | +8.8 | +3.36 |
| test_excl_covid | 5 | fixed | heston_mv_roll126 | fixed/every=1 | 53.3 | 15.2 | 51.9 | 67.4 | 142.4 | 219.5 | 299.4 | 20.0 | +3.9 | +1.37 |
| test_excl_covid | 5 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 59.6 | 13.7 | 58.6 | 76.1 | 155.4 | 292.4 | 415.7 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 5 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 60.7 | 14.0 | 59.7 | 81.0 | 156.3 | 283.9 | 424.9 | 12.4 | +3.6 | +2.07 |
| test_excl_covid | 5 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 60.2 | 11.9 | 59.2 | 76.6 | 160.1 | 297.4 | 420.1 | 12.4 | +1.9 | +0.84 |
| test_excl_covid | 5 | regime | heston_roll252 | regime[vix_hyst]/calm=2,stress=1 | 61.4 | 13.7 | 60.4 | 80.4 | 160.8 | 288.3 | 422.4 | 12.4 | +6.1 | +2.98 |
| test_excl_covid | 5 | regime | heston_mv_roll252 | regime[vix_hyst]/calm=2,stress=1 | 60.5 | 11.5 | 59.5 | 79.9 | 162.9 | 295.6 | 419.3 | 12.4 | +2.9 | +1.20 |
| test_excl_covid | 5 | regime | heston_roll126 | regime[vix_hyst]/calm=2,stress=1 | 61.6 | 13.2 | 60.6 | 82.4 | 162.8 | 289.8 | 422.1 | 12.4 | +6.8 | +2.86 |
| test_excl_covid | 5 | regime | heston_mv_roll126 | regime[vix_hyst]/calm=2,stress=1 | 60.6 | 11.5 | 59.6 | 81.7 | 163.9 | 296.2 | 419.2 | 12.4 | +3.3 | +1.40 |
| test_excl_covid | 5 | band | bs | band/h=0.02 | 52.4 | 17.6 | 51.1 | 62.9 | 134.2 | 213.8 | 296.1 | 14.8 | +0.0 | +0.00 |
| test_excl_covid | 5 | band | heston | band/h=0.02 | 53.8 | 17.5 | 52.5 | 67.2 | 135.5 | 210.7 | 296.4 | 14.7 | +5.2 | +2.98 |
| test_excl_covid | 5 | band | heston_mv | band/h=0.02 | 53.0 | 15.6 | 51.8 | 64.5 | 140.1 | 220.2 | 300.2 | 14.8 | +2.3 | +0.87 |
| test_excl_covid | 5 | band | heston_roll252 | band/h=0.02 | 54.5 | 17.3 | 53.3 | 68.9 | 139.9 | 216.6 | 298.0 | 14.7 | +8.2 | +3.60 |
| test_excl_covid | 5 | band | heston_mv_roll252 | band/h=0.02 | 53.4 | 15.2 | 52.1 | 69.1 | 142.6 | 219.2 | 299.5 | 14.8 | +3.7 | +1.24 |
| test_excl_covid | 5 | band | heston_roll126 | band/h=0.02 | 54.7 | 16.8 | 53.4 | 68.9 | 141.7 | 218.1 | 298.7 | 14.7 | +8.8 | +3.26 |
| test_excl_covid | 5 | band | heston_mv_roll126 | band/h=0.02 | 53.5 | 15.2 | 52.2 | 68.0 | 142.9 | 220.3 | 300.0 | 14.8 | +3.9 | +1.36 |
| test_excl_covid | 20 | fixed | bs | fixed/every=1 | 70.8 | -18.1 | 52.4 | 100.6 | 178.8 | 265.1 | 363.3 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 20 | fixed | heston | fixed/every=1 | 71.5 | -18.2 | 53.2 | 103.6 | 180.4 | 261.9 | 365.5 | 20.0 | +2.0 | +1.28 |
| test_excl_covid | 20 | fixed | heston_mv | fixed/every=1 | 71.2 | -19.4 | 53.6 | 105.7 | 185.3 | 271.0 | 364.3 | 20.0 | +1.0 | +0.46 |
| test_excl_covid | 20 | fixed | heston_roll252 | fixed/every=1 | 72.4 | -18.5 | 54.3 | 107.9 | 186.1 | 268.1 | 365.6 | 20.0 | +4.4 | +2.30 |
| test_excl_covid | 20 | fixed | heston_mv_roll252 | fixed/every=1 | 71.8 | -20.1 | 54.1 | 111.7 | 188.6 | 270.7 | 364.7 | 20.0 | +2.7 | +1.04 |
| test_excl_covid | 20 | fixed | heston_roll126 | fixed/every=1 | 72.6 | -19.1 | 54.6 | 110.2 | 188.2 | 269.7 | 366.4 | 20.0 | +5.1 | +2.40 |
| test_excl_covid | 20 | fixed | heston_mv_roll126 | fixed/every=1 | 71.9 | -20.2 | 54.2 | 110.5 | 189.6 | 271.7 | 365.6 | 20.0 | +3.2 | +1.33 |
| test_excl_covid | 20 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 74.2 | -18.8 | 60.2 | 110.9 | 198.4 | 339.2 | 466.0 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 20 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 74.9 | -18.7 | 60.9 | 113.4 | 199.1 | 330.6 | 476.2 | 12.4 | +1.8 | +1.11 |
| test_excl_covid | 20 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 74.9 | -20.1 | 61.5 | 115.0 | 203.9 | 344.0 | 470.3 | 12.4 | +1.8 | +0.82 |
| test_excl_covid | 20 | regime | heston_roll252 | regime[vix_hyst]/calm=2,stress=1 | 75.7 | -19.0 | 61.9 | 117.5 | 205.1 | 335.2 | 473.5 | 12.4 | +4.0 | +2.03 |
| test_excl_covid | 20 | regime | heston_mv_roll252 | regime[vix_hyst]/calm=2,stress=1 | 75.3 | -20.7 | 61.9 | 121.7 | 207.4 | 342.5 | 469.6 | 12.4 | +3.0 | +1.25 |
| test_excl_covid | 20 | regime | heston_roll126 | regime[vix_hyst]/calm=2,stress=1 | 76.0 | -19.5 | 62.2 | 117.2 | 207.4 | 337.0 | 473.2 | 12.4 | +4.8 | +2.18 |
| test_excl_covid | 20 | regime | heston_mv_roll126 | regime[vix_hyst]/calm=2,stress=1 | 75.5 | -20.8 | 62.0 | 121.0 | 208.9 | 343.2 | 469.6 | 12.4 | +3.5 | +1.56 |
| test_excl_covid | 20 | band | bs | band/h=0.05 | 69.9 | -16.6 | 53.9 | 105.4 | 180.7 | 270.3 | 355.2 | 10.0 | +0.0 | +0.00 |
| test_excl_covid | 20 | band | heston | band/h=0.05 | 70.6 | -16.4 | 54.7 | 110.7 | 183.0 | 266.8 | 358.2 | 9.9 | +1.9 | +1.25 |
| test_excl_covid | 20 | band | heston_mv | band/h=0.05 | 70.3 | -17.8 | 55.1 | 103.5 | 186.7 | 277.1 | 361.7 | 9.9 | +1.2 | +0.50 |
| test_excl_covid | 20 | band | heston_roll252 | band/h=0.05 | 71.5 | -16.8 | 55.8 | 113.6 | 188.4 | 275.1 | 360.7 | 9.9 | +4.6 | +2.17 |
| test_excl_covid | 20 | band | heston_mv_roll252 | band/h=0.05 | 70.9 | -18.3 | 55.7 | 112.8 | 189.6 | 277.3 | 362.3 | 10.0 | +2.9 | +1.12 |
| test_excl_covid | 20 | band | heston_roll126 | band/h=0.05 | 71.8 | -17.5 | 56.3 | 113.4 | 190.7 | 276.9 | 361.8 | 9.9 | +5.6 | +2.36 |
| test_excl_covid | 20 | band | heston_mv_roll126 | band/h=0.05 | 71.1 | -18.5 | 55.8 | 111.0 | 191.2 | 278.8 | 363.1 | 10.0 | +3.6 | +1.40 |


---

## 8c. Rough Heston hedges (rough Hawkes-Heston without jumps)

Model and approximations: see the docstrings of `src/rough_heston.py` and
`src/backtest_rough.py`. Parameters from 2010-2018 only. alpha from NIFTY daily
range volatility (Garman-Klass, OHLC): H = 0.055, alpha = 0.555 (paper: 0.527).
lam, nu from the VIX^2 variogram with alpha fixed; rho as in Heston. Forward
variance curve taken flat at (VIX/100)^2. The `_a1` hedges use the identical
pipeline with alpha = 1 (control: isolates the effect of roughness). Note: the
VIX variogram alone fits better with alpha = 1 (loss 0.29 vs 0.66), because VIX
is a 30-day average that hides roughness.

Results (test 2019-2026, rules picked on train):
- rough Heston delta (`rough`): worse than BS (+13 to +15% squared error, z ~ 3).
- rough minimum-variance (`rough_mv`): with COVID slightly better than BS at
  0-5 bp (-5 to -8%, not significant), same at 20 bp; without COVID slightly
  worse (+5 to +9%, not significant).
- Roughness does not improve hedging: `rough_mv` is about equal to the alpha = 1
  control `rough_mv_a1` with COVID and slightly worse without; neither beats the
  plain `heston_mv`.
- The three 20%+ NIFTY falls (daily, 0 bp; RMSE / worst loss in bp; BS ->
  heston_mv -> rough_mv_a1 -> rough_mv): 2011 65/76 -> 63/83 -> 63/82 -> 63/100;
  2015-16 63/165 -> 60/157 -> 58/153 -> 56/133; COVID 187/505 -> 153/442 ->
  163/473 -> 154/465. rough_mv has lower error than BS in all three (best in
  2015-16) but a larger worst loss in 2011. 2011 and 2015-16 are in the
  estimation period.
- Strategy ranking unchanged: daily ~ band, regime-aware worst.

#### Rough Heston / Heston vs Black-Scholes hedges on NIFTY (test period, rules picked on train)

Heston parameters (estimated on train): kappa=8.6, theta=0.0337, sigma=0.3409, rho=-0.5259

All values in bp of notional. Loss = -P&L. vs BS: change in mean squared error vs the BS hedge with the same strategy (negative = Heston better); |z| > 2 is roughly significant.

#### test_all

| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 | ES99 | worst | trades | vs BS % | z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| test_all | 0 | fixed | bs | fixed/every=1 | 64.0 | 29.9 | 64.0 | 62.9 | 157.4 | 302.2 | 504.8 | 20.0 | +0.0 | +0.00 |
| test_all | 0 | fixed | heston | fixed/every=1 | 64.1 | 30.1 | 64.1 | 70.9 | 153.4 | 282.1 | 478.7 | 20.0 | +0.5 | +0.13 |
| test_all | 0 | fixed | heston_mv | fixed/every=1 | 61.1 | 28.1 | 61.1 | 64.1 | 151.2 | 265.8 | 442.5 | 20.0 | -8.7 | -1.07 |
| test_all | 0 | fixed | rough | fixed/every=1 | 68.3 | 32.0 | 68.3 | 74.7 | 159.0 | 312.9 | 540.6 | 20.0 | +14.1 | +3.15 |
| test_all | 0 | fixed | rough_mv | fixed/every=1 | 61.5 | 27.0 | 61.5 | 63.0 | 156.8 | 280.4 | 464.9 | 20.0 | -7.5 | -0.84 |
| test_all | 0 | fixed | rough_a1 | fixed/every=1 | 66.5 | 31.0 | 66.5 | 69.3 | 158.1 | 309.9 | 529.3 | 20.0 | +8.1 | +2.78 |
| test_all | 0 | fixed | rough_mv_a1 | fixed/every=1 | 61.5 | 27.9 | 61.5 | 61.2 | 154.7 | 281.7 | 472.6 | 20.0 | -7.4 | -1.15 |
| test_all | 0 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 70.2 | 24.9 | 70.2 | 76.9 | 177.9 | 349.8 | 504.8 | 12.7 | +0.0 | +0.00 |
| test_all | 0 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 70.3 | 25.4 | 70.3 | 83.7 | 174.0 | 332.3 | 478.7 | 12.7 | +0.3 | +0.09 |
| test_all | 0 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 67.6 | 23.3 | 67.6 | 80.1 | 171.0 | 323.0 | 442.5 | 12.7 | -7.3 | -1.06 |
| test_all | 0 | regime | rough | regime[vix_hyst]/calm=2,stress=1 | 74.7 | 27.0 | 74.7 | 83.4 | 180.7 | 366.0 | 540.6 | 12.7 | +13.4 | +3.28 |
| test_all | 0 | regime | rough_mv | regime[vix_hyst]/calm=2,stress=1 | 68.4 | 21.7 | 68.4 | 78.6 | 177.2 | 345.2 | 464.9 | 12.7 | -4.8 | -0.61 |
| test_all | 0 | regime | rough_a1 | regime[vix_hyst]/calm=2,stress=1 | 72.7 | 26.1 | 72.7 | 81.4 | 179.5 | 359.6 | 529.3 | 12.7 | +7.4 | +2.85 |
| test_all | 0 | regime | rough_mv_a1 | regime[vix_hyst]/calm=2,stress=1 | 68.2 | 22.7 | 68.2 | 74.4 | 174.8 | 342.0 | 472.6 | 12.7 | -5.5 | -0.97 |
| test_all | 0 | band | bs | band/h=0.02 | 64.2 | 29.7 | 64.2 | 66.2 | 157.8 | 298.7 | 500.3 | 14.7 | +0.0 | +0.00 |
| test_all | 0 | band | heston | band/h=0.02 | 64.4 | 29.8 | 64.4 | 73.9 | 154.0 | 278.2 | 479.3 | 14.7 | +0.7 | +0.19 |
| test_all | 0 | band | heston_mv | band/h=0.02 | 61.4 | 27.9 | 61.4 | 66.4 | 151.5 | 262.4 | 442.4 | 14.8 | -8.5 | -1.05 |
| test_all | 0 | band | rough | band/h=0.02 | 68.6 | 31.8 | 68.6 | 75.9 | 159.7 | 310.0 | 539.3 | 14.6 | +14.4 | +3.15 |
| test_all | 0 | band | rough_mv | band/h=0.02 | 61.6 | 26.9 | 61.6 | 65.5 | 156.3 | 275.7 | 464.8 | 14.8 | -7.8 | -0.85 |
| test_all | 0 | band | rough_a1 | band/h=0.02 | 66.8 | 30.9 | 66.8 | 71.4 | 159.2 | 307.3 | 526.2 | 14.8 | +8.4 | +2.76 |
| test_all | 0 | band | rough_mv_a1 | band/h=0.02 | 61.7 | 27.7 | 61.7 | 63.6 | 154.8 | 277.2 | 470.4 | 14.9 | -7.6 | -1.16 |
| test_all | 5 | fixed | bs | fixed/every=1 | 64.8 | 18.0 | 63.7 | 75.0 | 170.7 | 313.1 | 511.8 | 20.0 | +0.0 | +0.00 |
| test_all | 5 | fixed | heston | fixed/every=1 | 64.9 | 18.1 | 63.8 | 83.4 | 167.0 | 293.6 | 486.0 | 20.0 | +0.3 | +0.08 |
| test_all | 5 | fixed | heston_mv | fixed/every=1 | 62.2 | 16.4 | 61.1 | 78.0 | 165.2 | 278.2 | 449.5 | 20.0 | -8.0 | -0.98 |
| test_all | 5 | fixed | rough | fixed/every=1 | 69.3 | 19.5 | 68.2 | 87.0 | 173.0 | 325.1 | 548.1 | 20.0 | +14.3 | +3.01 |
| test_all | 5 | fixed | rough_mv | fixed/every=1 | 63.1 | 15.1 | 62.0 | 74.8 | 171.1 | 293.2 | 471.8 | 20.0 | -5.2 | -0.56 |
| test_all | 5 | fixed | rough_a1 | fixed/every=1 | 67.4 | 18.8 | 66.2 | 82.4 | 171.7 | 321.2 | 536.6 | 20.0 | +7.9 | +2.57 |
| test_all | 5 | fixed | rough_mv_a1 | fixed/every=1 | 62.8 | 16.1 | 61.7 | 73.9 | 168.6 | 293.9 | 479.5 | 20.0 | -6.1 | -0.92 |
| test_all | 5 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 70.9 | 14.0 | 70.0 | 89.8 | 190.5 | 361.5 | 511.8 | 12.7 | +0.0 | +0.00 |
| test_all | 5 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 70.9 | 14.4 | 70.1 | 93.8 | 186.9 | 343.8 | 486.0 | 12.7 | +0.1 | +0.03 |
| test_all | 5 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 68.5 | 12.6 | 67.6 | 90.7 | 184.1 | 335.2 | 449.5 | 12.7 | -6.6 | -0.96 |
| test_all | 5 | regime | rough | regime[vix_hyst]/calm=2,stress=1 | 75.4 | 15.6 | 74.5 | 96.9 | 193.7 | 377.5 | 548.1 | 12.7 | +13.2 | +3.04 |
| test_all | 5 | regime | rough_mv | regime[vix_hyst]/calm=2,stress=1 | 69.8 | 10.9 | 69.0 | 91.2 | 190.9 | 357.5 | 471.8 | 12.7 | -3.0 | -0.37 |
| test_all | 5 | regime | rough_a1 | regime[vix_hyst]/calm=2,stress=1 | 73.4 | 15.0 | 72.5 | 94.3 | 192.2 | 370.9 | 536.6 | 12.7 | +7.2 | +2.57 |
| test_all | 5 | regime | rough_mv_a1 | regime[vix_hyst]/calm=2,stress=1 | 69.3 | 11.9 | 68.5 | 86.7 | 188.2 | 354.1 | 479.5 | 12.7 | -4.4 | -0.75 |
| test_all | 5 | band | bs | band/h=0.02 | 65.0 | 18.0 | 63.9 | 77.3 | 170.9 | 309.5 | 507.2 | 14.7 | +0.0 | +0.00 |
| test_all | 5 | band | heston | band/h=0.02 | 65.2 | 18.1 | 64.1 | 85.2 | 167.4 | 289.7 | 486.4 | 14.7 | +0.5 | +0.14 |
| test_all | 5 | band | heston_mv | band/h=0.02 | 62.4 | 16.4 | 61.4 | 80.3 | 165.1 | 274.4 | 449.2 | 14.8 | -7.8 | -0.96 |
| test_all | 5 | band | rough | band/h=0.02 | 69.6 | 19.4 | 68.5 | 88.6 | 173.5 | 321.8 | 546.6 | 14.6 | +14.6 | +3.02 |
| test_all | 5 | band | rough_mv | band/h=0.02 | 63.2 | 15.2 | 62.1 | 77.0 | 170.3 | 288.3 | 471.7 | 14.8 | -5.5 | -0.58 |
| test_all | 5 | band | rough_a1 | band/h=0.02 | 67.6 | 18.8 | 66.5 | 82.8 | 172.6 | 318.5 | 533.4 | 14.8 | +8.2 | +2.56 |
| test_all | 5 | band | rough_mv_a1 | band/h=0.02 | 62.9 | 16.1 | 61.9 | 76.6 | 168.4 | 289.2 | 477.3 | 14.9 | -6.3 | -0.94 |
| test_all | 20 | fixed | bs | fixed/every=1 | 79.6 | -17.7 | 63.8 | 112.8 | 211.7 | 347.0 | 533.0 | 20.0 | +0.0 | +0.00 |
| test_all | 20 | fixed | heston | fixed/every=1 | 79.6 | -17.7 | 63.6 | 118.1 | 208.6 | 330.2 | 508.0 | 20.0 | -0.1 | -0.06 |
| test_all | 20 | fixed | heston_mv | fixed/every=1 | 77.6 | -18.7 | 61.8 | 117.7 | 207.4 | 316.2 | 470.4 | 20.0 | -5.0 | -0.87 |
| test_all | 20 | fixed | rough | fixed/every=1 | 84.8 | -18.1 | 68.4 | 129.0 | 216.1 | 361.7 | 570.5 | 20.0 | +13.4 | +2.96 |
| test_all | 20 | fixed | rough_mv | fixed/every=1 | 79.9 | -20.4 | 64.4 | 116.0 | 214.8 | 332.3 | 492.6 | 20.0 | +0.8 | +0.11 |
| test_all | 20 | fixed | rough_a1 | fixed/every=1 | 82.2 | -17.9 | 66.1 | 120.5 | 213.3 | 356.4 | 558.7 | 20.0 | +6.7 | +2.39 |
| test_all | 20 | fixed | rough_mv_a1 | fixed/every=1 | 78.8 | -19.4 | 63.1 | 112.4 | 211.0 | 331.6 | 500.3 | 20.0 | -1.9 | -0.37 |
| test_all | 20 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 82.7 | -18.6 | 70.3 | 126.5 | 229.6 | 396.8 | 533.0 | 12.7 | +0.0 | +0.00 |
| test_all | 20 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 82.6 | -18.4 | 70.1 | 127.7 | 226.3 | 380.1 | 508.0 | 12.7 | -0.1 | -0.06 |
| test_all | 20 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 80.9 | -19.6 | 68.6 | 126.6 | 224.6 | 372.6 | 470.4 | 12.7 | -4.2 | -0.77 |
| test_all | 20 | regime | rough | regime[vix_hyst]/calm=2,stress=1 | 87.4 | -18.6 | 74.6 | 134.4 | 233.7 | 413.4 | 570.5 | 12.7 | +11.8 | +2.69 |
| test_all | 20 | regime | rough_mv | regime[vix_hyst]/calm=2,stress=1 | 83.3 | -21.4 | 71.3 | 128.9 | 232.6 | 395.6 | 493.3 | 12.7 | +1.5 | +0.21 |
| test_all | 20 | regime | rough_a1 | regime[vix_hyst]/calm=2,stress=1 | 85.1 | -18.5 | 72.4 | 127.5 | 231.5 | 406.6 | 558.7 | 12.7 | +5.9 | +2.16 |
| test_all | 20 | regime | rough_mv_a1 | regime[vix_hyst]/calm=2,stress=1 | 82.2 | -20.4 | 70.0 | 129.4 | 228.7 | 391.0 | 500.3 | 12.7 | -1.2 | -0.25 |
| test_all | 20 | band | bs | band/h=0.05 | 79.0 | -16.3 | 65.3 | 124.0 | 215.5 | 335.6 | 500.3 | 10.0 | +0.0 | +0.00 |
| test_all | 20 | band | heston | band/h=0.05 | 79.4 | -16.0 | 65.8 | 133.5 | 213.4 | 329.0 | 496.3 | 9.8 | +1.2 | +0.82 |
| test_all | 20 | band | heston_mv | band/h=0.05 | 77.3 | -17.2 | 63.8 | 128.7 | 209.5 | 316.9 | 472.6 | 9.9 | -4.2 | -0.84 |
| test_all | 20 | band | rough | band/h=0.05 | 83.9 | -16.4 | 69.4 | 134.4 | 218.0 | 353.2 | 541.9 | 10.0 | +12.8 | +2.80 |
| test_all | 20 | band | rough_mv | band/h=0.05 | 79.4 | -19.0 | 65.8 | 117.7 | 216.6 | 327.5 | 484.8 | 10.2 | +1.1 | +0.16 |
| test_all | 20 | band | rough_a1 | band/h=0.05 | 81.5 | -16.3 | 67.4 | 128.6 | 217.1 | 347.5 | 527.3 | 10.0 | +6.4 | +2.17 |
| test_all | 20 | band | rough_mv_a1 | band/h=0.05 | 78.0 | -17.9 | 64.3 | 117.6 | 210.9 | 326.3 | 487.7 | 10.1 | -2.3 | -0.45 |

#### test_excl_covid

| sample | cost bp | strategy | hedge | rule | RMSE | mean | sd | VaR95 | ES95 | ES99 | worst | trades | vs BS % | z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| test_excl_covid | 0 | fixed | bs | fixed/every=1 | 50.7 | 29.6 | 50.7 | 50.2 | 119.3 | 196.3 | 283.0 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 0 | fixed | heston | fixed/every=1 | 52.2 | 29.6 | 52.2 | 54.9 | 120.4 | 192.9 | 277.6 | 20.0 | +5.8 | +3.56 |
| test_excl_covid | 0 | fixed | heston_mv | fixed/every=1 | 51.1 | 27.5 | 51.1 | 51.9 | 124.3 | 202.5 | 287.4 | 20.0 | +1.5 | +0.64 |
| test_excl_covid | 0 | fixed | rough | fixed/every=1 | 54.5 | 31.7 | 54.5 | 61.1 | 121.7 | 199.3 | 309.6 | 20.0 | +15.3 | +2.75 |
| test_excl_covid | 0 | fixed | rough_mv | fixed/every=1 | 52.0 | 26.2 | 52.0 | 53.8 | 131.6 | 218.5 | 303.5 | 20.0 | +5.0 | +0.81 |
| test_excl_covid | 0 | fixed | rough_a1 | fixed/every=1 | 52.7 | 30.8 | 52.7 | 54.3 | 119.3 | 194.1 | 283.4 | 20.0 | +7.8 | +2.57 |
| test_excl_covid | 0 | fixed | rough_mv_a1 | fixed/every=1 | 50.9 | 27.3 | 50.9 | 50.4 | 125.6 | 208.3 | 289.5 | 20.0 | +0.6 | +0.15 |
| test_excl_covid | 0 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 58.3 | 24.6 | 58.3 | 63.5 | 141.5 | 276.8 | 398.9 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 0 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 59.5 | 24.9 | 59.5 | 67.6 | 142.3 | 268.4 | 407.8 | 12.4 | +4.1 | +2.52 |
| test_excl_covid | 0 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 58.7 | 22.6 | 58.7 | 64.9 | 145.7 | 281.9 | 403.4 | 12.4 | +1.3 | +0.65 |
| test_excl_covid | 0 | regime | rough | regime[vix_hyst]/calm=2,stress=1 | 62.1 | 26.7 | 62.1 | 72.3 | 144.0 | 273.5 | 444.7 | 12.4 | +13.5 | +2.81 |
| test_excl_covid | 0 | regime | rough_mv | regime[vix_hyst]/calm=2,stress=1 | 60.1 | 20.9 | 60.1 | 72.3 | 154.3 | 302.8 | 425.0 | 12.4 | +6.2 | +1.05 |
| test_excl_covid | 0 | regime | rough_a1 | regime[vix_hyst]/calm=2,stress=1 | 60.2 | 25.9 | 60.2 | 67.0 | 141.7 | 270.2 | 421.7 | 12.4 | +6.7 | +2.52 |
| test_excl_covid | 0 | regime | rough_mv_a1 | regime[vix_hyst]/calm=2,stress=1 | 58.8 | 22.1 | 58.8 | 67.2 | 147.7 | 292.5 | 411.6 | 12.4 | +1.7 | +0.47 |
| test_excl_covid | 0 | band | bs | band/h=0.02 | 50.9 | 29.3 | 50.9 | 50.4 | 119.8 | 196.8 | 283.4 | 14.8 | +0.0 | +0.00 |
| test_excl_covid | 0 | band | heston | band/h=0.02 | 52.4 | 29.3 | 52.4 | 55.2 | 120.9 | 193.6 | 278.0 | 14.7 | +6.0 | +3.64 |
| test_excl_covid | 0 | band | heston_mv | band/h=0.02 | 51.4 | 27.2 | 51.4 | 54.6 | 125.2 | 203.2 | 287.5 | 14.8 | +1.8 | +0.74 |
| test_excl_covid | 0 | band | rough | band/h=0.02 | 54.6 | 31.4 | 54.6 | 61.2 | 122.0 | 199.0 | 307.7 | 14.7 | +15.2 | +2.79 |
| test_excl_covid | 0 | band | rough_mv | band/h=0.02 | 52.2 | 26.0 | 52.2 | 54.5 | 132.4 | 218.1 | 302.3 | 14.8 | +5.0 | +0.80 |
| test_excl_covid | 0 | band | rough_a1 | band/h=0.02 | 52.9 | 30.6 | 52.9 | 54.5 | 119.6 | 194.1 | 281.9 | 14.8 | +7.9 | +2.62 |
| test_excl_covid | 0 | band | rough_mv_a1 | band/h=0.02 | 51.1 | 27.0 | 51.1 | 51.4 | 126.4 | 208.4 | 289.4 | 14.9 | +0.5 | +0.13 |
| test_excl_covid | 5 | fixed | bs | fixed/every=1 | 52.3 | 17.7 | 50.9 | 64.2 | 133.9 | 213.5 | 295.9 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 5 | fixed | heston | fixed/every=1 | 53.6 | 17.6 | 52.2 | 66.8 | 135.2 | 210.1 | 298.0 | 20.0 | +5.0 | +2.89 |
| test_excl_covid | 5 | fixed | heston_mv | fixed/every=1 | 52.8 | 15.7 | 51.5 | 64.4 | 139.4 | 219.6 | 300.3 | 20.0 | +2.1 | +0.77 |
| test_excl_covid | 5 | fixed | rough | fixed/every=1 | 56.1 | 19.1 | 54.7 | 73.6 | 137.0 | 216.7 | 333.3 | 20.0 | +15.1 | +2.53 |
| test_excl_covid | 5 | fixed | rough_mv | fixed/every=1 | 54.3 | 14.3 | 53.0 | 66.9 | 147.0 | 235.9 | 326.5 | 20.0 | +7.8 | +1.17 |
| test_excl_covid | 5 | fixed | rough_a1 | fixed/every=1 | 54.2 | 18.5 | 52.7 | 64.8 | 134.0 | 211.6 | 306.3 | 20.0 | +7.3 | +2.22 |
| test_excl_covid | 5 | fixed | rough_mv_a1 | fixed/every=1 | 52.9 | 15.4 | 51.5 | 64.2 | 140.8 | 225.6 | 305.1 | 20.0 | +2.2 | +0.52 |
| test_excl_covid | 5 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 59.6 | 13.7 | 58.6 | 76.1 | 155.4 | 292.4 | 415.7 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 5 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 60.7 | 14.0 | 59.7 | 81.0 | 156.3 | 283.9 | 424.9 | 12.4 | +3.6 | +2.07 |
| test_excl_covid | 5 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 60.2 | 11.9 | 59.2 | 76.6 | 160.1 | 297.4 | 420.1 | 12.4 | +1.9 | +0.84 |
| test_excl_covid | 5 | regime | rough | regime[vix_hyst]/calm=2,stress=1 | 63.3 | 15.4 | 62.3 | 85.5 | 158.2 | 288.3 | 462.9 | 12.4 | +13.0 | +2.51 |
| test_excl_covid | 5 | regime | rough_mv | regime[vix_hyst]/calm=2,stress=1 | 62.0 | 10.1 | 61.1 | 84.9 | 168.9 | 318.5 | 442.1 | 12.4 | +8.4 | +1.33 |
| test_excl_covid | 5 | regime | rough_a1 | regime[vix_hyst]/calm=2,stress=1 | 61.4 | 14.8 | 60.4 | 78.9 | 155.6 | 285.7 | 439.2 | 12.4 | +6.1 | +2.13 |
| test_excl_covid | 5 | regime | rough_mv_a1 | regime[vix_hyst]/calm=2,stress=1 | 60.5 | 11.3 | 59.5 | 78.5 | 162.2 | 308.1 | 428.5 | 12.4 | +3.0 | +0.77 |
| test_excl_covid | 5 | band | bs | band/h=0.02 | 52.4 | 17.6 | 51.1 | 62.9 | 134.2 | 213.8 | 296.1 | 14.8 | +0.0 | +0.00 |
| test_excl_covid | 5 | band | heston | band/h=0.02 | 53.8 | 17.5 | 52.5 | 67.2 | 135.5 | 210.7 | 296.4 | 14.7 | +5.2 | +2.98 |
| test_excl_covid | 5 | band | heston_mv | band/h=0.02 | 53.0 | 15.6 | 51.8 | 64.5 | 140.1 | 220.2 | 300.2 | 14.8 | +2.3 | +0.87 |
| test_excl_covid | 5 | band | rough | band/h=0.02 | 56.3 | 19.0 | 54.9 | 75.1 | 137.3 | 216.3 | 331.3 | 14.7 | +15.1 | +2.56 |
| test_excl_covid | 5 | band | rough_mv | band/h=0.02 | 54.4 | 14.3 | 53.2 | 68.1 | 147.6 | 235.3 | 325.2 | 14.8 | +7.8 | +1.16 |
| test_excl_covid | 5 | band | rough_a1 | band/h=0.02 | 54.4 | 18.5 | 53.0 | 64.6 | 134.2 | 211.5 | 304.7 | 14.8 | +7.5 | +2.26 |
| test_excl_covid | 5 | band | rough_mv_a1 | band/h=0.02 | 53.0 | 15.3 | 51.7 | 64.2 | 141.3 | 225.5 | 303.3 | 14.9 | +2.2 | +0.50 |
| test_excl_covid | 20 | fixed | bs | fixed/every=1 | 70.8 | -18.1 | 52.4 | 100.6 | 178.8 | 265.1 | 363.3 | 20.0 | +0.0 | +0.00 |
| test_excl_covid | 20 | fixed | heston | fixed/every=1 | 71.5 | -18.2 | 53.2 | 103.6 | 180.4 | 261.9 | 365.5 | 20.0 | +2.0 | +1.28 |
| test_excl_covid | 20 | fixed | heston_mv | fixed/every=1 | 71.2 | -19.4 | 53.6 | 105.7 | 185.3 | 271.0 | 364.3 | 20.0 | +1.0 | +0.46 |
| test_excl_covid | 20 | fixed | rough | fixed/every=1 | 75.3 | -18.5 | 56.1 | 114.3 | 184.2 | 268.9 | 404.6 | 20.0 | +13.1 | +2.52 |
| test_excl_covid | 20 | fixed | rough_mv | fixed/every=1 | 74.0 | -21.3 | 56.8 | 110.0 | 194.0 | 288.4 | 395.6 | 20.0 | +9.3 | +1.74 |
| test_excl_covid | 20 | fixed | rough_a1 | fixed/every=1 | 72.8 | -18.3 | 53.8 | 103.3 | 179.4 | 264.3 | 375.2 | 20.0 | +5.7 | +1.98 |
| test_excl_covid | 20 | fixed | rough_mv_a1 | fixed/every=1 | 72.1 | -20.1 | 54.4 | 106.5 | 186.8 | 277.5 | 372.8 | 20.0 | +3.7 | +1.06 |
| test_excl_covid | 20 | regime | bs | regime[vix_hyst]/calm=2,stress=1 | 74.2 | -18.8 | 60.2 | 110.9 | 198.4 | 339.2 | 466.0 | 12.4 | +0.0 | +0.00 |
| test_excl_covid | 20 | regime | heston | regime[vix_hyst]/calm=2,stress=1 | 74.9 | -18.7 | 60.9 | 113.4 | 199.1 | 330.6 | 476.2 | 12.4 | +1.8 | +1.11 |
| test_excl_covid | 20 | regime | heston_mv | regime[vix_hyst]/calm=2,stress=1 | 74.9 | -20.1 | 61.5 | 115.0 | 203.9 | 344.0 | 470.3 | 12.4 | +1.8 | +0.82 |
| test_excl_covid | 20 | regime | rough | regime[vix_hyst]/calm=2,stress=1 | 78.1 | -18.8 | 63.5 | 122.6 | 202.0 | 334.7 | 517.5 | 12.4 | +10.8 | +2.22 |
| test_excl_covid | 20 | regime | rough_mv | regime[vix_hyst]/calm=2,stress=1 | 77.7 | -22.1 | 64.8 | 122.6 | 213.4 | 365.6 | 493.3 | 12.4 | +9.7 | +1.80 |
| test_excl_covid | 20 | regime | rough_a1 | regime[vix_hyst]/calm=2,stress=1 | 75.9 | -18.7 | 61.5 | 114.4 | 198.5 | 332.6 | 491.8 | 12.4 | +4.7 | +1.69 |
| test_excl_covid | 20 | regime | rough_mv_a1 | regime[vix_hyst]/calm=2,stress=1 | 75.8 | -20.9 | 62.4 | 116.8 | 206.2 | 354.9 | 479.1 | 12.4 | +4.2 | +1.22 |
| test_excl_covid | 20 | band | bs | band/h=0.05 | 69.9 | -16.6 | 53.9 | 105.4 | 180.7 | 270.3 | 355.2 | 10.0 | +0.0 | +0.00 |
| test_excl_covid | 20 | band | heston | band/h=0.05 | 70.6 | -16.4 | 54.7 | 110.7 | 183.0 | 266.8 | 358.2 | 9.9 | +1.9 | +1.25 |
| test_excl_covid | 20 | band | heston_mv | band/h=0.05 | 70.3 | -17.8 | 55.1 | 103.5 | 186.7 | 277.1 | 361.7 | 9.9 | +1.2 | +0.50 |
| test_excl_covid | 20 | band | rough | band/h=0.05 | 74.0 | -16.9 | 57.0 | 116.6 | 185.9 | 268.1 | 397.7 | 10.0 | +12.1 | +2.29 |
| test_excl_covid | 20 | band | rough_mv | band/h=0.05 | 73.1 | -19.8 | 58.0 | 113.2 | 195.6 | 289.7 | 387.7 | 10.2 | +9.4 | +1.80 |
| test_excl_covid | 20 | band | rough_a1 | band/h=0.05 | 71.7 | -16.6 | 55.0 | 106.2 | 181.5 | 265.3 | 368.0 | 10.1 | +5.1 | +1.70 |
| test_excl_covid | 20 | band | rough_mv_a1 | band/h=0.05 | 71.1 | -18.6 | 55.6 | 107.9 | 187.5 | 281.2 | 364.5 | 10.2 | +3.4 | +1.01 |


---

## 8d. Pricing test (traded options)

IMPORTANT: this needs the NSE option data in `data/raw/bhavcopy/nifty/`, which
is git-ignored. A fresh clone has only 243 days (2010, 2013, 2014 and 24 days of
2023). For the full ~4,000 days, either copy that folder from a teammate's
machine that has it, or rebuild it (internet access to nsearchives.nseindia.com,
about 1.5 h, resumable):

```bash
python -m src.bhavcopy
```

Then:

```bash
python -m src.pricing_test
```

Writes `results/pricing_test/{atm_3m.csv, smile_3m.csv, summary.json, summary.md}`
and prints the summary. Takes under a minute on 243 days; a few minutes on all.

Reference output on the 243 days in the repo (211 ATM days in the train period
2010/2013/2014, only 24 in the test period, all 2023; parameters estimated on
2010-2018, so the train-period numbers are in-sample):

#### Pricing 3-month NIFTY calls: model vs market

Option days: 235 (2010-07-20 .. 2023-07-05); ATM days by year: {'2010': 114, '2013': 21, '2014': 76, '2023': 24}

Error = model - market. bp of the futures price; vol pts = implied-vol points.

#### ATM call, ~3 months (the paper's option)

| period | options | model | bias bp | RMSE bp | MAE bp | bias vol pts | RMSE vol pts |
|---|---|---|---|---|---|---|---|
| train | 211 | bs | +3.7 | 68.3 | 41.5 | +0.19 | 3.77 |
| train | 211 | heston | -10.3 | 57.3 | 36.3 | -0.58 | 3.21 |
| train | 211 | rough | -11.5 | 69.5 | 36.4 | -0.66 | 3.85 |
| train | 211 | rough_a1 | -6.0 | 68.6 | 37.1 | -0.35 | 3.79 |
| test | 24 | bs | +10.3 | 13.7 | 11.0 | +0.54 | 0.71 |
| test | 24 | heston | +85.7 | 86.9 | 85.7 | +4.60 | 4.63 |
| test | 24 | rough | -9.8 | 13.1 | 10.7 | -0.54 | 0.73 |
| test | 24 | rough_a1 | -3.1 | 9.4 | 7.8 | -0.18 | 0.51 |
| all | 235 | bs | +4.4 | 64.8 | 38.4 | +0.23 | 3.58 |
| all | 235 | heston | -0.5 | 61.0 | 41.3 | -0.05 | 3.39 |
| all | 235 | rough | -11.3 | 66.0 | 33.8 | -0.65 | 3.65 |
| all | 235 | rough_a1 | -5.7 | 65.1 | 34.1 | -0.33 | 3.60 |

#### All traded calls 0.90 <= K/F <= 1.10, same expiry

| period | options | model | bias bp | RMSE bp | MAE bp | bias vol pts | RMSE vol pts |
|---|---|---|---|---|---|---|---|
| train | 2363 | bs | +2.1 | 64.1 | 44.8 | +0.15 | 4.19 |
| train | 2363 | heston | -10.7 | 53.4 | 36.5 | -0.63 | 3.53 |
| train | 2363 | rough | -11.4 | 61.8 | 35.1 | -0.77 | 3.98 |
| train | 2363 | rough_a1 | -7.1 | 61.5 | 36.3 | -0.48 | 3.96 |
| test | 518 | bs | +2.0 | 15.2 | 11.1 | +0.07 | 1.32 |
| test | 518 | heston | +68.0 | 71.5 | 68.7 | +4.28 | 4.43 |
| test | 518 | rough | -5.2 | 15.3 | 11.0 | -0.30 | 1.27 |
| test | 518 | rough_a1 | -2.0 | 13.4 | 8.9 | -0.11 | 1.16 |
| all | 2881 | bs | +2.1 | 58.4 | 38.7 | +0.13 | 3.84 |
| all | 2881 | heston | +3.4 | 57.1 | 42.3 | +0.25 | 3.71 |
| all | 2881 | rough | -10.3 | 56.4 | 30.8 | -0.68 | 3.65 |
| all | 2881 | rough_a1 | -6.2 | 56.0 | 31.4 | -0.41 | 3.62 |

#### Smile: mean implied-vol error by moneyness (vol pts)

| K/F | options | market IV % | bs | heston | rough | rough_a1 |
|---|---|---|---|---|---|---|
| 0.90-0.95 | 422 | 20.8 | -2.16 | -1.27 | -0.57 | -0.80 |
| 0.95-0.99 | 755 | 17.6 | -0.79 | +0.48 | -0.69 | -0.58 |
| 0.99-1.01 | 408 | 16.7 | +0.04 | +0.90 | -0.88 | -0.55 |
| 1.01-1.05 | 620 | 17.7 | +0.92 | +0.25 | -0.76 | -0.29 |
| 1.05-1.10 | 676 | 17.0 | +1.93 | +0.55 | -0.55 | +0.00 |

Extra check (smile SHAPE only, each day's level error removed, RMSE in vol pts):
train bs 1.75, heston 1.31, rough 1.22, rough_a1 1.23; test bs 1.23, heston
1.01, rough 1.13, rough_a1 1.04.

Reading: no model fitted to option prices, all use only VIX. ATM 3-month:
rough and the alpha = 1 control are as accurate as BS (flat forward variance at
VIX^2 keeps the level at VIX); Heston is better in-sample but overprices 2023
(+4.6 vol pts) because its long-run level theta = 18% pulls the 3-month vol up
when VIX was ~11-12. Smile shape: every stochastic-volatility model beats BS
(which has no skew); rough is not clearly better than alpha = 1 at 3 months.
Re-run on the full data before drawing conclusions about 2019-2026.


---

## 9. Deliverables to hand back

1. The 11 new files (step 3).
2. `results/backtest_heston/comparison{,_rolling,_rough}.md` and `.csv`, `rough_params.json`, `results/pricing_test/summary.{md,json}`,
   `heston_params.json`, and each hedge's `analysis*.json`, `rules_test*.csv`,
   `fig_frontier_test*.png/pdf`.
3. The console output of steps 5 and 6 and the result of the check in 7.1.
Do not commit unless asked; if asked, `.npz` files stay uncommitted (ignored).
